// =====================================================================
// Topology: closed regions and open paths derived from the sketch,
// stable shape identity, outline paths, SVG and PNG helpers.
// =====================================================================

function segStart(s) {
  return s.t === 'L' ? [s.x0, s.y0] : [s.cx + s.r * Math.cos(s.a0), s.cy + s.r * Math.sin(s.a0)];
}
function segEnd(s) {
  return s.t === 'L' ? [s.x1, s.y1] : [s.cx + s.r * Math.cos(s.a1), s.cy + s.r * Math.sin(s.a1)];
}
function segFlip(s) {
  if (s.t === 'L') return { t: 'L', x0: s.x1, y0: s.y1, x1: s.x0, y1: s.y0 };
  return { t: 'A', cx: s.cx, cy: s.cy, r: s.r, a0: s.a1, a1: s.a0, ccw: !s.ccw };
}
function segArea(s) {
  const a = segStart(s), b = segEnd(s);
  let v = (a[0] * b[1] - b[0] * a[1]) / 2;
  if (s.t === 'A') {
    const phi = Math.abs(s.a1 - s.a0);
    v += (s.ccw ? 1 : -1) * s.r * s.r * (phi - Math.sin(phi)) / 2;
  }
  return v;
}
function segLen(s) {
  return s.t === 'L' ? Math.hypot(s.x1 - s.x0, s.y1 - s.y0) : s.r * Math.abs(s.a1 - s.a0);
}
// midpoint and left-hand unit normal (relative to travel direction)
function segMid(s) {
  if (s.t === 'L') {
    const dx = s.x1 - s.x0, dy = s.y1 - s.y0, L = Math.hypot(dx, dy) || 1;
    return { x: (s.x0 + s.x1) / 2, y: (s.y0 + s.y1) / 2, nx: -dy / L, ny: dx / L };
  }
  const am = (s.a0 + s.a1) / 2, c = Math.cos(am), sn = Math.sin(am), k = s.ccw ? -1 : 1;
  return { x: s.cx + s.r * c, y: s.cy + s.r * sn, nx: k * c, ny: k * sn };
}
function angInSpan(ang, s) {
  const sw = Math.abs(s.a1 - s.a0);
  if (sw >= TAU - 1e-12) return true;
  return normAng(ang - (s.ccw ? s.a0 : s.a1)) < sw;
}
// crossings of the ray from (qx,qy) toward +x
function segCross(s, qx, qy) {
  if (s.t === 'L') {
    if ((s.y0 > qy) !== (s.y1 > qy)) {
      const x = s.x0 + (qy - s.y0) * (s.x1 - s.x0) / (s.y1 - s.y0);
      return x > qx ? 1 : 0;
    }
    return 0;
  }
  const dy = qy - s.cy;
  if (Math.abs(dy) >= s.r) return 0;
  const h = Math.sqrt(s.r * s.r - dy * dy);
  let n = 0;
  if (s.cx + h > qx && angInSpan(Math.atan2(dy, h), s)) n++;
  if (s.cx - h > qx && angInSpan(Math.atan2(dy, -h), s)) n++;
  return n;
}
function segDist(s, qx, qy) {
  if (s.t === 'L') {
    const dx = s.x1 - s.x0, dy = s.y1 - s.y0, L2 = dx * dx + dy * dy;
    let t = L2 > 0 ? ((qx - s.x0) * dx + (qy - s.y0) * dy) / L2 : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    return Math.hypot(qx - s.x0 - t * dx, qy - s.y0 - t * dy);
  }
  const ang = Math.atan2(qy - s.cy, qx - s.cx);
  if (angInSpan(ang, s)) return Math.abs(Math.hypot(qx - s.cx, qy - s.cy) - s.r);
  const a = segStart(s), b = segEnd(s);
  return Math.min(Math.hypot(qx - a[0], qy - a[1]), Math.hypot(qx - b[0], qy - b[1]));
}
// even-odd membership over a set of cycles
function inCycles(cycles, qx, qy) {
  const y = qy + 1.3e-9 * (1 + Math.abs(qy));
  let n = 0;
  for (const c of cycles) for (const s of c.segs) n += segCross(s, qx, y);
  return (n & 1) === 1;
}
function cyclesDist(cycles, qx, qy) {
  let d = Infinity;
  for (const c of cycles) for (const s of c.segs) { const v = segDist(s, qx, qy); if (v < d) d = v; }
  return d;
}
function segBBox(s, bb) {
  const add = (x, y) => { if (x < bb[0]) bb[0] = x; if (y < bb[1]) bb[1] = y; if (x > bb[2]) bb[2] = x; if (y > bb[3]) bb[3] = y; };
  const a = segStart(s), b = segEnd(s);
  add(a[0], a[1]); add(b[0], b[1]);
  if (s.t === 'A') {
    for (let k = 0; k < 4; k++) {
      const ang = k * Math.PI / 2;
      if (angInSpan(ang, s)) add(s.cx + s.r * Math.cos(ang), s.cy + s.r * Math.sin(ang));
    }
  }
}
function reverseCycle(c) {
  return { segs: c.segs.slice().reverse().map(segFlip), area: -c.area };
}

function computeTopology(doc, sys) {
  const node = pid => sys.uf.find(pid);
  const pos = pid => doc.points[pid];
  const junc = new Map();
  for (const id in doc.constraints) {
    const c = doc.constraints[id];
    if (c.type !== 'pointOn' || !conValid(doc, c)) continue;
    const e = doc.entities[c.refs[1]];
    if (e.ref || e.construction) continue;
    let l = junc.get(e.id);
    if (!l) junc.set(e.id, l = []);
    l.push(c.refs[0]);
  }
  const edges = [], faces = [];
  const dedupe = stops => stops.filter((s, i) => i === 0 || s.node !== stops[i - 1].node);
  for (const id in doc.entities) {
    const e = doc.entities[id];
    if (e.ref || e.construction) continue;
    const js = junc.get(id) || [];
    if (e.type === 'line') {
      const A = pos(e.p1), B = pos(e.p2), dx = B.x - A.x, dy = B.y - A.y, L2 = dx * dx + dy * dy;
      if (L2 < 1e-18) continue;
      let stops = [{ u: 0, node: node(e.p1), tok: 's', x: A.x, y: A.y }, { u: 1, node: node(e.p2), tok: 'e', x: B.x, y: B.y }];
      for (const pid of js) {
        const q = pos(pid), u = ((q.x - A.x) * dx + (q.y - A.y) * dy) / L2;
        if (u > 1e-9 && u < 1 - 1e-9) stops.push({ u, node: node(pid), tok: pid, x: A.x + u * dx, y: A.y + u * dy });
      }
      stops.sort((a, b) => a.u - b.u);
      stops = dedupe(stops);
      const split = stops.length > 2;
      for (let i = 0; i + 1 < stops.length; i++) {
        const a = stops[i], b = stops[i + 1];
        edges.push({
          ent: id, tok: split ? id + '[' + a.tok + ',' + b.tok + ']' : id, a: a.node, b: b.node,
          seg: { t: 'L', x0: a.x, y0: a.y, x1: b.x, y1: b.y }
        });
      }
    } else if (e.type === 'arc') {
      const c = pos(e.c), s = pos(e.s), en = pos(e.e);
      const r = Math.hypot(s.x - c.x, s.y - c.y);
      if (r < 1e-9) continue;
      const a0 = Math.atan2(s.y - c.y, s.x - c.x);
      const sw = normAng(Math.atan2(en.y - c.y, en.x - c.x) - a0);
      if (sw < 1e-9) continue;
      let stops = [{ u: 0, node: node(e.s), tok: 's' }, { u: 1, node: node(e.e), tok: 'e' }];
      for (const pid of js) {
        const q = pos(pid), u = normAng(Math.atan2(q.y - c.y, q.x - c.x) - a0) / sw;
        if (u > 1e-9 && u < 1 - 1e-9) stops.push({ u, node: node(pid), tok: pid });
      }
      stops.sort((a, b) => a.u - b.u);
      stops = dedupe(stops);
      const split = stops.length > 2;
      for (let i = 0; i + 1 < stops.length; i++) {
        const a = stops[i], b = stops[i + 1];
        edges.push({
          ent: id, tok: split ? id + '[' + a.tok + ',' + b.tok + ']' : id, a: a.node, b: b.node,
          seg: { t: 'A', cx: c.x, cy: c.y, r, a0: a0 + a.u * sw, a1: a0 + b.u * sw, ccw: true }
        });
      }
    } else if (e.type === 'circle') {
      const c = pos(e.c), r = e.r;
      if (!(r > 1e-9)) continue;
      let stops = js.map(pid => { const q = pos(pid); return { u: normAng(Math.atan2(q.y - c.y, q.x - c.x)), node: node(pid), tok: pid }; });
      stops.sort((a, b) => a.u - b.u);
      stops = dedupe(stops);
      if (stops.length > 1 && stops[0].node === stops[stops.length - 1].node) stops.pop();
      if (!stops.length) {
        const seg = { t: 'A', cx: c.x, cy: c.y, r, a0: 0, a1: TAU, ccw: true };
        faces.push({ comp: 'ring:' + id, cycles: [{ segs: [seg], area: Math.PI * r * r }], toks: [id], ents: [id] });
        continue;
      }
      for (let i = 0; i < stops.length; i++) {
        const a = stops[i], b = stops[(i + 1) % stops.length];
        const a1 = i + 1 < stops.length ? b.u : stops[0].u + TAU;
        edges.push({
          ent: id, tok: id + '[' + a.tok + ',' + b.tok + ']', a: a.node, b: b.node,
          seg: { t: 'A', cx: c.x, cy: c.y, r, a0: a.u, a1, ccw: true }
        });
      }
    }
  }

  // half-edges: 2k forward, 2k+1 reverse
  const nH = edges.length * 2;
  const hFrom = h => (h & 1) ? edges[h >> 1].b : edges[h >> 1].a;
  const hTo = h => (h & 1) ? edges[h >> 1].a : edges[h >> 1].b;
  const hSeg = h => (h & 1) ? segFlip(edges[h >> 1].seg) : edges[h >> 1].seg;
  const out = new Map();
  for (let h = 0; h < nH; h++) {
    const s = edges[h >> 1].seg;
    let ang, curv;
    if (s.t === 'L') { ang = Math.atan2(s.y1 - s.y0, s.x1 - s.x0) + ((h & 1) ? Math.PI : 0); curv = 0; }
    else if (h & 1) { ang = s.a1 - Math.PI / 2; curv = -1 / s.r; }
    else { ang = s.a0 + Math.PI / 2; curv = 1 / s.r; }
    ang = normAng(ang);
    if (ang > TAU - 1e-7) ang = 0;
    const n = hFrom(h);
    let l = out.get(n);
    if (!l) out.set(n, l = []);
    l.push({ h, ang, curv });
  }
  const posIn = new Int32Array(nH);
  const lists = new Map();
  for (const [n, l] of out) {
    l.sort((a, b) => a.ang - b.ang);
    // same tangent direction: the curve bending left comes later (counter-clockwise)
    const m = l.length;
    let start = 0;
    for (let i = 0; i < m; i++) {
      const prev = l[(i - 1 + m) % m];
      if (Math.abs(wrapPi(l[i].ang - prev.ang)) > 1e-7) { start = i; break; }
    }
    const rot = l.slice(start).concat(l.slice(0, start));
    for (let i = 0; i < m;) {
      let j = i + 1;
      while (j < m && Math.abs(wrapPi(rot[j].ang - rot[j - 1].ang)) <= 1e-7) j++;
      if (j - i > 1) { const run = rot.slice(i, j).sort((a, b) => a.curv - b.curv); for (let k = i; k < j; k++) rot[k] = run[k - i]; }
      i = j;
    }
    const hs = rot.map(o => o.h);
    lists.set(n, hs);
    hs.forEach((h, i) => { posIn[h] = i; });
  }

  // graph components
  const cuf = new UF();
  for (const e of edges) cuf.union(e.a, e.b);

  // face walks
  const seen = new Uint8Array(nH);
  const closedEdge = new Uint8Array(edges.length);
  for (let h0 = 0; h0 < nH; h0++) {
    if (seen[h0]) continue;
    const walk = [];
    let h = h0, guard = 0;
    do {
      seen[h] = 1; walk.push(h);
      const l = lists.get(hTo(h));
      h = l[(posIn[h ^ 1] - 1 + l.length) % l.length];
    } while (h !== h0 && ++guard < nH + 2);
    let area = 0;
    for (const w of walk) area += segArea(hSeg(w));
    if (!(area > 1e-9)) continue;
    // drop spurs and bridges (edges walked in both directions), then
    // split what is left into closed cycles
    const inWalk = new Set(walk);
    const keep = walk.map(w => !inWalk.has(w ^ 1));
    let rot = 0;
    for (let i = 0; i < walk.length; i++) if (!keep[i]) { rot = i; break; }
    const frags = [];
    let cur = null;
    for (let k = 0; k < walk.length; k++) {
      const i = (rot + k) % walk.length;
      if (!keep[i]) { cur = null; continue; }
      if (!cur) frags.push(cur = []);
      cur.push(walk[i]);
    }
    const cycles = [], stack = [];
    for (const f of frags) {
      let c = f;
      for (; ;) {
        if (hFrom(c[0]) === hTo(c[c.length - 1])) { cycles.push(c); break; }
        const top = stack[stack.length - 1];
        if (top && hTo(top[top.length - 1]) === hFrom(c[0])) { stack.pop(); c = top.concat(c); continue; }
        stack.push(c);
        break;
      }
    }
    const cyc = cycles.map(c => {
      const segs = c.map(hSeg);
      let a = 0;
      for (const s of segs) a += segArea(s);
      return { segs, area: a, hs: c };
    }).filter(c => Math.abs(c.area) > 1e-9).sort((a, b) => b.area - a.area);
    if (!cyc.length || cyc[0].area <= 0) continue;
    for (const c of cyc) for (const w of c.hs) closedEdge[w >> 1] = 1;
    const toks = cyc[0].hs.map(w => edges[w >> 1].tok);
    const ents = Array.from(new Set(cyc[0].hs.map(w => edges[w >> 1].ent)));
    faces.push({ comp: cuf.find(edges[walk[0] >> 1].a), cycles: cyc.map(c => ({ segs: c.segs, area: c.area })), toks, ents });
  }

  for (let i = 0; i < faces.length; i++) {
    const f = faces[i];
    f.idx = i;
    f.key = 'F|' + f.toks.slice().sort().join('+');
    f.outerArea = f.cycles[0].area;
    f.area = f.cycles.reduce((s, c) => s + c.area, 0);
    f.parent = -1; f.children = [];
    const bb = [Infinity, Infinity, -Infinity, -Infinity];
    for (const s of f.cycles[0].segs) segBBox(s, bb);
    f.bbox = bb;
  }
  // make keys unique when two regions share the same edge set
  const keyCount = new Map();
  for (const f of faces) {
    const n = keyCount.get(f.key) || 0;
    keyCount.set(f.key, n + 1);
    if (n) f.key += '#' + n;
  }

  // nesting: a component that lies wholly inside a face of another
  // component becomes that face's child
  const byComp = new Map();
  for (const f of faces) { let l = byComp.get(f.comp); if (!l) byComp.set(f.comp, l = []); l.push(f); }
  const interior = f => {
    const segs = f.cycles[0].segs.slice().sort((a, b) => segLen(b) - segLen(a)).slice(0, 8);
    const sc = Math.sqrt(f.outerArea);
    for (const d of [1e-3, 1e-2, 1e-4, 0.05]) {
      for (const s of segs) {
        const m = segMid(s), x = m.x + m.nx * d * sc, y = m.y + m.ny * d * sc;
        if (inCycles(f.cycles, x, y)) return [x, y];
      }
    }
    const m = segMid(segs[0]);
    return [m.x, m.y];
  };
  for (const [, list] of byComp) {
    let rep = list[0], total = 0;
    const bb = [Infinity, Infinity, -Infinity, -Infinity];
    const probes = [];
    for (const f of list) {
      total += f.area;
      if (f.outerArea > rep.outerArea) rep = f;
      for (const s of f.cycles[0].segs) { segBBox(s, bb); const m = segMid(s); probes.push(segStart(s), [m.x, m.y]); }
    }
    const q = interior(rep);
    const stride = Math.max(1, Math.floor(probes.length / 24));
    let best = null;
    for (const g of faces) {
      if (g.comp === rep.comp || g.outerArea <= total * (1 + 1e-9)) continue;
      if (best && g.outerArea >= best.outerArea) continue;
      const gb = g.bbox, tol = 1e-6 * (1 + Math.sqrt(g.outerArea));
      if (bb[0] < gb[0] - tol || bb[1] < gb[1] - tol || bb[2] > gb[2] + tol || bb[3] > gb[3] + tol) continue;
      if (!inCycles(g.cycles, q[0], q[1])) continue;
      let ok = true;
      for (let i = 0; i < probes.length && ok; i += stride) {
        const p = probes[i];
        if (!inCycles(g.cycles, p[0], p[1]) && cyclesDist(g.cycles, p[0], p[1]) > tol) ok = false;
      }
      if (ok) best = g;
    }
    if (best) for (const f of list) { f.parent = best.idx; best.children.push(f.idx); }
  }

  // open chains: edges that bound no region
  const paths = [];
  const openAt = new Map();
  edges.forEach((e, k) => {
    if (closedEdge[k]) return;
    for (const n of [e.a, e.b]) { let l = openAt.get(n); if (!l) openAt.set(n, l = []); l.push(k); }
  });
  const usedE = new Uint8Array(edges.length);
  const traceFrom = (k0, n0) => {
    const hs = [];
    let k = k0, n = n0;
    for (; ;) {
      usedE[k] = 1;
      const e = edges[k];
      const fwd = e.a === n;
      hs.push(fwd ? 2 * k : 2 * k + 1);
      n = fwd ? e.b : e.a;
      const l = openAt.get(n);
      if (!l || l.length !== 2) break;
      const nk = l[0] === k ? l[1] : l[0];
      if (usedE[nk] || nk === k) break;
      k = nk;
    }
    return hs;
  };
  const pushPath = hs => {
    const toks = hs.map(w => edges[w >> 1].tok);
    paths.push({
      key: 'P|' + toks.slice().sort().join('+'), segs: hs.map(hSeg),
      ents: Array.from(new Set(hs.map(w => edges[w >> 1].ent))),
      closed: hFrom(hs[0]) === hTo(hs[hs.length - 1])
    });
  };
  for (const [n, l] of openAt) {
    if (l.length === 2 && l[0] !== l[1]) continue;
    for (const k of l) if (!usedE[k]) pushPath(traceFrom(k, n));
  }
  edges.forEach((e, k) => { if (!closedEdge[k] && !usedE[k]) pushPath(traceFrom(k, e.a)); });
  for (const p of paths) {
    const bb = [Infinity, Infinity, -Infinity, -Infinity];
    for (const s of p.segs) segBBox(s, bb);
    p.bbox = bb;
  }
  return { faces, paths, edges };
}

// ---------------------------------------------------------------------
// Shape records: style keyed by the set of sketch entities in the loop.
// ---------------------------------------------------------------------
const DEFAULT_STYLE = { fill: 'none', stroke: '#1b1f24', sw: 0.35, opacity: 1, dash: 'solid', join: 'miter', cap: 'butt' };
const STYLE_KEYS = ['fill', 'stroke', 'sw', 'opacity', 'dash', 'join', 'cap'];

function syncShapes(doc, topo) {
  const active = new Set();
  for (const f of topo.faces) active.add(f.key);
  for (const p of topo.paths) active.add(p.key);
  const claim = (key, ents) => {
    let rec = doc.shapes[key];
    if (rec) return rec;
    // a loop that changed (split, trimmed, re-closed) inherits from the
    // unused record it shares the most entities with
    let best = null, bestScore = 0;
    for (const k in doc.shapes) {
      if (active.has(k)) continue;
      const r = doc.shapes[k];
      let sc = 0;
      for (const e of r.ents) if (ents.indexOf(e) >= 0) sc++;
      if (sc * 2 < Math.min(ents.length, r.ents.length) || sc === 0) continue;
      if (sc > bestScore || (sc === bestScore && best && r.z > best.z)) { best = r; bestScore = sc; }
    }
    rec = { ents: ents.slice() };
    for (const k of STYLE_KEYS) rec[k] = best ? best[k] : DEFAULT_STYLE[k];
    if (best && best.own !== undefined) rec.own = best.own;
    if (best && best.user) rec.user = true;
    rec.z = best ? best.z + 0.001 : ++doc.zTop;
    doc.shapes[key] = rec;
    return rec;
  };
  for (const f of topo.faces) {
    f.rec = claim(f.key, f.ents);
    f.own = f.parent < 0 ? true : f.rec.own === true;
  }
  for (const p of topo.paths) p.rec = claim(p.key, p.ents);
  // keep an unused record only while it holds styling the user chose
  // and some of its entities still exist
  for (const k in doc.shapes) {
    if (active.has(k)) continue;
    const r = doc.shapes[k];
    if (!r.user || !r.ents.some(e => doc.entities[e])) delete doc.shapes[k];
  }
}

// Outline of a region shape: its own boundary, plus every nested loop
// that has not been turned into a shape of its own. Orientation
// alternates with depth, so even-odd and non-zero fills agree.
function shapeCycles(topo, f) {
  const out = [];
  const visit = (face, depth) => {
    for (const c of face.cycles) out.push(depth % 2 ? reverseCycle(c) : c);
    for (const ci of face.children) {
      const ch = topo.faces[ci];
      if (!ch.own) visit(ch, depth + 1);
    }
  };
  visit(f, 0);
  return out;
}

// Everything that is drawn and exported, back to front.
function drawList(topo) {
  const items = [];
  for (const f of topo.faces) if (f.own) items.push({ kind: 'face', key: f.key, rec: f.rec, face: f, cycles: shapeCycles(topo, f), closed: true });
  for (const p of topo.paths) items.push({ kind: 'path', key: p.key, rec: p.rec, path: p, cycles: [{ segs: p.segs }], closed: p.closed });
  items.sort((a, b) => a.rec.z - b.rec.z);
  return items;
}

// Innermost region under a point.
function hitFace(topo, x, y) {
  let best = null;
  for (const f of topo.faces) {
    const b = f.bbox;
    if (x < b[0] || x > b[2] || y < b[1] || y > b[3]) continue;
    if (best && f.outerArea >= best.outerArea) continue;
    if (inCycles(f.cycles, x, y)) best = f;
  }
  return best;
}
// The shape that owns a region (itself, or the ancestor it is a hole of).
function ownerFace(topo, f) {
  while (!f.own && f.parent >= 0) f = topo.faces[f.parent];
  return f;
}

const DASHES = { solid: null, dash: [5, 3], dot: [1, 2.5], dashdot: [6, 2.5, 1, 2.5] };
function dashArray(rec) {
  const d = DASHES[rec.dash];
  return d ? d.map(v => v * Math.max(rec.sw, 0.01)) : null;
}

// Bounds of the geometry, and of the geometry plus its outline.
function itemsBounds(items) {
  const g = [Infinity, Infinity, -Infinity, -Infinity], s = [Infinity, Infinity, -Infinity, -Infinity];
  const grow = (bb, x, y) => { if (x < bb[0]) bb[0] = x; if (y < bb[1]) bb[1] = y; if (x > bb[2]) bb[2] = x; if (y > bb[3]) bb[3] = y; };
  for (const it of items) {
    const hw = it.rec.stroke === 'none' ? 0 : it.rec.sw / 2;
    for (const c of it.cycles) {
      const one = [Infinity, Infinity, -Infinity, -Infinity];
      for (const sg of c.segs) segBBox(sg, one);
      grow(g, one[0], one[1]); grow(g, one[2], one[3]);
      grow(s, one[0] - hw, one[1] - hw); grow(s, one[2] + hw, one[3] + hw);
      // sharp mitred corners reach further than half the stroke width
      if (hw > 0 && it.rec.join === 'miter') {
        const n = c.segs.length;
        for (let i = 0; i < n; i++) {
          if (!it.closed && i === 0) continue;
          const a = c.segs[(i - 1 + n) % n], b = c.segs[i];
          const ta = segTangent(a, true), tb = segTangent(b, false);
          const dot = ta[0] * tb[0] + ta[1] * tb[1];
          const half = Math.acos(Math.max(-1, Math.min(1, -dot))) / 2;
          const ratio = 1 / Math.max(Math.sin(half), 1e-6);
          if (ratio > 4 || ratio < 1.0001) continue;
          const bx = ta[0] - tb[0], by = ta[1] - tb[1], bl = Math.hypot(bx, by);
          if (bl < 1e-9) continue;
          const v = segStart(b);
          grow(s, v[0] + bx / bl * hw * ratio, v[1] + by / bl * hw * ratio);
        }
      }
    }
  }
  return { geom: g, stroke: s };
}
function segTangent(s, atEnd) {
  if (s.t === 'L') { const dx = s.x1 - s.x0, dy = s.y1 - s.y0, L = Math.hypot(dx, dy) || 1; return [dx / L, dy / L]; }
  const a = atEnd ? s.a1 : s.a0, k = s.ccw ? 1 : -1;
  return [-Math.sin(a) * k, Math.cos(a) * k];
}

// Draw one item's outline into a canvas context whose transform maps
// millimetres (Y up) to pixels.
function tracePath(ctx, it) {
  ctx.beginPath();
  for (const c of it.cycles) {
    const st = segStart(c.segs[0]);
    ctx.moveTo(st[0], st[1]);
    for (const s of c.segs) {
      if (s.t === 'L') ctx.lineTo(s.x1, s.y1);
      else ctx.arc(s.cx, s.cy, s.r, s.a0, s.a1, !s.ccw);
    }
    if (it.closed) ctx.closePath();
  }
}
function paintItem(ctx, it, opts) {
  const rec = it.rec, o = opts || {};
  tracePath(ctx, it);
  const alpha = rec.opacity === undefined ? 1 : rec.opacity;
  if (it.kind === 'face' && rec.fill !== 'none') {
    ctx.globalAlpha = alpha * (o.fillAlpha === undefined ? 1 : o.fillAlpha);
    ctx.fillStyle = rec.fill;
    ctx.fill('evenodd');
  }
  if (!o.noStroke && rec.stroke !== 'none' && rec.sw > 0) {
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = rec.stroke;
    ctx.lineWidth = rec.sw;
    ctx.lineJoin = rec.join; ctx.lineCap = rec.cap; ctx.miterLimit = 4;
    ctx.setLineDash(dashArray(rec) || []);
    ctx.stroke();
    ctx.setLineDash([]);
  }
  ctx.globalAlpha = 1;
}

// ---------------------------------------------------------------------
// SVG. One <path> per shape, presentation attributes only, physical
// size on the root element (1 user unit = 1 mm).
// ---------------------------------------------------------------------
function svgNum(v) {
  let s = v.toFixed(4);
  s = s.replace(/0+$/, '').replace(/\.$/, '');
  return s === '-0' ? '0' : s;
}
function buildSVG(items, opts) {
  opts = opts || {};
  if (!items.length) return null;
  const b = itemsBounds(items);
  const bb = opts.frame === 'geometry' ? b.geom : b.stroke;
  const W = bb[2] - bb[0], H = bb[3] - bb[1];
  const X = x => svgNum(x - bb[0]), Y = y => svgNum(bb[3] - y);
  const arcTo = (s, a0, a1) => {
    // world counter-clockwise shows as sweep-flag 0 once Y is flipped
    const ex = s.cx + s.r * Math.cos(a1), ey = s.cy + s.r * Math.sin(a1);
    if (opts.bezier) {
      const n = Math.max(1, Math.ceil(Math.abs(a1 - a0) / (Math.PI / 4) - 1e-9));
      let d = '';
      const da = (a1 - a0) / n, k = 4 / 3 * Math.tan(da / 4);
      for (let i = 0; i < n; i++) {
        const t0 = a0 + i * da, t1 = t0 + da;
        const x0 = s.cx + s.r * Math.cos(t0), y0 = s.cy + s.r * Math.sin(t0);
        const x1 = s.cx + s.r * Math.cos(t1), y1 = s.cy + s.r * Math.sin(t1);
        d += 'C' + X(x0 - k * s.r * Math.sin(t0)) + ' ' + Y(y0 + k * s.r * Math.cos(t0)) + ' ' +
          X(x1 + k * s.r * Math.sin(t1)) + ' ' + Y(y1 - k * s.r * Math.cos(t1)) + ' ' + X(x1) + ' ' + Y(y1);
      }
      return d;
    }
    const large = Math.abs(a1 - a0) > Math.PI ? 1 : 0, sweep = a1 > a0 ? 0 : 1;
    return 'A' + svgNum(s.r) + ' ' + svgNum(s.r) + ' 0 ' + large + ' ' + sweep + ' ' + X(ex) + ' ' + Y(ey);
  };
  const out = [];
  out.push('<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="' + svgNum(W) + 'mm" height="' + svgNum(H) +
    'mm" viewBox="0 0 ' + svgNum(W) + ' ' + svgNum(H) + '"' + (opts.frame === 'geometry' ? ' overflow="visible"' : '') + '>');
  let n = 0;
  for (const it of items) {
    const rec = it.rec;
    let d = '';
    for (const c of it.cycles) {
      const st = segStart(c.segs[0]);
      d += 'M' + X(st[0]) + ' ' + Y(st[1]);
      const last = c.segs.length - 1;
      for (let i = 0; i <= last; i++) {
        const s = c.segs[i];
        // Z draws the closing edge, so a final straight segment back to the start is left out
        if (s.t === 'L' && it.closed && i === last && i > 0 && X(s.x1) === X(st[0]) && Y(s.y1) === Y(st[1])) continue;
        if (s.t === 'L') d += 'L' + X(s.x1) + ' ' + Y(s.y1);
        else if (Math.abs(s.a1 - s.a0) > TAU - 1e-9) {
          const am = (s.a0 + s.a1) / 2;
          d += arcTo(s, s.a0, am) + arcTo(s, am, s.a1);
        } else d += arcTo(s, s.a0, s.a1);
      }
      if (it.closed) d += 'Z';
    }
    const fill = it.kind === 'face' ? rec.fill : 'none';
    let a = ' id="shape-' + (++n) + '" d="' + d + '" fill="' + fill + '"';
    if (fill !== 'none') {
      a += ' fill-rule="evenodd"';
      if (rec.opacity < 1) a += ' fill-opacity="' + svgNum(rec.opacity) + '"';
    }
    if (rec.stroke !== 'none' && rec.sw > 0) {
      a += ' stroke="' + rec.stroke + '" stroke-width="' + svgNum(rec.sw) + '" stroke-linejoin="' + rec.join +
        '" stroke-linecap="' + rec.cap + '" stroke-miterlimit="4"';
      const da = dashArray(rec);
      if (da) a += ' stroke-dasharray="' + da.map(svgNum).join(' ') + '"';
      if (rec.opacity < 1) a += ' stroke-opacity="' + svgNum(rec.opacity) + '"';
    } else a += ' stroke="none"';
    out.push('  <path' + a + '/>');
  }
  out.push('</svg>');
  return { svg: out.join('\n') + '\n', width: W, height: H, geomW: b.geom[2] - b.geom[0], geomH: b.geom[3] - b.geom[1], bounds: bb };
}

// ---------------------------------------------------------------------
// PNG physical size: insert a pHYs chunk (pixels per metre) after IHDR.
// ---------------------------------------------------------------------
let CRC_TABLE = null;
function crc32(bytes, start, end) {
  if (!CRC_TABLE) {
    CRC_TABLE = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      CRC_TABLE[n] = c >>> 0;
    }
  }
  let c = 0xFFFFFFFF;
  for (let i = start; i < end; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function pngSetDpi(bytes, dpi) {
  if (bytes.length < 33 || bytes[0] !== 0x89 || bytes[1] !== 0x50) return bytes;
  const ppm = Math.round(dpi / 0.0254);
  const chunk = new Uint8Array(21);
  const dv = new DataView(chunk.buffer);
  dv.setUint32(0, 9);
  chunk.set([0x70, 0x48, 0x59, 0x73], 4);
  dv.setUint32(8, ppm); dv.setUint32(12, ppm); chunk[16] = 1;
  dv.setUint32(17, crc32(chunk, 4, 17));
  // strip any existing pHYs chunk
  const parts = [bytes.subarray(0, 33), chunk];
  let p = 33;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  while (p + 12 <= bytes.length) {
    const len = view.getUint32(p);
    const type = String.fromCharCode(bytes[p + 4], bytes[p + 5], bytes[p + 6], bytes[p + 7]);
    if (type !== 'pHYs') parts.push(bytes.subarray(p, p + 12 + len));
    p += 12 + len;
  }
  let total = 0;
  for (const a of parts) total += a.length;
  const outB = new Uint8Array(total);
  let o = 0;
  for (const a of parts) { outB.set(a, o); o += a.length; }
  return outB;
}
