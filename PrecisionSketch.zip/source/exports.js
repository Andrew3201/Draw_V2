return {
  UNITS, TAU, TOL, fmtNum, fmtLen, normAng, wrapPi, evalExpr,
  newDoc, addPoint, addLine, addCircle, addArc, addRect, addCon, entPoints, kindOf, isDim, conValid, conPoints,
  entRadius, deleteItems, entityLabel, describeCon, makeConstraint, measureCon, distRefs, CON_LABEL,
  buildSystem, writeBack, solveSystem, trySolve, applyChange, setDimValue, restoreInto, clashList,
  analyze, docDof, addConIfUseful, addDimension, beginDrag, dragStep, lmSolve, makeLocal, evalLocal,
  serialize, parseDoc,
  computeTopology, syncShapes, shapeCycles, drawList, hitFace, ownerFace, inCycles, cyclesDist, itemsBounds,
  tracePath, paintItem, dashArray, buildSVG, pngSetDpi, segStart, segEnd, DEFAULT_STYLE
};
