// Build: one self-contained HTML page, plus a CommonJS copy of the core for tests.
const fs = require('fs');
const rd = f => fs.readFileSync(__dirname + '/src/' + f, 'utf8');
const core = "const PS = (function () {\n'use strict';\n" + rd('core.js') + '\n' + rd('topo.js') + '\n' + rd('exports.js') + '\n})();\n';
fs.writeFileSync(__dirname + '/dist/core.cjs', core + 'module.exports = PS;\n');
if (fs.existsSync(__dirname + '/src/body.html')) {
  const html = rd('body.html')
    .replace('/*__CSS__*/', () => rd('style.css'))
    .replace('/*__CORE__*/', () => core)
    .replace('/*__UI__*/', () => rd('ui.js'));
  fs.writeFileSync(__dirname + '/dist/precisionsketch.html', html);
  console.log('html', (html.length / 1024).toFixed(1) + ' KB');
}
console.log('core ok');
