// Wrap the page content in the same skeleton the publisher adds, for local testing.
const fs = require('fs');
const body = fs.readFileSync(__dirname + '/../dist/precisionsketch.html', 'utf8');
const reset = ':root{color-scheme:light;padding:env(safe-area-inset-top,0px) 0 env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui,sans-serif;background:#fafafa}img{max-width:100%}[hidden]{display:none!important}';
fs.writeFileSync(__dirname + '/../dist/local.html', '<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>' + reset + '</style></head><body>' + body + '</body></html>');
