const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path'), fs = require('fs');
const SHOTS = process.env.SHOTS || '/tmp/claude-0/-home-claude/8dd0c3c1-a53d-531a-8511-e881a85d4397/scratchpad';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL: ' + m); } };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 820 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../dist/local.html'));
  await page.waitForTimeout(300);
  const S = async (x, y) => page.evaluate(([x, y]) => { const s = window.__ps, r = document.getElementById('cv').getBoundingClientRect(); return [r.left + (x - s.view.cx) * s.view.zoom + s.w / 2, r.top + s.h / 2 - (y - s.view.cy) * s.view.zoom]; }, [x, y]);
  const click = async (x, y, o) => { const p = await S(x, y); const sh = o && o.modifiers; if (sh) await page.keyboard.down('Shift'); await page.mouse.move(p[0], p[1]); await page.mouse.click(p[0], p[1]); if (sh) await page.keyboard.up('Shift'); await page.waitForTimeout(30); };
  const move = async (x, y) => { const p = await S(x, y); await page.mouse.move(p[0], p[1]); await page.waitForTimeout(20); };
  const drag = async (x0, y0, x1, y1, n) => { let p = await S(x0, y0); await page.mouse.move(p[0], p[1]); await page.mouse.down(); for (let i = 1; i <= (n || 8); i++) { p = await S(x0 + (x1 - x0) * i / (n || 8), y0 + (y1 - y0) * i / (n || 8)); await page.mouse.move(p[0], p[1]); await page.waitForTimeout(8); } await page.mouse.up(); await page.waitForTimeout(60); };
  const key = async k => { await page.keyboard.press(k); await page.waitForTimeout(30); };
  const st = (f, a) => page.evaluate(f, a);
  const dof = () => page.evaluate(() => document.getElementById('dof').textContent);
  const typeDim = async v => { await page.waitForSelector('#dimedit:not([hidden])', { timeout: 2000 }); await page.keyboard.press('Control+A'); await page.keyboard.type(String(v)); await page.keyboard.press('Enter'); await page.waitForTimeout(60); };
  const shot = n => page.screenshot({ path: SHOTS + '/' + n + '.png' });
  const toastText = () => page.evaluate(() => { const t = document.getElementById('toast'); return t.hidden ? '' : t.textContent; });

  console.log('# example: drag the under-defined hole, hole to shape, styling');
  // the right hole can only slide horizontally (equal radius + horizontal with the left one)
  const c2 = await st(() => { const d = window.__ps.doc, cs = Object.values(d.entities).filter(e => e.type === 'circle'); return [d.points[cs[1].c].x, d.points[cs[1].c].y, cs[1].r]; });
  await drag(c2[0], c2[1], c2[0] + 8, c2[1] + 9);
  const c2b = await st(() => { const d = window.__ps.doc, cs = Object.values(d.entities).filter(e => e.type === 'circle'); return [d.points[cs[1].c].x, d.points[cs[1].c].y, cs[1].r]; });
  ok(Math.abs(c2b[0] - (c2[0] + 8)) < 0.05 && Math.abs(c2b[1] - 20) < 1e-7 && Math.abs(c2b[2] - 6) < 1e-7, 'under-defined hole slides along its one free direction only: ' + c2b);
  ok(await st(() => document.getElementById('example').hidden), 'example banner disappears after the first edit');
  // click the hole -> "Hole" panel -> make it a separate shape with its own fill
  await key('Escape');
  await click(c2b[0], c2b[1] + 3);
  ok((await page.textContent('#right h2')).trim() === 'Hole', 'clicking inside the inner loop selects it as a hole: ' + await page.textContent('#right h2'));
  await page.selectOption('#f-role', 'own');
  await page.waitForTimeout(80);
  ok(await st(() => window.__ps.items.length === 2 && window.__ps.items.find(i => i.rec.ents.length === 4).cycles.length === 2), 'separate shape: plate keeps one hole, the other loop is its own shape');
  await page.click('[data-swatch="#e0a300"][data-style="fill"]');
  await page.waitForTimeout(80);
  await page.fill('#f-sw', '1 pt'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  ok(await st(() => { const it = window.__ps.items.find(i => i.rec.ents.length === 1); return it.rec.fill === '#e0a300' && Math.abs(it.rec.sw - 25.4 / 72) < 1e-9; }), 'fill and outline width (1 pt) applied to the inner shape');
  await page.selectOption('#f-dash', 'dash'); await page.waitForTimeout(60);
  await page.fill('#f-flhex', '#0a8'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  ok(await st(() => window.__ps.items.find(i => i.rec.ents.length === 1).rec.fill === '#00aa88'), 'hex entry accepts short form');
  await key('Tab');
  await page.waitForTimeout(100);
  await shot('20-clean-two-shapes');
  const pxAt = await S(c2b[0], c2b[1]);
  const rgb = await page.evaluate(([sx, sy]) => { const cv = document.getElementById('cv'), r = cv.getBoundingClientRect(), k = cv.width / r.width; const d = cv.getContext('2d').getImageData(Math.round((sx - r.left) * k), Math.round((sy - r.top) * k), 1, 1).data; return [d[0], d[1], d[2]]; }, pxAt);
  ok(rgb[0] < 30 && rgb[1] > 150 && rgb[2] > 110 && rgb[2] < 160, 'the separate inner shape is drawn in front of the plate with its own fill: ' + rgb);
  // send to back hides it behind the (solid there) plate? plate still has the first hole only
  await key('Tab');
  // dimension drag keeps the dimension, moves the text
  const dr = await st(() => { const s = window.__ps, r = s.dimRects.find(r => s.doc.constraints[r.cid].value === 70), b = document.getElementById('cv').getBoundingClientRect(); return [b.left + r.x + r.w / 2, b.top + r.y + r.h / 2, r.cid]; });
  await page.mouse.move(dr[0], dr[1]); await page.mouse.down(); await page.mouse.move(dr[0] + 30, dr[1] + 40, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(60);
  const dr2 = await st(cid => { const s = window.__ps, r = s.dimRects.find(r => r.cid === cid), b = document.getElementById('cv').getBoundingClientRect(); return [b.left + r.x + r.w / 2, b.top + r.y + r.h / 2]; }, dr[2]);
  ok(Math.abs(dr2[0] - dr[0] - 30) < 2 && Math.abs(dr2[1] - dr[1] - 40) < 2, 'dimension text can be dragged to a new place');
  // dimension value through the properties panel, with units
  await page.mouse.click(dr2[0], dr2[1]); await page.waitForTimeout(60);
  await page.fill('#f-dimv', '3 in'); await page.keyboard.press('Enter'); await page.waitForTimeout(100);
  ok(await st(() => { const d = window.__ps.doc; let mx = 0; for (const k in d.points) if (!d.points[k].ref) mx = Math.max(mx, d.points[k].x); return Math.abs(mx - 76.2) < 1e-7; }), 'panel accepts "3 in" in a mm document (76.2 mm)');
  // reference toggle
  await page.check('#f-driven'); await page.waitForTimeout(80);
  ok((await dof()).includes('2 degrees'), 'making the width a reference frees one DOF: ' + await dof());
  await page.uncheck('#f-driven'); await page.waitForTimeout(80);
  ok((await dof()).includes('1 degree'), 'and driving again removes it: ' + await dof());

  console.log('# new sketch: preselect + constraint, inference, joining by drag');
  await page.click('#btnFile'); await page.click('[data-m="new"]'); await page.waitForTimeout(100);
  await st(() => { window.__ps.view = { cx: 30, cy: 20, zoom: 9 }; });
  // two free lines
  await key('l');
  await page.keyboard.down('Shift');
  await click(5, 5); await click(30, 9); await key('Escape');
  await click(8, 20); await click(28, 33); await key('Escape');
  await page.keyboard.up('Shift');
  await key('Escape');
  ok(await st(() => Object.keys(window.__ps.doc.constraints).length) === 0, 'holding Shift suppresses inference');
  // select both, press the parallel button
  await click(17.5, 7); await click(18, 26.5, { modifiers: ['Shift'] });
  ok(await st(() => window.__ps.sel.size) === 2, 'two lines selected');
  await page.click('[data-tool="parallel"]'); await page.waitForTimeout(80);
  let ang = await st(() => { const d = window.__ps.doc, ls = Object.values(d.entities).filter(e => !e.ref); return ls.map(l => Math.atan2(d.points[l.p2].y - d.points[l.p1].y, d.points[l.p2].x - d.points[l.p1].x)); });
  ok(Math.abs(Math.sin(ang[0] - ang[1])) < 1e-9, 'parallel applied to the preselected lines');
  ok(await st(() => window.__ps.tool) === 'select', 'tool stays on Select after applying to a selection');
  // perpendicular now clashes
  const snap = await st(() => JSON.stringify(window.__ps.doc));
  await click(17.5, await st(() => { const d = window.__ps.doc, l = Object.values(d.entities).filter(e => !e.ref)[0]; const a = d.points[l.p1], b = d.points[l.p2]; return a.y + (17.5 - a.x) * (b.y - a.y) / (b.x - a.x); }));
  const l2 = await st(() => { const d = window.__ps.doc, l = Object.values(d.entities).filter(e => !e.ref)[1]; const a = d.points[l.p1], b = d.points[l.p2]; return [(a.x + b.x) / 2, (a.y + b.y) / 2]; });
  await click(l2[0], l2[1], { modifiers: ['Shift'] });
  await key('Shift+L'); await page.waitForTimeout(100);
  ok(/Not applied/.test(await toastText()) && /Parallel/.test(await toastText()), 'conflict message names the clashing constraint: ' + await toastText());
  ok(await st(() => JSON.stringify(window.__ps.doc)) === snap, 'sketch left exactly as it was');
  await shot('21-conflict');
  // horizontal on line 1 via tool mode (H then click)
  await key('Escape'); await key('h');
  await click(l2[0], l2[1]);
  ang = await st(() => { const d = window.__ps.doc, ls = Object.values(d.entities).filter(e => !e.ref); return ls.map(l => Math.atan2(d.points[l.p2].y - d.points[l.p1].y, d.points[l.p2].x - d.points[l.p1].x)); });
  ok(Math.abs(Math.sin(ang[0])) < 1e-9 && Math.abs(Math.sin(ang[1])) < 1e-9, 'horizontal tool: both lines horizontal (through parallel)');
  // drag an end of line 2 onto an end of line 1: they join
  await key('Escape');
  const ends = await st(() => { const d = window.__ps.doc, ls = Object.values(d.entities).filter(e => !e.ref); return { a: d.points[ls[0].p2], b: d.points[ls[1].p1] }; });
  await drag(ends.b.x, ends.b.y, ends.a.x + 0.3, ends.a.y - 0.2, 10);
  ok(await st(() => Object.values(window.__ps.doc.constraints).filter(c => c.type === 'coincident').length) === 1, 'dragging a point onto another joins them with a coincident constraint');
  // angle dimension between a new line and the first
  await key('l');
  await click(5, 30); await page.keyboard.down('Shift'); await click(22, 44); await page.keyboard.up('Shift'); await key('Escape'); await key('Escape');
  await key('d');
  const l1m = await st(() => { const d = window.__ps.doc, l = Object.values(d.entities).filter(e => !e.ref)[0]; const a = d.points[l.p1], b = d.points[l.p2]; return [(a.x + b.x) / 2, (a.y + b.y) / 2]; });
  await click(l1m[0], l1m[1]); await click(13.5, 37);
  await click(40, 30);
  await typeDim(30);
  const a3 = await st(() => { const d = window.__ps.doc, ls = Object.values(d.entities).filter(e => !e.ref); const f = l => Math.atan2(d.points[l.p2].y - d.points[l.p1].y, d.points[l.p2].x - d.points[l.p1].x) * 180 / Math.PI; return [f(ls[0]), f(ls[2])]; });
  ok(Math.abs(Math.abs(a3[1] - a3[0]) - 30) < 1e-6 || Math.abs(Math.abs(a3[1] - a3[0]) - 150) < 1e-6, 'angle dimension set to 30 degrees: ' + a3);
  await key('Escape'); await key('f'); await page.waitForTimeout(80);
  await shot('22-angle');
  // tangent inference: line from a circle's rim
  await page.click('#btnFile'); await page.click('[data-m="new"]'); await page.waitForTimeout(100);
  await st(() => { window.__ps.view = { cx: 30, cy: 20, zoom: 9 }; });
  await key('c'); await click(20, 20); await click(30, 20);
  await key('l'); await click(40, 40); await move(17, 31); await move(15.7, 29.4);
  const tin = await st(() => JSON.stringify(window.__ps.infer));
  await click(15.7, 29.4); await key('Escape'); await key('Escape');
  const tcon = await st(() => Object.values(window.__ps.doc.constraints).map(c => c.type).sort().join());
  ok(/tangent/.test(tcon) && /pointOn/.test(tcon), 'line ending on a circle near tangency gets tangent + coincident: ' + tcon + ' ' + tin);
  // circle rim tangent to the X axis by inference, construction toggle, coordinates edit
  await key('c'); await click(50, 12); await move(50, 0.4); await click(50, 0.4); await key('Escape');
  ok(await st(() => Object.values(window.__ps.doc.constraints).filter(c => c.type === 'tangent' && c.refs.indexOf('AX') >= 0).length) === 1, 'circle drawn up to the X axis becomes tangent to it');
  await click(50 + 12 * Math.cos(0.5), 12 + 12 * Math.sin(0.5));
  await key('q');
  ok(await st(() => Object.values(window.__ps.doc.entities).filter(e => e.construction && !e.ref).length) === 1, 'Q makes the selected circle construction geometry');
  ok(await st(() => window.__ps.items.length) === 2, 'construction circle forms no shape');
  await key('q');
  // coordinate entry on the centre point
  await click(50, 12);
  await page.fill('#f-px', '55'); await page.keyboard.press('Enter'); await page.waitForTimeout(100);
  ok(await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).filter(e => e.type === 'circle')[1]; return Math.abs(d.points[c.c].x - 55) < 1e-6; }), 'typing an exact X coordinate moves the point');

  console.log('# files and clipboard');
  // save: outside a viewer this is a normal download
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 5000 }), (async () => { await page.click('#btnFile'); await page.click('[data-m="save"]'); })()]);
  const saved = fs.readFileSync(await dl.path(), 'utf8');
  ok(dl.suggestedFilename() === 'drawing.precisionsketch.json' && JSON.parse(saved).app === 'PrecisionSketch', 'Save writes a PrecisionSketch JSON file');
  // export SVG download
  await page.click('#btnExport'); await page.waitForSelector('#x-go');
  const [dl2] = await Promise.all([page.waitForEvent('download', { timeout: 5000 }), page.click('#x-go')]);
  const svg = fs.readFileSync(await dl2.path(), 'utf8');
  ok(dl2.suggestedFilename() === 'drawing.svg' && svg.startsWith('<svg xmlns') && (svg.match(/<path /g) || []).length === await st(() => window.__ps.items.length), 'Export saves an SVG with one path per shape');
  // PNG export
  await page.click('#btnExport'); await page.waitForSelector('#x-go'); await page.selectOption('#x-fmt', 'png');
  const [dl3] = await Promise.all([page.waitForEvent('download', { timeout: 5000 }), page.click('#x-go')]);
  const png = fs.readFileSync(await dl3.path());
  ok(png[1] === 0x50 && png.slice(37, 41).toString() === 'pHYs' && png.readUInt32BE(41) === 11811, 'Export saves a PNG that records 300 dpi');
  fs.writeFileSync(SHOTS + '/export.png', png); fs.writeFileSync(SHOTS + '/export.svg', svg);
  // open: new drawing, then load the saved file back
  await page.click('#btnFile'); await page.click('[data-m="new"]'); await page.waitForTimeout(80);
  const tmp = SHOTS + '/roundtrip.precisionsketch.json';
  fs.writeFileSync(tmp, saved);
  await page.setInputFiles('#fileIn', tmp); await page.waitForTimeout(250);
  ok(await st(() => Object.values(window.__ps.doc.entities).filter(e => !e.ref).length) === 3, 'Open reads the file back');
  await page.setInputFiles('#fileIn', { name: 'bad.json', mimeType: 'application/json', buffer: Buffer.from('{"x":1}') }); await page.waitForTimeout(200);
  ok(/not a PrecisionSketch file/.test(await toastText()), 'a foreign file is refused with a clear message');
  // clipboard blocked -> fallback dialog
  await page.evaluate(() => { navigator.clipboard.write = () => Promise.reject(new Error('blocked')); });
  await page.click('#btnCopy'); await page.waitForSelector('.dialog img', { timeout: 4000 });
  ok(/not allowed to write images/.test(await page.textContent('.dialog')), 'blocked clipboard shows the fallback dialog with the image');
  await page.waitForTimeout(150);
  await shot('23-copy-fallback');
  await page.click('#dlgClose');
  // clipboard allowed -> success toast
  await page.evaluate(() => { window.__clip = null; navigator.clipboard.write = async items => { window.__clip = items[0].types.slice(); }; });
  await page.click('#btnCopy'); await page.waitForTimeout(400);
  ok(/copied as an image/.test(await toastText()) && (await st(() => window.__clip || [])).indexOf('image/png') >= 0, 'clipboard write succeeds when allowed: ' + await toastText());
  // autosave survives a reload
  await page.waitForTimeout(600);
  await page.reload(); await page.waitForTimeout(400);
  ok(await st(() => Object.values(window.__ps.doc.entities).filter(e => !e.ref).length) === 3 && await st(() => document.getElementById('example').hidden), 'drawing is restored from autosave after a reload');
  // shortcuts dialog
  await page.click('#btnFile'); await page.click('[data-m="keys"]');
  ok(/Perpendicular/.test(await page.textContent('.dialog')), 'shortcut list opens');
  await key('Escape');
  ok(errors.length === 0, 'no script errors: ' + errors.join(' | '));
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  await browser.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
