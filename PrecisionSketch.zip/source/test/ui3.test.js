const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL: ' + m); } };
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 1360, height: 820 } })).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('file://' + path.resolve(__dirname, '../dist/local.html'));
  await page.waitForTimeout(300);
  const S = async (x, y) => page.evaluate(([x, y]) => { const s = window.__ps, r = document.getElementById('cv').getBoundingClientRect(); return [r.left + (x - s.view.cx) * s.view.zoom + s.w / 2, r.top + s.h / 2 - (y - s.view.cy) * s.view.zoom]; }, [x, y]);
  const W = async (sx, sy) => page.evaluate(([sx, sy]) => { const s = window.__ps, r = document.getElementById('cv').getBoundingClientRect(); return [(sx - r.left - s.w / 2) / s.view.zoom + s.view.cx, (s.h / 2 - (sy - r.top)) / s.view.zoom + s.view.cy]; }, [sx, sy]);
  const click = async (x, y) => { const p = await S(x, y); await page.mouse.move(p[0], p[1]); await page.mouse.click(p[0], p[1]); await page.waitForTimeout(30); };
  const drag = async (x0, y0, x1, y1, btn) => { let p = await S(x0, y0); await page.mouse.move(p[0], p[1]); await page.mouse.down({ button: btn || 'left' }); for (let i = 1; i <= 8; i++) { p = await S(x0 + (x1 - x0) * i / 8, y0 + (y1 - y0) * i / 8); await page.mouse.move(p[0], p[1]); await page.waitForTimeout(8); } await page.mouse.up({ button: btn || 'left' }); await page.waitForTimeout(60); };
  const key = async k => { await page.keyboard.press(k); await page.waitForTimeout(30); };
  const st = (f, a) => page.evaluate(f, a);
  // zoom about the cursor: the world point under the cursor stays put
  const p = await S(35, 20);
  await page.mouse.move(p[0], p[1]);
  const z0 = await st(() => window.__ps.view.zoom);
  await page.mouse.wheel(0, -400); await page.waitForTimeout(80);
  const w1 = await W(p[0], p[1]), z1 = await st(() => window.__ps.view.zoom);
  ok(z1 > z0 * 1.5 && Math.abs(w1[0] - 35) < 0.1 && Math.abs(w1[1] - 20) < 0.1, 'scroll zooms about the cursor: ' + z0.toFixed(2) + ' -> ' + z1.toFixed(2));
  await page.mouse.wheel(0, 400); await page.waitForTimeout(80);
  // right-drag pans
  const v0 = await st(() => ({ ...window.__ps.view }));
  await page.mouse.move(p[0], p[1]); await page.mouse.down({ button: 'right' }); await page.mouse.move(p[0] + 90, p[1] + 40, { steps: 4 }); await page.mouse.up({ button: 'right' }); await page.waitForTimeout(50);
  const v1 = await st(() => ({ ...window.__ps.view }));
  ok(Math.abs((v0.cx - v1.cx) * v1.zoom - 90) < 1 && Math.abs((v1.cy - v0.cy) * v1.zoom - 40) < 1, 'right-drag pans the view');
  ok(await st(() => Object.keys(window.__ps.doc.entities).length) === 8, 'panning changed nothing in the sketch');
  // space + left drag pans too
  await page.keyboard.down('Space'); await page.mouse.move(p[0], p[1]); await page.mouse.down(); await page.mouse.move(p[0] - 90, p[1] - 40, { steps: 4 }); await page.mouse.up(); await page.keyboard.up('Space'); await page.waitForTimeout(50);
  const v2 = await st(() => ({ ...window.__ps.view }));
  ok(Math.abs(v2.cx - v0.cx) < 0.5 && Math.abs(v2.cy - v0.cy) < 0.5, 'Space + drag pans back');
  // blank sketch, press-drag-release rectangle and circle
  await page.click('#btnFile'); await page.click('[data-m="new"]'); await page.waitForTimeout(80);
  await st(() => { window.__ps.view = { cx: 30, cy: 20, zoom: 9 }; });
  await key('r'); await drag(5, 5, 25, 18);
  ok(await st(() => Object.values(window.__ps.doc.entities).filter(e => !e.ref).length) === 4, 'press, drag, release draws a rectangle');
  await key('c'); await drag(40, 25, 48, 25);
  ok(await st(() => { const c = Object.values(window.__ps.doc.entities).find(e => e.type === 'circle'); return c && Math.abs(c.r - 8) < 0.2; }), 'press, drag, release draws a circle');
  // arc: start on the rectangle's top-right corner (joins it), then drag the arc to change its radius
  await key('a'); await click(25, 18); await click(25, 34); await click(33, 26); await key('Escape');
  const arc = await st(() => { const d = window.__ps.doc, a = Object.values(d.entities).find(e => e.type === 'arc'); return a && { s: d.points[a.s], e: d.points[a.e], c: d.points[a.c], n: Object.values(d.constraints).filter(c => c.type === 'coincident').length }; });
  ok(arc && arc.n === 5, 'arc start joined to the rectangle corner by inference');
  const r0 = Math.hypot(arc.s.x - arc.c.x, arc.s.y - arc.c.y);
  await drag(arc.c.x + r0, arc.c.y, arc.c.x + r0 + 6, arc.c.y);
  const arc2 = await st(() => { const d = window.__ps.doc, a = Object.values(d.entities).find(e => e.type === 'arc'); return { s: d.points[a.s], e: d.points[a.e], c: d.points[a.c] }; });
  const r1 = Math.hypot(arc2.s.x - arc2.c.x, arc2.s.y - arc2.c.y), r1e = Math.hypot(arc2.e.x - arc2.c.x, arc2.e.y - arc2.c.y);
  ok(Math.abs(r1 - r1e) < 1e-7 && Math.abs(arc2.s.x - 25) < 1e-6 && Math.abs(arc2.s.y - 18) < 1e-6 && Math.abs(arc2.c.x + r1 - (arc.c.x + r0 + 6)) < 0.3, 'dragging the arc bulges it through the cursor while its ends stay: r ' + r0.toFixed(2) + ' -> ' + r1.toFixed(2));
  // point-to-line and parallel-line distance dimensions
  await key('d');
  await click(40, 25); await click(15, 5); await click(45, 12);
  await page.waitForSelector('#dimedit:not([hidden])'); await page.keyboard.press('Control+A'); await page.keyboard.type('22'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  ok(await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).find(e => e.type === 'circle'), l = Object.values(d.entities).filter(e => e.type === 'line' && !e.ref)[0]; return Math.abs(d.points[c.c].y - d.points[l.p1].y - 22) < 1e-7 && Math.abs(d.points[l.p1].y - d.points[l.p2].y) < 1e-9; }), 'point-to-line distance puts the circle centre 22 above the bottom side');
  await click(5, 11); await click(25, 11.5); await click(15, 24);
  await page.waitForSelector('#dimedit:not([hidden])'); await page.keyboard.press('Control+A'); await page.keyboard.type('31.5'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  ok(await st(() => { const d = window.__ps.doc; const ls = Object.values(d.entities).filter(e => e.type === 'line' && !e.ref); return Math.abs(Math.abs(d.points[ls[1].p1].x - d.points[ls[3].p1].x) - 31.5) < 1e-7; }), 'two parallel lines give a distance dimension (31.5)');
  // invalid entry keeps the editor open
  await key('Escape');
  const dp = await st(() => { const s = window.__ps, r = s.dimRects[0], b = document.getElementById('cv').getBoundingClientRect(); return [b.left + r.x + r.w / 2, b.top + r.y + r.h / 2]; });
  await page.mouse.dblclick(dp[0], dp[1]); await page.waitForSelector('#dimedit:not([hidden])');
  await page.keyboard.press('Control+A'); await page.keyboard.type('12 +'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  ok(await st(() => !document.getElementById('dimedit').hidden && /ends early/.test(document.getElementById('toast').textContent)), 'a bad expression is explained and the box stays open');
  await key('Escape');
  ok(await st(() => document.getElementById('dimedit').hidden), 'Esc closes the dimension box');
  ok(errors.length === 0, 'no script errors: ' + errors.join(' | '));
  console.log(pass + ' passed, ' + fail + ' failed');
  await browser.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
