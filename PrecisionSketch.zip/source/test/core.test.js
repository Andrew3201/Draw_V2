// Headless checks of the solver, DOF analysis, topology and exporters.
const PS = require('../dist/core.cjs');
let pass = 0, fail = 0;
function ok(cond, msg) { if (cond) pass++; else { fail++; console.log('  FAIL: ' + msg); } }
function near(a, b, tol, msg) { ok(Math.abs(a - b) <= tol, msg + ' (got ' + a + ', want ' + b + ')'); }
function section(n) { console.log('\n# ' + n); }
const E = (d, id) => d.entities[id], Pt = (d, id) => d.points[id];

// dense Jacobian of the hard equations
function denseJ(sys) {
  const m = sys.eqs.length, n = sys.nVars, J = [];
  for (const e of sys.eqs) {
    const row = new Float64Array(n);
    e.ev(sys.P, sys.G);
    for (const p of e.params) { const v = sys.varOf[p]; if (v >= 0) row[v] = sys.G[p]; sys.G[p] = 0; }
    J.push(row);
  }
  return { J, m, n };
}
function denseRank(J, m, n) {
  const A = J.map(r => Float64Array.from(r));
  let rank = 0, big = 0;
  for (const r of A) for (const v of r) big = Math.max(big, Math.abs(v));
  const usedRow = new Uint8Array(m), usedCol = new Uint8Array(n);
  for (; ;) {
    let bv = 0, bi = -1, bj = -1;
    for (let i = 0; i < m; i++) if (!usedRow[i]) for (let j = 0; j < n; j++) if (!usedCol[j] && Math.abs(A[i][j]) > bv) { bv = Math.abs(A[i][j]); bi = i; bj = j; }
    if (bi < 0 || bv < 1e-7 * Math.max(big, 1e-30)) break;
    usedRow[bi] = usedCol[bj] = 1; rank++;
    for (let i = 0; i < m; i++) {
      if (usedRow[i]) continue;
      const f = A[i][bj] / A[bi][bj];
      if (f !== 0) for (let j = 0; j < n; j++) A[i][j] -= f * A[bi][j];
    }
  }
  return rank;
}
function maxResidual(doc) {
  const sys = PS.buildSystem(doc);
  let m = 0;
  for (const e of sys.eqs) m = Math.max(m, Math.abs(e.ev(sys.P, null)));
  return m;
}
let seed = 7;
function rnd() { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }

// ---------------------------------------------------------------
section('expressions and units');
{
  const ev = (s, o) => PS.evalExpr(s, Object.assign({ units: 'mm', kind: 'length' }, o));
  near(ev('42.5').value, 42.5, 1e-12, 'plain number');
  near(ev('1.5 in').value, 38.1, 1e-12, '1.5 in in a mm document');
  near(ev('40/2 + 3').value, 23, 1e-12, 'arithmetic');
  near(ev('1 in + 5').value, 30.4, 1e-12, 'unit plus document units');
  near(ev('2 * (10 + 2.5) mm').value, 25, 1e-12, 'parentheses with unit');
  near(ev('3', { units: 'in' }).value, 76.2, 1e-12, 'inch document');
  near(ev('72pt').value, 25.4, 1e-12, 'points');
  near(ev('45', { kind: 'angle' }).value, Math.PI / 4, 1e-12, 'degrees');
  near(ev('pi/2 rad + 0', { kind: 'angle' }).ok ? 1 : 0, 0, 1, 'angle expression parses or fails cleanly');
  near(ev('sqrt(16) + 2^3').value, 12, 1e-12, 'functions and powers');
  ok(!ev('4 +').ok, 'incomplete expression rejected');
  ok(!ev('width/2').ok, 'unknown name rejected');
  near(PS.evalExpr('width/2 + 3', { units: 'mm', kind: 'length', vars: { width: { v: 40, L: 1 } } }).value, 23, 1e-12, 'variables');
  ok(PS.fmtNum(40, 2) === '40' && PS.fmtNum(12.5, 2) === '12.5' && PS.fmtNum(1 / 3, 3) === '0.333', 'number formatting');
}

// ---------------------------------------------------------------
section('analytic gradients vs finite differences');
{
  const d = PS.newDoc();
  const l1 = PS.addLine(d, 3, 4, 41, 9), l2 = PS.addLine(d, 12, 30, 47, 52), l3 = PS.addLine(d, -20, 5, -8, 33);
  const l4 = PS.addLine(d, 60, -10, 85, 14), l5 = PS.addLine(d, 5, -30, 33, -41), l6 = PS.addLine(d, 70, 40, 96, 58);
  const c1 = PS.addCircle(d, 20, -12, 7.5), c2 = PS.addCircle(d, 55, 20, 11), c3 = PS.addCircle(d, 80, -30, 5);
  const a1 = PS.addArc(d, -30, -20, -18, -20, -30, -8), a2 = PS.addArc(d, 100, 10, 112, 10, 100, 22);
  const a3 = PS.addArc(d, -50, 40, -40, 40, -50, 50);
  const pt = PS.addLine(d, -5, -5, 2, 17);
  const cons = [
    { type: 'pointOn', refs: [E(d, l3).p1, l1] }, { type: 'pointOn', refs: [E(d, l3).p2, c2] }, { type: 'pointOn', refs: [E(d, pt).p1, a1] },
    { type: 'horizontal', refs: [l5] }, { type: 'vertical', refs: [E(d, l4).p1, E(d, l6).p1] },
    { type: 'parallel', refs: [l1, l2] }, { type: 'perpendicular', refs: [l2, l4] },
    { type: 'tangent', refs: [l1, c1] }, { type: 'tangent', refs: [a1, l5] }, { type: 'tangent', refs: [c2, c3] },
    { type: 'tangent', refs: [c1, a2] }, { type: 'tangent', refs: [a1, a3] },
    { type: 'equal', refs: [l4, l6] }, { type: 'equal', refs: [c1, a2] }, { type: 'equal', refs: [a1, a3] }, { type: 'equal', refs: [c2, c3] },
    { type: 'midpoint', refs: [E(d, pt).p2, l2] },
    { type: 'distance', refs: [l1], mode: 'aligned', value: 37 }, { type: 'distance', refs: [E(d, l1).p1, E(d, l2).p2], mode: 'h', value: 40 },
    { type: 'distance', refs: [E(d, l1).p1, E(d, l2).p2], mode: 'v', value: 44 }, { type: 'distance', refs: [E(d, c1).c, l2], value: 30 },
    { type: 'distance', refs: [l5, l6], value: 80 }, { type: 'distance', refs: ['O', E(d, c3).c], mode: 'aligned', value: 90 },
    { type: 'angle', refs: [l3, l4], rev: [false, true], value: 1.1 }, { type: 'angle', refs: [l6, 'AX'], rev: [true, false], value: 2.4 },
    { type: 'radius', refs: [a3], value: 9 }, { type: 'diameter', refs: [c2], value: 25 }, { type: 'radius', refs: [c3], value: 4 }
  ];
  for (const c of cons) PS.addCon(d, c);
  // shared-endpoint tangency (line meets arc at its end; arc meets arc; line end on circle)
  const l7 = PS.addLine(d, 120, 0, 140, 3), a4 = PS.addArc(d, 141, 20, 140, 3, 158, 21), a5 = PS.addArc(d, 170, 30, 158, 21, 172, 44);
  PS.addCon(d, { type: 'coincident', refs: [E(d, l7).p2, E(d, a4).s] });
  PS.addCon(d, { type: 'coincident', refs: [E(d, a4).e, E(d, a5).s] });
  PS.addCon(d, { type: 'tangent', refs: [l7, a4] });
  PS.addCon(d, { type: 'tangent', refs: [a4, a5] });
  const l8 = PS.addLine(d, 200, 0, 230, 12), c4 = PS.addCircle(d, 205, 14, 14);
  PS.addCon(d, { type: 'pointOn', refs: [E(d, l8).p1, c4] });
  PS.addCon(d, { type: 'tangent', refs: [l8, c4] });
  const sys = PS.buildSystem(d);
  let worst = 0, n = 0;
  for (const e of sys.eqs) {
    e.ev(sys.P, sys.G);
    const g = Array.from(e.params, p => sys.G[p]);
    for (const p of e.params) sys.G[p] = 0;
    e.params.forEach((p, k) => {
      const h = 1e-6, x0 = sys.P[p];
      sys.P[p] = x0 + h; const f1 = e.ev(sys.P, null);
      sys.P[p] = x0 - h; const f0 = e.ev(sys.P, null);
      sys.P[p] = x0;
      const fd = (f1 - f0) / (2 * h), err = Math.abs(fd - g[k]) / (1 + Math.abs(fd));
      if (err > worst) worst = err;
      n++;
    });
    // no gradient leaks outside the declared parameters
  }
  let leak = 0;
  for (const e of sys.eqs) { e.ev(sys.P, sys.G); for (const p of e.params) sys.G[p] = 0; for (let i = 0; i < sys.G.length; i++) leak = Math.max(leak, Math.abs(sys.G[i])); sys.G.fill(0); }
  console.log('  ' + sys.eqs.length + ' equations, ' + n + ' partial derivatives, worst relative error ' + worst.toExponential(2));
  ok(worst < 1e-6, 'gradients match finite differences');
  ok(leak === 0, 'no gradient written outside declared parameters');
}

// ---------------------------------------------------------------
section('Phase 1 acceptance scenario');
let accDoc;
{
  const d = PS.newDoc();
  const R = PS.addRect(d, 12.3, 7.7, 49.1, 36.2);
  const [b, r, t, l] = R.lines;
  ok(PS.trySolve(d).ok, 'rectangle solves');
  near(PS.docDof(d), 4, 0, 'free rectangle has 4 degrees of freedom');
  // dimension 40 x 25
  let id = PS.addDimension(d, { type: 'distance', refs: [b], mode: 'aligned' });
  ok(!d.constraints[id].driven, 'width dimension is driving');
  ok(PS.setDimValue(d, id, 40).ok, 'width set to 40');
  const wId = id;
  id = PS.addDimension(d, { type: 'distance', refs: [l], mode: 'aligned' });
  ok(PS.setDimValue(d, id, 25).ok, 'height set to 25');
  near(PS.docDof(d), 2, 0, 'dimensioned rectangle has 2 DOF (position)');
  // locate from the origin
  const r1 = PS.applyChange(d, doc => PS.addCon(doc, { type: 'coincident', refs: [R.p1, 'O'] }));
  ok(r1.ok, 'corner made coincident with the origin');
  let ana = PS.analyze(PS.buildSystem(d));
  near(ana.dof, 0, 0, 'rectangle fully defined once located from the origin');
  ok(R.lines.every(x => !ana.entFree(x)), 'every side reports fully defined');
  near(Pt(d, E(d, r).p2).x, 40, 1e-8, 'top-right x = 40');
  near(Pt(d, E(d, r).p2).y, 25, 1e-8, 'top-right y = 25');
  // a third length on the already-defined rectangle becomes driven
  id = PS.addDimension(d, { type: 'distance', refs: [t], mode: 'aligned' });
  ok(d.constraints[id].driven === true, 'dimension on defined geometry becomes driven');
  near(PS.measureCon(d, d.constraints[id]), 40, 1e-8, 'driven dimension reads 40');
  const drivenId = id;
  // circle tangent to two sides, diameter 10
  const c = PS.addCircle(d, 9, 8, 6.2);
  ok(PS.applyChange(d, doc => PS.addCon(doc, { type: 'tangent', refs: [c, b] })).ok, 'tangent to bottom side');
  ok(PS.applyChange(d, doc => PS.addCon(doc, { type: 'tangent', refs: [l, c] })).ok, 'tangent to left side');
  ana = PS.analyze(PS.buildSystem(d));
  near(ana.dof, 1, 0, 'circle with two tangents has 1 DOF');
  ok(ana.entFree(c) && !ana.entFree(b), 'circle is under-defined, rectangle is not');
  id = PS.addDimension(d, { type: 'diameter', refs: [c] });
  ok(PS.setDimValue(d, id, 10).ok, 'diameter set to 10');
  ana = PS.analyze(PS.buildSystem(d));
  near(ana.dof, 0, 0, 'sketch fully defined');
  ok(ana.redundant.size === 0 && ana.conflict.size === 0, 'no redundant or conflicting constraints');
  near(Pt(d, E(d, c).c).x, 5, 1e-8, 'circle centre x = 5');
  near(Pt(d, E(d, c).c).y, 5, 1e-8, 'circle centre y = 5');
  near(E(d, c).r, 5, 1e-8, 'circle radius = 5');
  // 40 -> 60
  ok(PS.setDimValue(d, wId, 60, '60').ok, 'width changed from 40 to 60');
  near(Pt(d, E(d, r).p2).x, 60, 1e-8, 'top-right x = 60');
  near(Pt(d, E(d, r).p2).y, 25, 1e-8, 'height still 25');
  near(Pt(d, E(d, c).c).x, 5, 1e-8, 'circle still tangent to the left side');
  near(Pt(d, E(d, c).c).y, 5, 1e-8, 'circle still tangent to the bottom side');
  near(PS.measureCon(d, d.constraints[drivenId]), 60, 1e-8, 'driven dimension follows to 60');
  near(maxResidual(d), 0, 1e-9, 'all constraints hold');
  near(PS.docDof(d), 0, 0, 'still fully defined');
  // conflict: a second horizontal size that disagrees is refused and named
  const snap = JSON.stringify(d);
  const bad = PS.applyChange(d, doc => PS.addCon(doc, { type: 'distance', refs: ['O', E(doc, r).p1], mode: 'h', value: 70 }));
  ok(!bad.ok, 'conflicting dimension is refused');
  ok(JSON.stringify(d) === snap, 'sketch reverted exactly to the last good state');
  ok(bad.clash.some(k => k.cid === wId), 'clash list names the width dimension (' + bad.clash.map(k => k.text).join(' | ') + ')');
  // impossible value
  const bad2 = PS.setDimValue(d, wId, -5);
  ok(!bad2.ok && JSON.stringify(d) === snap, 'impossible value refused, sketch unchanged');
  // topology: rectangle with the circle as a hole
  let sys = PS.buildSystem(d), topo = PS.computeTopology(d, sys);
  PS.syncShapes(d, topo);
  near(topo.faces.length, 2, 0, 'two closed regions');
  const rect = topo.faces.find(f => f.ents.length === 4), hole = topo.faces.find(f => f.ents.length === 1);
  ok(rect && hole && hole.parent === rect.idx, 'circle is nested in the rectangle (it touches two sides)');
  ok(rect.own && !hole.own, 'circle is a hole by default');
  near(rect.outerArea, 1500, 1e-6, 'rectangle area 60 x 25');
  rect.rec.fill = '#2f6fed'; rect.rec.user = true;
  const key = rect.key;
  let items = PS.drawList(topo);
  near(items.length, 1, 0, 'one exported shape');
  near(items[0].cycles.length, 2, 0, 'shape path has outer loop and hole');
  ok(items[0].cycles[0].area > 0 && items[0].cycles[1].area < 0, 'hole is wound opposite to the outline');
  ok(PS.inCycles(items[0].cycles, 30, 12) && !PS.inCycles(items[0].cycles, 5, 5), 'fill covers the plate and not the hole');
  let out = PS.buildSVG(items, {});
  near(out.width, 60.35, 1e-9, 'SVG width = 60 + outline');
  near(out.height, 25.35, 1e-9, 'SVG height = 25 + outline');
  ok(/width="60.35mm" height="25.35mm" viewBox="0 0 60.35 25.35"/.test(out.svg), 'SVG root carries physical size');
  ok((out.svg.match(/<path /g) || []).length === 1 && !/class=|style=|clip-path|<g/.test(out.svg), 'one path, presentation attributes only');
  ok(/fill="#2f6fed" fill-rule="evenodd"/.test(out.svg), 'fill attributes');
  out = PS.buildSVG(items, { frame: 'geometry' });
  ok(/width="60mm" height="25mm" viewBox="0 0 60 25"/.test(out.svg), 'geometry frame is exactly 60 x 25 mm');
  ok(/M0 25L60 25L60 0L0 0Z/.test(out.svg.replace(/L0 25Z/, 'Z')) || /M0 25L60 25L60 0L0 0L0 25Z/.test(out.svg), 'rectangle path coordinates: ' + out.svg.split('\n')[1].slice(0, 120));
  // identity survives a dimension edit
  PS.setDimValue(d, wId, 45);
  sys = PS.buildSystem(d); topo = PS.computeTopology(d, sys); PS.syncShapes(d, topo);
  const rect2 = topo.faces.find(f => f.ents.length === 4);
  ok(rect2.key === key && rect2.rec.fill === '#2f6fed', 'fill and identity survive a dimension change');
  // promote the hole to its own shape
  const h2 = topo.faces.find(f => f.ents.length === 1);
  h2.rec.own = true; h2.rec.fill = '#ffcc00';
  PS.syncShapes(d, topo);
  items = PS.drawList(topo);
  ok(items.length === 2 && items.find(i => i.key === key).cycles.length === 1, 'separate shape: parent becomes solid, circle drawn on its own');
  PS.setDimValue(d, wId, 60);
  accDoc = d;
  // save / load round trip
  const again = PS.parseDoc(PS.serialize(d));
  ok(again.doc && PS.trySolve(again.doc).ok && PS.docDof(again.doc) === 0, 'save and reopen keeps a solved, fully defined sketch');
  ok(PS.parseDoc('{"a":1}').error && PS.parseDoc('nope').error, 'foreign files are rejected with a message');
}

// ---------------------------------------------------------------
section('dragging holds constraints');
{
  // rectangle with fixed size, free position: drag a corner
  const d = PS.newDoc();
  const R = PS.addRect(d, 10, 10, 50, 35);
  PS.addCon(d, { type: 'distance', refs: [R.lines[0]], mode: 'aligned', value: 40 });
  PS.addCon(d, { type: 'distance', refs: [R.lines[3]], mode: 'aligned', value: 25 });
  PS.trySolve(d);
  let sys = PS.buildSystem(d);
  let s = PS.beginDrag(sys, [{ kind: 'point', pid: R.p2 }]);
  let worst = 0, okAll = true;
  for (let k = 1; k <= 40; k++) {
    s.grabs[0].t.x = 50 + k * 3; s.grabs[0].t.y = 35 + Math.sin(k / 3) * 20;
    okAll = PS.dragStep(s) && okAll;
    worst = Math.max(worst, maxResidual(d));
  }
  ok(okAll, 'every drag frame solved');
  near(worst, 0, 1e-8, 'constraints hold on every frame');
  near(Pt(d, R.p2).x, 170, 1e-6, 'dragged corner reached the cursor (x)');
  near(Pt(d, R.p2).x - Pt(d, R.p1).x, 40, 1e-8, 'width still 40 after the drag');
  // point on a fixed circle: cursor far away, point slides on the circle
  const d2 = PS.newDoc();
  const c = PS.addCircle(d2, 0, 0, 20), ln = PS.addLine(d2, 20, 0, 60, 10);
  PS.addCon(d2, { type: 'fix', refs: [c] });
  PS.addCon(d2, { type: 'pointOn', refs: [E(d2, ln).p1, c] });
  PS.trySolve(d2);
  sys = PS.buildSystem(d2);
  s = PS.beginDrag(sys, [{ kind: 'point', pid: E(d2, ln).p1 }]);
  s.grabs[0].t.x = 0; s.grabs[0].t.y = 100;
  for (let k = 0; k < 6; k++) PS.dragStep(s);
  const p = Pt(d2, E(d2, ln).p1);
  near(Math.hypot(p.x, p.y), 20, 1e-8, 'dragged point stays on the circle');
  near(p.x, 0, 1e-3, 'and slides to the side nearest the cursor');
  near(p.y, 20, 1e-3, 'and slides to the side nearest the cursor (y)');
  // fully defined point does not move
  const before = JSON.stringify(accDoc.points);
  sys = PS.buildSystem(accDoc);
  const anyPt = Object.keys(accDoc.points).find(k => !accDoc.points[k].ref);
  s = PS.beginDrag(sys, [{ kind: 'point', pid: anyPt }]);
  s.grabs[0].t.x += 30; s.grabs[0].t.y -= 12;
  PS.dragStep(s);
  let moved = 0;
  const b0 = JSON.parse(before);
  for (const k in accDoc.points) moved = Math.max(moved, Math.abs(accDoc.points[k].x - b0[k].x), Math.abs(accDoc.points[k].y - b0[k].y));
  near(moved, 0, 1e-7, 'dragging a fully defined point moves nothing');
  // circle radius drag
  const d3 = PS.newDoc();
  const cc = PS.addCircle(d3, 10, 10, 5);
  sys = PS.buildSystem(d3);
  s = PS.beginDrag(sys, [{ kind: 'radius', ent: cc }]);
  s.grabs[0].t.x = 10 + 12; s.grabs[0].t.y = 10;
  PS.dragStep(s);
  near(E(d3, cc).r, 12, 1e-6, 'dragging the rim sets the radius');
  near(Pt(d3, E(d3, cc).c).x, 10, 1e-6, 'centre stays put while the radius is free');
}

// ---------------------------------------------------------------
section('degrees of freedom vs dense reference');
{
  let trials = 0, agree = 0, redOk = 0, redTrials = 0;
  for (let T = 0; T < 60; T++) {
    const d = PS.newDoc();
    const lines = [], circs = [];
    const nL = 3 + Math.floor(rnd() * 6), nC = Math.floor(rnd() * 3);
    for (let i = 0; i < nL; i++) lines.push(PS.addLine(d, rnd() * 100, rnd() * 100, rnd() * 100, rnd() * 100));
    for (let i = 0; i < nC; i++) circs.push(PS.addCircle(d, rnd() * 100, rnd() * 100, 5 + rnd() * 15));
    const pick = a => a[Math.floor(rnd() * a.length)];
    const nCon = 2 + Math.floor(rnd() * 14);
    for (let i = 0; i < nCon; i++) {
      const k = Math.floor(rnd() * 10), a = pick(lines), b = pick(lines);
      let con = null;
      if (k === 0) con = { type: 'coincident', refs: [E(d, a).p2, E(d, b).p1] };
      else if (k === 1) con = { type: 'horizontal', refs: [a] };
      else if (k === 2) con = { type: 'vertical', refs: [a] };
      else if (k === 3 && a !== b) con = { type: 'parallel', refs: [a, b] };
      else if (k === 4 && a !== b) con = { type: 'perpendicular', refs: [a, b] };
      else if (k === 5 && a !== b) con = { type: 'equal', refs: [a, b] };
      else if (k === 6) con = { type: 'distance', refs: [a], mode: 'aligned', value: 10 + rnd() * 60 };
      else if (k === 7 && circs.length) con = { type: 'tangent', refs: [a, pick(circs)] };
      else if (k === 8 && a !== b) con = { type: 'pointOn', refs: [E(d, a).p1, b] };
      else if (k === 9) con = { type: 'coincident', refs: [E(d, a).p1, 'O'] };
      if (!con) continue;
      if (con.type === 'coincident' && con.refs[0] === con.refs[1]) continue;
      PS.applyChange(d, doc => PS.addCon(doc, con));
    }
    const sys = PS.buildSystem(d);
    const ana = PS.analyze(sys);
    const { J, m, n } = denseJ(sys);
    const rank = denseRank(J, m, n);
    trials++;
    if (ana.dof === n - rank) agree++; else console.log('  mismatch: sparse dof ' + ana.dof + ' dense ' + (n - rank) + ' (n=' + n + ', m=' + m + ')');
    const cidsWithEq = new Set(sys.eqs.map(e => e.cid));
    if (m > rank) { redTrials++; if (ana.redundant.size >= 1) redOk++; }
    else if (Array.from(ana.redundant).filter(c => cidsWithEq.has(c)).length === 0) { redTrials++; redOk++; }
    // free parameters: perturbing along a null vector must exist for flagged ones only when dof>0
    if (ana.dof === 0) ok(!Array.from(ana.freeParam).some(Boolean), 'no free parameters when DOF is 0');
  }
  console.log('  ' + agree + '/' + trials + ' random sketches agree with the dense rank');
  ok(agree === trials, 'sparse DOF count matches dense rank on random sketches');
  ok(redOk === redTrials, 'redundancy detection consistent (' + redOk + '/' + redTrials + ')');
  // per-entity status
  const d = PS.newDoc();
  const a = PS.addLine(d, 0, 0, 30, 0), b = PS.addLine(d, 50, 50, 70, 80);
  PS.addCon(d, { type: 'fix', refs: [a] });
  let ana = PS.analyze(PS.buildSystem(d));
  ok(!ana.entFree(a) && ana.entFree(b) && ana.dof === 4, 'fixed line defined, free line under-defined');
  // rotation-only freedom: both ends of the stick are free, pivot is not
  const d2 = PS.newDoc();
  const s = PS.addLine(d2, 0, 0, 30, 0);
  PS.addCon(d2, { type: 'coincident', refs: [E(d2, s).p1, 'O'] });
  PS.addCon(d2, { type: 'distance', refs: [s], mode: 'aligned', value: 30 });
  ana = PS.analyze(PS.buildSystem(d2));
  ok(ana.dof === 1 && ana.ptFree(E(d2, s).p2) && !ana.ptFree(E(d2, s).p1), 'pinned stick: 1 DOF, free end only');
  // redundant but consistent: a square's fourth "equal"
  const d3 = PS.newDoc();
  const R = PS.addRect(d3, 0, 0, 30, 20);
  PS.applyChange(d3, doc => PS.addCon(doc, { type: 'equal', refs: [R.lines[0], R.lines[1]] }));
  const x = PS.applyChange(d3, doc => PS.addCon(doc, { type: 'equal', refs: [R.lines[1], R.lines[2]] }));
  ana = PS.analyze(PS.buildSystem(d3));
  ok(x.ok && ana.redundant.has(x.cid) && ana.redundant.size === 1 && ana.conflict.size === 0, 'redundant constraint is flagged, the newest one');
  ok(PS.addConIfUseful(d3, { type: 'parallel', refs: [R.lines[0], R.lines[2]] }) === null, 'inferred constraint that adds nothing is skipped');
}

// ---------------------------------------------------------------
section('constraint behaviour');
{
  // tangent arc between two lines (shared end points), then drive the radius
  const d = PS.newDoc();
  const l1 = PS.addLine(d, 0, 0, 30, 0), a = PS.addArc(d, 30, 10, 30, 0, 40, 10), l2 = PS.addLine(d, 40, 10, 40, 40);
  PS.addCon(d, { type: 'coincident', refs: [E(d, l1).p2, E(d, a).s] });
  PS.addCon(d, { type: 'coincident', refs: [E(d, a).e, E(d, l2).p1] });
  PS.addCon(d, { type: 'coincident', refs: [E(d, l1).p1, 'O'] });
  PS.addCon(d, { type: 'horizontal', refs: [l1] });
  PS.addCon(d, { type: 'vertical', refs: [l2] });
  ok(PS.applyChange(d, doc => PS.addCon(doc, { type: 'tangent', refs: [l1, a] })).ok, 'line-arc tangent at a shared end');
  ok(PS.applyChange(d, doc => PS.addCon(doc, { type: 'tangent', refs: [a, l2] })).ok, 'arc-line tangent at a shared end');
  const rid = PS.addDimension(d, { type: 'radius', refs: [a] });
  ok(PS.setDimValue(d, rid, 6).ok, 'fillet radius set to 6');
  const c = Pt(d, E(d, a).c), s = Pt(d, E(d, a).s), e = Pt(d, E(d, a).e);
  near(Math.hypot(s.x - c.x, s.y - c.y), 6, 1e-8, 'arc radius is 6');
  near(c.y, 6, 1e-8, 'arc centre sits one radius above the horizontal line');
  near(e.x - c.x, 6, 1e-8, 'arc end is tangent to the vertical line');
  let ana = PS.analyze(PS.buildSystem(d));
  // remaining freedom: length of l1, length of l2
  near(ana.dof, 2, 0, 'tangent fillet leaves exactly the two line lengths free');
  // angle dimension keeps the intended side when changed a lot
  const d2 = PS.newDoc();
  const u = PS.addLine(d2, 0, 0, 50, 0), v = PS.addLine(d2, 0, 0, 40, 23);
  PS.addCon(d2, { type: 'fix', refs: [u] });
  PS.addCon(d2, { type: 'coincident', refs: [E(d2, v).p1, E(d2, u).p1] });
  const aid = PS.addDimension(d2, { type: 'angle', refs: [u, v], rev: [false, false] });
  ok(PS.setDimValue(d2, aid, 170 * Math.PI / 180).ok, 'angle changed from about 30 to 170 degrees');
  const q = Pt(d2, E(d2, v).p2);
  near(Math.atan2(q.y, q.x) * 180 / Math.PI, 170, 1e-6, 'line swung to 170 degrees, not the mirrored solution');
  // concentric + equal + circle-circle tangency
  const d3 = PS.newDoc();
  const c1 = PS.addCircle(d3, 0, 0, 10), c2 = PS.addCircle(d3, 28, 3, 6), c3 = PS.addCircle(d3, 3, 2, 4);
  PS.addCon(d3, { type: 'fix', refs: [c1] });
  ok(PS.applyChange(d3, doc => PS.addCon(doc, { type: 'tangent', refs: [c1, c2] })).ok, 'circle-circle tangent');
  near(Math.hypot(Pt(d3, E(d3, c2).c).x, Pt(d3, E(d3, c2).c).y), 10 + E(d3, c2).r, 1e-8, 'external tangency: centre distance = r1 + r2');
  ok(PS.applyChange(d3, doc => PS.addCon(doc, { type: 'concentric', refs: [c3, c1] })).ok, 'concentric');
  near(Pt(d3, E(d3, c3).c).x, 0, 1e-12, 'concentric circle moved onto the fixed centre');
  ok(PS.applyChange(d3, doc => PS.addCon(doc, { type: 'equal', refs: [c2, c3] })).ok, 'equal radius');
  near(E(d3, c2).r, E(d3, c3).r, 1e-9, 'radii equal');
  // midpoint, point-on-line, perpendicular
  const d4 = PS.newDoc();
  const base = PS.addLine(d4, 0, 0, 40, 0), up = PS.addLine(d4, 18, 1, 22, 30);
  PS.addCon(d4, { type: 'fix', refs: [base] });
  ok(PS.applyChange(d4, doc => PS.addCon(doc, { type: 'midpoint', refs: [E(doc, up).p1, base] })).ok, 'midpoint');
  ok(PS.applyChange(d4, doc => PS.addCon(doc, { type: 'perpendicular', refs: [up, base] })).ok, 'perpendicular');
  near(Pt(d4, E(d4, up).p1).x, 20, 1e-9, 'end sits at the midpoint');
  near(Pt(d4, E(d4, up).p2).x, 20, 1e-8, 'line is perpendicular');
  // a constraint that would collapse a line is refused
  const d6 = PS.newDoc();
  const hv = PS.addLine(d6, 0, 0, 20, 3);
  PS.applyChange(d6, doc => PS.addCon(doc, { type: 'horizontal', refs: [hv] }));
  const col = PS.applyChange(d6, doc => PS.addCon(doc, { type: 'vertical', refs: [hv] }));
  ok(!col.ok && col.collapsed.length === 1, 'horizontal + vertical on one line is refused (it would collapse the line)');
  // makeConstraint validation
  ok(PS.makeConstraint(d4, 'parallel', [base]).need, 'parallel asks for a second line');
  ok(PS.makeConstraint(d4, 'tangent', [base, up]).error, 'tangent between two lines is refused');
  ok(PS.makeConstraint(d4, 'coincident', [E(d4, up).p2, base]).con.type === 'pointOn', 'coincident with a line means point-on-line');
  ok(PS.makeConstraint(d4, 'fix', ['O']).error, 'origin cannot be fixed again');
  // deleting an entity removes its constraints
  PS.deleteItems(d4, [up]);
  ok(Object.keys(d4.constraints).length === 1 && !d4.entities[up], 'deleting a line removes the constraints that used it');
  // fix conflict names the fix
  const d5 = PS.newDoc();
  const f = PS.addLine(d5, 0, 0, 30, 0);
  const fx = PS.addCon(d5, { type: 'fix', refs: [f] });
  const res = PS.applyChange(d5, doc => PS.addCon(doc, { type: 'distance', refs: [f], mode: 'aligned', value: 50 }));
  ok(!res.ok && res.clash.some(k => k.cid === fx), 'clash with a fixed line names the Fix constraint');
}

// ---------------------------------------------------------------
section('regions and paths');
{
  const build = d => { const sys = PS.buildSystem(d); const t = PS.computeTopology(d, sys); PS.syncShapes(d, t); return t; };
  // two rectangles sharing an edge via T-junctions
  const d = PS.newDoc();
  const R = PS.addRect(d, 0, 0, 40, 20);
  let t = build(d);
  near(t.faces.length, 1, 0, 'rectangle is one region');
  t.faces[0].rec.fill = '#00aa55'; t.faces[0].rec.user = true;
  const div = PS.addLine(d, 15, 0, 15, 20);
  PS.addCon(d, { type: 'pointOn', refs: [E(d, div).p1, R.lines[0]] });
  PS.addCon(d, { type: 'pointOn', refs: [E(d, div).p2, R.lines[2]] });
  PS.trySolve(d);
  t = build(d);
  near(t.faces.length, 2, 0, 'dividing line with T-junctions makes two regions');
  near(t.faces.reduce((s, f) => s + f.area, 0), 800, 1e-6, 'regions tile the rectangle');
  ok(t.faces.every(f => f.rec.fill === '#00aa55'), 'both halves inherit the fill of the loop they came from');
  ok(t.paths.length === 0, 'no stray open paths');
  PS.deleteItems(d, [div]);
  t = build(d);
  ok(t.faces.length === 1 && t.faces[0].rec.fill === '#00aa55', 'removing the divider restores the original shape and fill');
  // lines that merely cross do not create regions
  const d2 = PS.newDoc();
  PS.addLine(d2, 0, 0, 40, 40); PS.addLine(d2, 0, 40, 40, 0);
  t = build(d2);
  ok(t.faces.length === 0 && t.paths.length === 2, 'crossing lines stay two open paths');
  // open chain is one stroke-only path
  const d3 = PS.newDoc();
  const a = PS.addLine(d3, 0, 0, 10, 0), b = PS.addLine(d3, 10, 0, 10, 10), c = PS.addArc(d3, 15, 10, 20, 10, 10, 10);
  PS.addCon(d3, { type: 'coincident', refs: [E(d3, a).p2, E(d3, b).p1] });
  PS.addCon(d3, { type: 'coincident', refs: [E(d3, b).p2, E(d3, c).e] });
  t = build(d3);
  ok(t.faces.length === 0 && t.paths.length === 1 && t.paths[0].segs.length === 3 && !t.paths[0].closed, 'three chained entities form one open path');
  // circle with a chord: two regions with distinct identities
  const d4 = PS.newDoc();
  const ci = PS.addCircle(d4, 0, 0, 10), ch = PS.addLine(d4, -10, 0, 10, 0);
  PS.addCon(d4, { type: 'pointOn', refs: [E(d4, ch).p1, ci] });
  PS.addCon(d4, { type: 'pointOn', refs: [E(d4, ch).p2, ci] });
  PS.trySolve(d4);
  t = build(d4);
  ok(t.faces.length === 2 && t.faces[0].key !== t.faces[1].key, 'chord splits a circle into two distinct regions');
  near(t.faces[0].area + t.faces[1].area, Math.PI * 100, 1e-6, 'two halves add up to the circle');
  // nesting three deep: even-odd island
  const d5 = PS.newDoc();
  PS.addRect(d5, 0, 0, 100, 100); PS.addRect(d5, 20, 20, 80, 80); PS.addCircle(d5, 50, 50, 10);
  const off = PS.addCircle(d5, 95, 50, 12);     // crosses the outer boundary: not a hole
  t = build(d5);
  const outer = t.faces.find(f => Math.abs(f.outerArea - 10000) < 1e-6);
  const mid = t.faces.find(f => Math.abs(f.outerArea - 3600) < 1e-6);
  const inner = t.faces.find(f => f.ents.length === 1 && f.ents[0] !== off);
  const offF = t.faces.find(f => f.ents[0] === off);
  ok(mid.parent === outer.idx && inner.parent === mid.idx, 'nesting chain outer > middle > inner');
  ok(offF.parent === -1, 'a loop that crosses the boundary is not treated as a hole');
  const it = PS.drawList(t).find(i => i.key === outer.key);
  ok(it.cycles.length === 3, 'outer shape carries the hole and the island');
  ok(PS.inCycles(it.cycles, 10, 10) && !PS.inCycles(it.cycles, 30, 30) && PS.inCycles(it.cycles, 50, 50), 'even-odd: filled, hole, filled');
  ok(it.cycles[0].area > 0 && it.cycles[1].area < 0 && it.cycles[2].area > 0, 'winding alternates, so non-zero fill gives the same picture');
  ok(PS.hitFace(t, 50, 50) === inner && PS.hitFace(t, 30, 30) === mid && PS.hitFace(t, 5, 5) === outer, 'click picks the innermost region');
  // slot outline: two lines and two tangent arcs
  const d6 = PS.newDoc();
  const top = PS.addLine(d6, 0, 5, 30, 5), bot = PS.addLine(d6, 30, -5, 0, -5);
  const ar = PS.addArc(d6, 30, 0, 30, -5, 30, 5), al = PS.addArc(d6, 0, 0, 0, 5, 0, -5);
  PS.addCon(d6, { type: 'coincident', refs: [E(d6, top).p2, E(d6, ar).e] });
  PS.addCon(d6, { type: 'coincident', refs: [E(d6, ar).s, E(d6, bot).p1] });
  PS.addCon(d6, { type: 'coincident', refs: [E(d6, bot).p2, E(d6, al).e] });
  PS.addCon(d6, { type: 'coincident', refs: [E(d6, al).s, E(d6, top).p1] });
  t = build(d6);
  ok(t.faces.length === 1 && t.paths.length === 0, 'slot outline (tangent arcs) is one region');
  near(t.faces[0].area, 300 + Math.PI * 25, 1e-6, 'slot area');
  const svg = PS.buildSVG(PS.drawList(t), { frame: 'geometry' });
  near(svg.width, 40, 1e-9, 'slot SVG width includes the arcs');
  ok((svg.svg.match(/A5 5 0 /g) || []).length === 2, 'arcs exported as true arcs');
  const bz = PS.buildSVG(PS.drawList(t), { frame: 'geometry', bezier: true });
  ok(!/A5 5/.test(bz.svg) && /C/.test(bz.svg), 'bezier option replaces arcs with curves');
  // line tangent to a circle at a junction point: tie broken by curvature
  const d7 = PS.newDoc();
  const k = PS.addCircle(d7, 0, 0, 10), tl = PS.addLine(d7, 0, 10, 30, 10), dn = PS.addLine(d7, 30, 10, 10, 0);
  PS.addCon(d7, { type: 'pointOn', refs: [E(d7, tl).p1, k] });
  PS.addCon(d7, { type: 'tangent', refs: [tl, k] });
  PS.addCon(d7, { type: 'coincident', refs: [E(d7, tl).p2, E(d7, dn).p1] });
  PS.addCon(d7, { type: 'pointOn', refs: [E(d7, dn).p2, k] });
  ok(PS.trySolve(d7).ok, 'tangent-at-junction sketch solves');
  t = build(d7);
  ok(t.faces.length === 2, 'tangent junction: circle plus the wedge beside it (' + t.faces.length + ' regions)');
  near(t.faces.reduce((s, f) => Math.max(s, f.area), 0), Math.PI * 100, 1e-6, 'circle region keeps its full area');
  // PNG dpi chunk
  const png = Uint8Array.from([137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0, 31, 21, 196, 137,
    0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130]);
  const out = PS.pngSetDpi(png, 300);
  ok(out.length === png.length + 21 && String.fromCharCode(out[37], out[38], out[39], out[40]) === 'pHYs', 'pHYs chunk inserted after IHDR');
  near(new DataView(out.buffer).getUint32(41), 11811, 0, '300 dpi = 11811 pixels per metre');
}

// ---------------------------------------------------------------
section('performance: a few hundred entities');
{
  // 90 linked rectangles in a row (360 lines, one connected system) + 60 circles
  const d = PS.newDoc();
  let prev = null;
  const rects = [];
  for (let i = 0; i < 90; i++) {
    const R = PS.addRect(d, i * 12, 0, i * 12 + 10, 8 + (i % 3));
    PS.addCon(d, { type: 'distance', refs: [R.lines[0]], mode: 'aligned', value: 10 });
    PS.addCon(d, { type: 'distance', refs: [R.lines[3]], mode: 'aligned', value: 8 + (i % 3) });
    if (prev) PS.addCon(d, { type: 'distance', refs: [E(d, prev.lines[1]).p1, R.p1], mode: 'h', value: 2 });
    if (prev) PS.addCon(d, { type: 'horizontal', refs: [prev.p1, R.p1] });
    rects.push(R); prev = R;
  }
  for (let i = 0; i < 60; i++) {
    const c = PS.addCircle(d, i * 12 + 5, 4, 2);
    PS.addCon(d, { type: 'tangent', refs: [c, rects[i].lines[0]] });
    PS.addCon(d, { type: 'tangent', refs: [c, rects[i].lines[3]] });
  }
  let t0 = process.hrtime.bigint();
  const res = PS.trySolve(d);
  const tSolve = Number(process.hrtime.bigint() - t0) / 1e6;
  ok(res.ok, 'large sketch solves');
  t0 = process.hrtime.bigint();
  let sys = PS.buildSystem(d);
  const ana = PS.analyze(sys);
  const tAna = Number(process.hrtime.bigint() - t0) / 1e6;
  t0 = process.hrtime.bigint();
  const topo = PS.computeTopology(d, sys); PS.syncShapes(d, topo);
  const tTopo = Number(process.hrtime.bigint() - t0) / 1e6;
  const nEnt = Object.keys(d.entities).length - 2;
  console.log('  ' + nEnt + ' entities, ' + sys.nVars + ' unknowns, ' + sys.eqs.length + ' equations, ' + sys.comps.length + ' component(s), DOF ' + ana.dof);
  console.log('  full solve ' + tSolve.toFixed(1) + ' ms, build + DOF analysis ' + tAna.toFixed(1) + ' ms, regions ' + tTopo.toFixed(1) + ' ms (' + topo.faces.length + ' regions)');
  // drag the first rectangle: the whole chain follows
  const s = PS.beginDrag(sys, [{ kind: 'point', pid: rects[0].p1 }]);
  const times = [];
  let worst = 0;
  for (let k = 1; k <= 60; k++) {
    s.grabs[0].t.x = k * 1.5; s.grabs[0].t.y = Math.sin(k / 5) * 15;
    t0 = process.hrtime.bigint();
    const good = PS.dragStep(s);
    times.push(Number(process.hrtime.bigint() - t0) / 1e6);
    if (!good) worst = 1;
  }
  worst = Math.max(worst, maxResidual(d));
  times.sort((a, b) => a - b);
  console.log('  drag frame: median ' + times[30].toFixed(2) + ' ms, worst ' + times[59].toFixed(2) + ' ms over 60 frames (' + s.locAll.n + ' unknowns in the dragged system)');
  near(worst, 0, 1e-7, 'constraints hold through the drag');
  near(Pt(d, rects[89].p1).x - Pt(d, rects[0].p1).x, 89 * 12, 1e-6, 'far end of the chain followed the drag');
  ok(times[30] < 8, 'median drag frame under 8 ms');
  ok(times[59] < 16, 'worst drag frame under 16 ms');
}

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
