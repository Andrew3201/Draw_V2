const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path');
const SHOTS = process.env.SHOTS || '/tmp/claude-0/-home-claude/8dd0c3c1-a53d-531a-8511-e881a85d4397/scratchpad';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL: ' + m); } };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 820 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../dist/local.html'));
  await page.waitForTimeout(400);
  const S = async (x, y) => page.evaluate(([x, y]) => { const s = window.__ps, r = document.getElementById('cv').getBoundingClientRect(); return [r.left + (x - s.view.cx) * s.view.zoom + s.w / 2, r.top + s.h / 2 - (y - s.view.cy) * s.view.zoom]; }, [x, y]);
  const click = async (x, y, o) => { const p = await S(x, y); await page.mouse.move(p[0], p[1]); await page.mouse.click(p[0], p[1], o); await page.waitForTimeout(30); };
  const move = async (x, y) => { const p = await S(x, y); await page.mouse.move(p[0], p[1]); };
  const key = async k => { await page.keyboard.press(k); await page.waitForTimeout(30); };
  const st = f => page.evaluate(f);
  const dof = () => page.evaluate(() => document.getElementById('dof').textContent);
  const typeDim = async v => { await page.waitForSelector('#dimedit:not([hidden])', { timeout: 2000 }); await page.keyboard.press('Control+A'); await page.keyboard.type(String(v)); await page.keyboard.press('Enter'); await page.waitForTimeout(60); };
  const shot = n => page.screenshot({ path: SHOTS + '/' + n + '.png' });

  console.log('# first open');
  ok(await st(() => !document.getElementById('example').hidden), 'example banner shown on first open');
  ok((await dof()).includes('1 degree of freedom'), 'example reports 1 degree of freedom: ' + await dof());
  ok(await st(() => window.__ps.items.length === 1 && window.__ps.items[0].cycles.length === 3), 'example plate is one shape with two holes');
  await shot('01-example');

  console.log('# acceptance flow by mouse and keyboard');
  await page.click('#btnBlank');
  await page.waitForTimeout(100);
  ok((await dof()).includes('Empty'), 'blank sketch');
  await st(() => { window.__ps.view = { cx: 30, cy: 14, zoom: 9 }; });
  await key('r');
  await click(10, 6); await click(47, 29);
  ok(await st(() => Object.keys(window.__ps.doc.entities).length === 6), 'rectangle drawn (4 lines)');
  ok((await dof()).includes('4 degrees'), 'rectangle has 4 DOF: ' + await dof());
  // locate from origin: coincident tool, corner then origin
  await key('i');
  await click(10, 6); await click(0, 0);
  ok((await dof()).includes('2 degrees'), 'corner on origin leaves 2 DOF: ' + await dof());
  let g = await st(() => { const d = window.__ps.doc, e = Object.values(d.entities).filter(e => !e.ref); return e.map(l => [d.points[l.p1].x, d.points[l.p1].y, d.points[l.p2].x, d.points[l.p2].y]); });
  ok(Math.abs(g[0][0]) < 1e-9 && Math.abs(g[0][1]) < 1e-9, 'rectangle corner moved to the origin');
  // dimension bottom side: 40
  await key('d');
  await click(18, 0); await click(18, -6);
  await typeDim(40);
  await click(0, 12); await click(-7, 12);
  await typeDim(25);
  ok((await dof()).includes('Fully defined'), '40 x 25 from the origin is fully defined: ' + await dof());
  g = await st(() => { const d = window.__ps.doc; let mx = 0, my = 0; for (const k in d.points) if (!d.points[k].ref) { mx = Math.max(mx, d.points[k].x); my = Math.max(my, d.points[k].y); } return [mx, my]; });
  ok(Math.abs(g[0] - 40) < 1e-8 && Math.abs(g[1] - 25) < 1e-8, 'rectangle is 40 x 25: ' + g);
  await shot('02-rect-defined');
  // circle, tangent to bottom and left, diameter 10
  await key('c');
  await click(11, 9); await click(17, 9);
  await key('t');
  await click(11 + 6 * Math.cos(1), 9 + 6 * Math.sin(1)); await click(25, 0);
  await click(await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).find(e => e.type === 'circle'); return d.points[c.c].x + c.r * Math.cos(1); }), await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).find(e => e.type === 'circle'); return d.points[c.c].y + c.r * Math.sin(1); }));
  await click(0, 18);
  ok((await dof()).includes('1 degree'), 'circle tangent to two sides: 1 DOF: ' + await dof());
  await key('d');
  const cc = await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).find(e => e.type === 'circle'); return [d.points[c.c].x, d.points[c.c].y, c.r]; });
  await click(cc[0] + cc[2] * Math.cos(2.2), cc[1] + cc[2] * Math.sin(2.2)); await click(cc[0] + 9, cc[1] + 8);
  await typeDim(10);
  ok((await dof()).includes('Fully defined'), 'with the diameter the sketch is fully defined: ' + await dof());
  let c = await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).find(e => e.type === 'circle'); return [d.points[c.c].x, d.points[c.c].y, c.r]; });
  ok(Math.abs(c[0] - 5) < 1e-7 && Math.abs(c[1] - 5) < 1e-7 && Math.abs(c[2] - 5) < 1e-7, 'circle sits at (5,5) with radius 5: ' + c);
  // change 40 -> 60 by double-clicking the dimension
  await key('Escape');
  const dimPos = await st(() => { const r = window.__ps.dimRects.find(r => window.__ps.doc.constraints[r.cid].value === 40), b = document.getElementById('cv').getBoundingClientRect(); return [b.left + r.x + r.w / 2, b.top + r.y + r.h / 2]; });
  await page.mouse.dblclick(dimPos[0], dimPos[1]);
  await typeDim(60);
  g = await st(() => { const d = window.__ps.doc; let mx = 0, my = 0; for (const k in d.points) if (!d.points[k].ref) { mx = Math.max(mx, d.points[k].x); my = Math.max(my, d.points[k].y); } return [mx, my]; });
  c = await st(() => { const d = window.__ps.doc, c = Object.values(d.entities).find(e => e.type === 'circle'); return [d.points[c.c].x, d.points[c.c].y, c.r]; });
  ok(Math.abs(g[0] - 60) < 1e-8 && Math.abs(g[1] - 25) < 1e-8, '40 changed to 60: ' + g);
  ok(Math.abs(c[0] - 5) < 1e-7 && Math.abs(c[1] - 5) < 1e-7, 'tangency preserved after the change: ' + c);
  ok((await dof()).includes('Fully defined'), 'still fully defined');
  await key('f');
  await page.waitForTimeout(100);
  await shot('03-60x25');
  // fill the rectangle blue, circle stays a hole
  await click(35, 15);
  await page.waitForTimeout(80);
  ok(await st(() => Array.from(window.__ps.sel).join().startsWith('s:F|')), 'clicking inside the loop selects the shape');
  await page.click('[data-swatch="#1f6fd6"][data-style="fill"]');
  await page.waitForTimeout(80);
  ok(await st(() => { const it = window.__ps.items; return it.length === 1 && it[0].rec.fill === '#1f6fd6' && it[0].cycles.length === 2; }), 'rectangle filled blue with the circle as a hole');
  await shot('04-filled-sketch');
  await key('Tab');
  await page.waitForTimeout(100);
  ok(await st(() => window.__ps.mode === 'clean'), 'Tab switches to Clean view');
  await shot('05-clean');
  // pixel check in clean view: blue in the plate, white in the hole
  const px = async (x, y) => { const p = await S(x, y); return page.evaluate(([sx, sy]) => { const cv = document.getElementById('cv'), r = cv.getBoundingClientRect(), k = cv.width / r.width; const d = cv.getContext('2d').getImageData(Math.round((sx - r.left) * k), Math.round((sy - r.top) * k), 1, 1).data; return [d[0], d[1], d[2]]; }, p); };
  const blue = await px(35, 15), hole = await px(5, 5), outside = await px(30, 28);
  ok(blue[2] > 180 && blue[0] < 80, 'Clean view pixel inside the plate is blue: ' + blue);
  ok(hole[0] > 240 && hole[1] > 240, 'Clean view pixel inside the hole is paper white: ' + hole);
  ok(outside[0] > 240, 'outside is white');
  // export dialog
  await page.click('#btnExport');
  await page.waitForSelector('#x-info');
  const info = await page.evaluate(() => document.getElementById('x-info').textContent);
  ok(/60\.35 × 25\.35 mm/.test(info) && /60 × 25/.test(info), 'export dialog states the picture size: ' + info);
  await shot('06-export');
  await page.selectOption('#x-frame', 'geometry');
  ok(/60 × 25 mm/.test(await page.evaluate(() => document.getElementById('x-info').textContent)), 'geometry-only frame is 60 x 25');
  await page.selectOption('#x-fmt', 'png');
  ok(/713 × 300 px/.test(await page.evaluate(() => document.getElementById('x-info').textContent)), 'PNG size at 300 dpi: ' + await page.evaluate(() => document.getElementById('x-info').textContent));
  await key('Escape');
  const svg = await st(() => PS.buildSVG(window.__ps.items, { frame: 'geometry' }).svg);
  ok(/width="60mm" height="25mm"/.test(svg), 'exported SVG is 60 x 25 mm');
  console.log(svg.trim().split('\n').map(l => '    ' + l.slice(0, 200)).join('\n'));
  // PNG render path in the real browser (pHYs + pixels)
  const png = await st(async () => { const mod = window.__ps; const c = document.createElement('canvas'); return true; });
  // back to sketch, undo/redo
  await key('Tab');
  const before = await st(() => JSON.stringify(window.__ps.doc));
  await page.keyboard.press('Control+z'); await page.waitForTimeout(50);
  ok(await st(() => window.__ps.items[0].rec.fill === 'none'), 'undo removes the fill');
  await page.keyboard.press('Control+y'); await page.waitForTimeout(50);
  ok(await st(() => JSON.stringify(window.__ps.doc)) === before, 'redo restores it exactly');

  console.log('# drawing, inference and dragging');
  // line chain with inference: start on the rectangle's top-right corner, go horizontal, then close back
  await st(() => { window.__ps.view = { cx: 45, cy: 14, zoom: 8 }; });
  await key('l');
  await click(60, 25);
  await move(80, 25.3);
  await page.waitForTimeout(40);
  const inf = await st(() => JSON.stringify(window.__ps.infer));
  ok(/horizontal/.test(inf), 'horizontal inferred while drawing: ' + inf);
  await click(80, 25.3);
  await click(80.2, 8);
  await key('Escape'); await key('Escape');
  let cons = await st(() => Object.values(window.__ps.doc.constraints).map(c => c.type));
  ok(cons.filter(t => t === 'horizontal').length === 3 && cons.filter(t => t === 'vertical').length === 3, 'inferred horizontal and vertical constraints were added');
  ok(cons.filter(t => t === 'coincident').length === 7, 'chain joined by coincident constraints: ' + cons.filter(t => t === 'coincident').length);
  ok(await st(() => window.__ps.topo.paths.length === 1 && window.__ps.topo.paths[0].segs.length === 2), 'open chain is one stroke-only path');
  ok((await dof()).includes('2 degrees'), 'chain has 2 DOF (its two lengths): ' + await dof());
  // drag the free end: it may only move vertically; the corner moves horizontally
  const end = await st(() => { const d = window.__ps.doc, ls = Object.values(d.entities).filter(e => e.type === 'line' && !e.ref); const l = ls[ls.length - 1]; return [d.points[l.p2].x, d.points[l.p2].y, l.p2]; });
  let p = await S(end[0], end[1]);
  await page.mouse.move(p[0], p[1]); await page.mouse.down();
  for (let i = 1; i <= 10; i++) { const q = await S(end[0] + i * 1.5, end[1] - i * 0.8); await page.mouse.move(q[0], q[1]); await page.waitForTimeout(8); }
  await page.mouse.up(); await page.waitForTimeout(60);
  const after = await st(() => { const d = window.__ps.doc, ls = Object.values(d.entities).filter(e => e.type === 'line' && !e.ref); const l = ls[ls.length - 1], h = ls[ls.length - 2]; return { x: d.points[l.p2].x, y: d.points[l.p2].y, topx: d.points[l.p1].x, topy: d.points[l.p1].y, hy: d.points[h.p1].y }; });
  ok(Math.abs(after.x - (end[0] + 15)) < 0.2 && Math.abs(after.y - (end[1] - 8)) < 0.2, 'dragged end followed the cursor: ' + JSON.stringify(after));
  ok(Math.abs(after.x - after.topx) < 1e-7 && Math.abs(after.topy - 25) < 1e-7 && Math.abs(after.hy - 25) < 1e-7, 'vertical and horizontal constraints held during the drag');
  await shot('07-chain-drag');
  // conflicting dimension is refused with a message
  await key('d');
  await click(70, 25); await click(70, 31);
  await typeDim(12);
  const n1 = await st(() => Object.keys(window.__ps.doc.constraints).length);
  // conflict: fix the far end, then try to add an impossible horizontal distance via the solver API through the UI path
  const res = await st(() => { const s = window.__ps, d = s.doc; const top = Object.values(d.entities).filter(e => e.type === 'line' && !e.ref)[4]; const r = PS.applyChange(d, doc => PS.addCon(doc, { type: 'distance', refs: ['O', top.p2], mode: 'h', value: 100 })); return { ok: r.ok, clash: r.clash && r.clash.map(k => k.text) }; });
  ok(!res.ok && res.clash.length >= 2, 'clashing dimension refused and named: ' + JSON.stringify(res.clash));
  ok(await st(() => Object.keys(window.__ps.doc.constraints).length) === n1, 'sketch unchanged after the refusal');
  // box select + delete
  await key('Escape'); await key('Escape');
  let a = await S(-1.5, 11.5), b = await S(11.5, -1.5);
  await page.mouse.move(a[0], a[1]); await page.mouse.down(); await page.mouse.move(b[0], b[1], { steps: 4 }); await page.mouse.up();
  await page.waitForTimeout(50);
  ok(await st(() => { const e = Array.from(window.__ps.sel).filter(r => r[0] === 'e'); return e.length === 1 && window.__ps.doc.entities[e[0].slice(2)].type === 'circle'; }), 'left-to-right box selects only what it encloses (the circle)');
  a = await S(100, 12); b = await S(66, 28);
  await page.mouse.move(a[0], a[1]); await page.mouse.down(); await page.mouse.move(b[0], b[1], { steps: 4 }); await page.mouse.up();
  await page.waitForTimeout(50);
  await shot('07b-crossing');
  ok(await st(() => Array.from(window.__ps.sel).filter(r => r[0] === 'e').length) === 2, 'right-to-left box selects the two lines it crosses: ' + await st(() => Array.from(window.__ps.sel).join(' ')));
  await key('Delete');
  ok(await st(() => Object.values(window.__ps.doc.entities).filter(e => !e.ref).length) === 5, 'Delete removes them');
  ok((await dof()).includes('Fully defined'), 'back to fully defined: ' + await dof());
  // arc tool
  await st(() => { window.__ps.view = { cx: 45, cy: 14, zoom: 8 }; });
  await key('a');
  await click(70, 0); await click(90, 0); await click(80, 8);
  ok(await st(() => Object.values(window.__ps.doc.entities).filter(e => e.type === 'arc').length) === 1, 'three-point arc created');
  const arc = await st(() => { const d = window.__ps.doc, a = Object.values(d.entities).find(e => e.type === 'arc'); const c = d.points[a.c], s = d.points[a.s], e = d.points[a.e]; return { r1: Math.hypot(s.x - c.x, s.y - c.y), r2: Math.hypot(e.x - c.x, e.y - c.y), sx: s.x, ex: e.x, cy: c.y }; });
  ok(Math.abs(arc.r1 - arc.r2) < 1e-8 && arc.cy < 0, 'arc passes through the three clicks: ' + JSON.stringify(arc));
  await key('Escape');
  await key('f'); await page.waitForTimeout(80);
  await shot('08-arc');
  // units switch does not change geometry
  await page.selectOption('#f-units', 'in');
  await page.waitForTimeout(80);
  ok(await st(() => { const d = window.__ps.doc; let mx = 0; for (const k in d.points) if (!d.points[k].ref && d.points[k].owner && d.entities[d.points[k].owner].type === 'line') mx = Math.max(mx, d.points[k].x); return Math.abs(mx - 60) < 1e-8 && d.units === 'in'; }), 'switching to inches keeps the geometry');
  ok(await st(() => window.__ps.dimRects.length >= 3), 'dimensions still drawn');
  await shot('09-inches');
  await page.selectOption('#f-units', 'mm');
  // save / open round trip through the real parser
  ok(await st(() => { const t = PS.serialize(window.__ps.doc), r = PS.parseDoc(t); return !!r.doc && PS.trySolve(r.doc).ok; }), 'save text reopens and solves');
  // real PNG export in the browser
  const pngInfo = await page.evaluate(async () => {
    const it = window.__ps.items, b = PS.itemsBounds(it).stroke, k = 300 / 25.4;
    const c = document.createElement('canvas'); c.width = Math.ceil((b[2] - b[0]) * k); c.height = Math.ceil((b[3] - b[1]) * k);
    const g = c.getContext('2d'); g.setTransform(k, 0, 0, -k, -b[0] * k, b[3] * k);
    for (const i of it) PS.paintItem(g, i);
    const blob = await new Promise(r => c.toBlob(r, 'image/png'));
    const out = PS.pngSetDpi(new Uint8Array(await blob.arrayBuffer()), 300);
    const img = await createImageBitmap(new Blob([out], { type: 'image/png' }));
    return { w: img.width, h: img.height, phys: String.fromCharCode(out[37], out[38], out[39], out[40]), ppm: new DataView(out.buffer).getUint32(41) };
  });
  ok(pngInfo.phys === 'pHYs' && pngInfo.ppm === 11811 && pngInfo.w > 700, 'PNG with physical size still decodes: ' + JSON.stringify(pngInfo));
  // dark theme
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'dark'));
  await page.waitForTimeout(150);
  await shot('10-dark');
  await page.evaluate(() => document.documentElement.removeAttribute('data-theme'));
  // narrow layout: no horizontal scroll
  await page.setViewportSize({ width: 400, height: 760 });
  await page.waitForTimeout(200);
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth && document.body.scrollWidth <= window.innerWidth), 'no horizontal page scroll at phone width');
  await shot('11-narrow');
  ok(errors.length === 0, 'no script errors: ' + errors.join(' | '));
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  await browser.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
