// =====================================================================
// PrecisionSketch core: document model, units, expressions, constraint
// solver and degree-of-freedom analysis. No DOM access in this file.
// Geometry is stored in millimetres with Y up.
// =====================================================================

const UNITS = { mm: 1, cm: 10, in: 25.4, pt: 25.4 / 72, px: 25.4 / 96 };
const TAU = Math.PI * 2;
const TOL = 1e-7;        // residual (mm) accepted as "constraint holds"
const TOL_GOAL = 1e-10;  // residual the solver aims for
const RADIUS_STIFFNESS = 100;

function normAng(a) { a %= TAU; return a < 0 ? a + TAU : a; }
function wrapPi(a) { a = (a + Math.PI) % TAU; if (a < 0) a += TAU; return a - Math.PI; }

function fmtNum(v, prec) {
  if (!isFinite(v)) return '?';
  let s = v.toFixed(prec);
  if (s.indexOf('.') >= 0) s = s.replace(/0+$/, '').replace(/\.$/, '');
  if (s === '-0') s = '0';
  return s;
}
function fmtLen(mm, doc) { return fmtNum(mm / UNITS[doc.units], doc.precision); }

// ---------------------------------------------------------------------
// Expressions: "42.5", "1.5 in", "40/2 + 3", "(10 + 2.5) * 2 mm".
// Plain numbers are document units (or degrees for angles).
// ---------------------------------------------------------------------
function evalExpr(src, env) {
  env = env || {};
  const unit = env.units || 'mm';
  const kind = env.kind || 'length';
  const vars = env.vars || {};
  const s = String(src);
  let i = 0;
  const toks = [];
  while (i < s.length) {
    const ch = s[i];
    if (/\s/.test(ch)) { i++; continue; }
    const mnum = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i));
    if (mnum) { toks.push({ t: 'n', v: parseFloat(mnum[0]) }); i += mnum[0].length; continue; }
    const mid = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s.slice(i));
    if (mid) { toks.push({ t: 'id', v: mid[0] }); i += mid[0].length; continue; }
    if (ch === '°') { toks.push({ t: 'id', v: 'deg' }); i++; continue; }
    if (ch === '"') { toks.push({ t: 'id', v: 'in' }); i++; continue; }
    if ('+-*/^()'.indexOf(ch) >= 0) { toks.push({ t: ch }); i++; continue; }
    if (ch === '×') { toks.push({ t: '*' }); i++; continue; }
    if (ch === '÷') { toks.push({ t: '/' }); i++; continue; }
    if (ch === ',') { return { ok: false, error: 'Use a point as the decimal separator' }; }
    return { ok: false, error: 'Unexpected "' + ch + '"' };
  }
  if (!toks.length) return { ok: false, error: 'Enter a value' };
  let p = 0;
  const peek = () => toks[p];
  const isUnit = n => Object.prototype.hasOwnProperty.call(UNITS, n) || n === 'm' || n === 'deg' || n === 'rad';
  const FN = { sqrt: Math.sqrt, abs: Math.abs, sin: Math.sin, cos: Math.cos, tan: Math.tan };
  function fail(m) { throw new Error(m); }
  // values carry a length exponent L and an angle flag A (already radians)
  function withUnit(val, name) {
    if (val.L !== 0 || val.A) fail('A unit can only follow a plain number');
    if (name === 'deg') return { v: val.v * Math.PI / 180, L: 0, A: true };
    if (name === 'rad') return { v: val.v, L: 0, A: true };
    if (name === 'm') return { v: val.v * 1000, L: 1, A: false };
    return { v: val.v * UNITS[name], L: 1, A: false };
  }
  function addish(a, b, sign) {
    if (a.A !== b.A) {
      if (!a.A && a.L === 0) a = { v: a.v * Math.PI / 180, L: 0, A: true };
      else if (!b.A && b.L === 0) b = { v: b.v * Math.PI / 180, L: 0, A: true };
      else fail('Cannot combine an angle with a length');
    }
    if (a.L !== b.L) {
      if (a.L === 0 && b.L === 1) a = { v: a.v * UNITS[unit], L: 1, A: a.A };
      else if (b.L === 0 && a.L === 1) b = { v: b.v * UNITS[unit], L: 1, A: b.A };
      else fail('Cannot add values with different dimensions');
    }
    return { v: a.v + sign * b.v, L: a.L, A: a.A };
  }
  function primary() {
    const t = peek();
    if (!t) fail('The expression ends early');
    if (t.t === 'n') {
      p++;
      let val = { v: t.v, L: 0, A: false };
      const n = peek();
      if (n && n.t === 'id' && isUnit(n.v) && !vars[n.v]) { p++; val = withUnit(val, n.v); }
      return val;
    }
    if (t.t === '(') {
      p++;
      let val = expr();
      if (!peek() || peek().t !== ')') fail('Missing ")"');
      p++;
      const n = peek();
      if (n && n.t === 'id' && isUnit(n.v) && !vars[n.v]) { p++; val = withUnit(val, n.v); }
      return val;
    }
    if (t.t === 'id') {
      p++;
      if (t.v === 'pi') return { v: Math.PI, L: 0, A: false };
      if (FN[t.v]) {
        if (!peek() || peek().t !== '(') fail(t.v + ' needs parentheses');
        p++;
        const a = expr();
        if (!peek() || peek().t !== ')') fail('Missing ")"');
        p++;
        if (t.v === 'sin' || t.v === 'cos' || t.v === 'tan') return { v: FN[t.v](a.A ? a.v : a.v * Math.PI / 180), L: 0, A: false };
        if (t.v === 'sqrt') { if (a.L % 2) fail('sqrt of a length'); return { v: Math.sqrt(a.v), L: a.L / 2, A: false }; }
        return { v: FN[t.v](a.v), L: a.L, A: a.A };
      }
      if (vars[t.v]) return { v: vars[t.v].v, L: vars[t.v].L || 0, A: !!vars[t.v].A };
      fail('Unknown name "' + t.v + '"');
    }
    fail('Unexpected "' + t.t + '"');
  }
  function power() {
    const b = primary();
    if (peek() && peek().t === '^') {
      p++;
      const e = unary();
      if (e.L !== 0 || e.A) fail('An exponent must be a plain number');
      return { v: Math.pow(b.v, e.v), L: b.L * e.v, A: false };
    }
    return b;
  }
  function unary() {
    const t = peek();
    if (t && t.t === '-') { p++; const a = unary(); return { v: -a.v, L: a.L, A: a.A }; }
    if (t && t.t === '+') { p++; return unary(); }
    return power();
  }
  function term() {
    let a = unary();
    while (peek() && (peek().t === '*' || peek().t === '/')) {
      const op = toks[p++].t;
      const b = unary();
      if (op === '*') a = { v: a.v * b.v, L: a.L + b.L, A: a.A || b.A };
      else {
        if (b.v === 0) fail('Division by zero');
        a = { v: a.v / b.v, L: a.L - b.L, A: a.A && !b.A };
      }
    }
    return a;
  }
  function expr() {
    let a = term();
    while (peek() && (peek().t === '+' || peek().t === '-')) {
      const op = toks[p++].t;
      a = addish(a, term(), op === '+' ? 1 : -1);
    }
    return a;
  }
  try {
    const r = expr();
    if (p < toks.length) fail('Unexpected "' + (toks[p].v !== undefined ? toks[p].v : toks[p].t) + '"');
    if (!isFinite(r.v)) fail('The result is not a number');
    if (kind === 'length') {
      if (r.A) fail('Expected a length, got an angle');
      if (r.L === 1) return { ok: true, value: r.v };
      if (r.L === 0) return { ok: true, value: r.v * UNITS[unit] };
      fail('The result is not a length');
    }
    if (kind === 'angle') {
      if (r.L !== 0) fail('Expected an angle, got a length');
      return { ok: true, value: r.A ? r.v : r.v * Math.PI / 180 };
    }
    return { ok: true, value: r.v };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ---------------------------------------------------------------------
// Document model
// ---------------------------------------------------------------------
function newDoc() {
  const d = {
    app: 'PrecisionSketch', version: 1,
    units: 'mm', precision: 2,
    grid: { show: true, snap: false },
    nextId: 1,
    points: {}, entities: {}, constraints: {},
    shapes: {}, zTop: 0
  };
  d.points.O = { id: 'O', x: 0, y: 0, ref: true };
  d.points.OX = { id: 'OX', x: 1, y: 0, ref: true, hidden: true };
  d.points.OY = { id: 'OY', x: 0, y: 1, ref: true, hidden: true };
  d.entities.AX = { id: 'AX', type: 'line', p1: 'O', p2: 'OX', ref: true, construction: true };
  d.entities.AY = { id: 'AY', type: 'line', p1: 'O', p2: 'OY', ref: true, construction: true };
  return d;
}
function nid(doc, prefix) { return prefix + (doc.nextId++); }
function addPoint(doc, x, y, owner) {
  const id = nid(doc, 'p');
  doc.points[id] = { id, x, y, owner };
  return id;
}
function addLine(doc, x1, y1, x2, y2) {
  const id = nid(doc, 'e');
  doc.entities[id] = { id, type: 'line', p1: addPoint(doc, x1, y1, id), p2: addPoint(doc, x2, y2, id), construction: false };
  return id;
}
function addCircle(doc, cx, cy, r) {
  const id = nid(doc, 'e');
  doc.entities[id] = { id, type: 'circle', c: addPoint(doc, cx, cy, id), r, construction: false };
  return id;
}
// Arc runs counter-clockwise from s to e around c.
function addArc(doc, cx, cy, sx, sy, ex, ey) {
  const id = nid(doc, 'e');
  doc.entities[id] = {
    id, type: 'arc', c: addPoint(doc, cx, cy, id), s: addPoint(doc, sx, sy, id), e: addPoint(doc, ex, ey, id),
    construction: false
  };
  return id;
}
function addCon(doc, c) {
  c.id = nid(doc, 'c');
  doc.constraints[c.id] = c;
  return c.id;
}
function addRect(doc, x1, y1, x2, y2) {
  const b = addLine(doc, x1, y1, x2, y1), r = addLine(doc, x2, y1, x2, y2);
  const t = addLine(doc, x2, y2, x1, y2), l = addLine(doc, x1, y2, x1, y1);
  const E = doc.entities;
  addCon(doc, { type: 'coincident', refs: [E[b].p2, E[r].p1] });
  addCon(doc, { type: 'coincident', refs: [E[r].p2, E[t].p1] });
  addCon(doc, { type: 'coincident', refs: [E[t].p2, E[l].p1] });
  addCon(doc, { type: 'coincident', refs: [E[l].p2, E[b].p1] });
  addCon(doc, { type: 'horizontal', refs: [b] });
  addCon(doc, { type: 'vertical', refs: [r] });
  addCon(doc, { type: 'horizontal', refs: [t] });
  addCon(doc, { type: 'vertical', refs: [l] });
  return { lines: [b, r, t, l], p1: E[b].p1, p2: E[r].p2 };
}
function entPoints(e) {
  if (e.type === 'line') return [e.p1, e.p2];
  if (e.type === 'circle') return [e.c];
  return [e.c, e.s, e.e];
}
function kindOf(doc, id) {
  if (doc.points[id]) return 'point';
  const e = doc.entities[id];
  return e ? e.type : null;
}
function isCurveKind(k) { return k === 'circle' || k === 'arc'; }
const DIM_TYPES = { distance: 1, angle: 1, radius: 1, diameter: 1 };
function isDim(c) { return !!DIM_TYPES[c.type]; }
function conValid(doc, c) {
  if (!c || !c.refs) return false;
  for (const r of c.refs) if (!doc.points[r] && !doc.entities[r]) return false;
  return true;
}
function conPoints(doc, c) {
  const out = [];
  for (const r of c.refs) {
    if (doc.points[r]) out.push(r);
    else if (doc.entities[r]) for (const p of entPoints(doc.entities[r])) out.push(p);
  }
  return out;
}
function arcRadius(doc, e) {
  const c = doc.points[e.c], s = doc.points[e.s];
  return Math.hypot(s.x - c.x, s.y - c.y);
}
function entRadius(doc, e) { return e.type === 'circle' ? e.r : arcRadius(doc, e); }

// Remove entities / constraints. ids: entity or constraint ids.
function deleteItems(doc, ids) {
  const gonePts = new Set(), goneEnts = new Set();
  let n = 0;
  for (const id of ids) {
    const e = doc.entities[id];
    if (e && !e.ref) {
      for (const p of entPoints(e)) { gonePts.add(p); delete doc.points[p]; }
      goneEnts.add(id);
      delete doc.entities[id];
      n++;
    } else if (doc.constraints[id]) { delete doc.constraints[id]; n++; }
  }
  for (const cid in doc.constraints) {
    const c = doc.constraints[cid];
    if (c.refs.some(r => gonePts.has(r) || goneEnts.has(r))) delete doc.constraints[cid];
  }
  return n;
}

const CON_LABEL = {
  coincident: 'Coincident', pointOn: 'Coincident', horizontal: 'Horizontal', vertical: 'Vertical',
  parallel: 'Parallel', perpendicular: 'Perpendicular', tangent: 'Tangent', equal: 'Equal',
  concentric: 'Concentric', midpoint: 'Midpoint', fix: 'Fix',
  distance: 'Distance', angle: 'Angle', radius: 'Radius', diameter: 'Diameter'
};
function entityLabel(doc, id) {
  if (id === 'O') return 'Origin';
  if (id === 'AX') return 'X axis';
  if (id === 'AY') return 'Y axis';
  const p = doc.points[id];
  if (p) {
    const o = doc.entities[p.owner];
    if (!o) return 'Point';
    const role = o.type === 'line' ? (o.p1 === id ? 'start' : 'end') : (o.c === id ? 'center' : (o.s === id ? 'start' : 'end'));
    return entityLabel(doc, o.id) + ' ' + role;
  }
  const e = doc.entities[id];
  if (!e) return '?';
  const name = e.type === 'line' ? 'Line' : e.type === 'circle' ? 'Circle' : 'Arc';
  return name + ' ' + id.replace(/^\D+/, '');
}
function describeCon(doc, c) {
  let s = CON_LABEL[c.type] || c.type;
  if (isDim(c)) {
    const v = c.driven ? measureCon(doc, c) : c.value;
    if (c.type === 'angle') s += ' ' + fmtNum(v * 180 / Math.PI, doc.precision) + '°';
    else s += ' ' + fmtLen(v, doc);
  }
  return s + ' (' + c.refs.map(r => entityLabel(doc, r)).join(', ') + ')';
}

// Turn a list of picked ids into a constraint record for the given tool.
function makeConstraint(doc, type, picks) {
  const k = picks.map(id => kindOf(doc, id));
  const need = m => ({ need: m }), err = m => ({ error: m });
  const two = (ok, msg1, msgBad) => {
    if (picks.length < 2) return need(msg1);
    if (picks[0] === picks[1]) return err('Pick two different items');
    return ok() || err(msgBad);
  };
  switch (type) {
    case 'coincident':
      return two(() => {
        if (k[0] === 'point' && k[1] === 'point') return { con: { type: 'coincident', refs: [picks[0], picks[1]] } };
        const pi = k[0] === 'point' ? 0 : k[1] === 'point' ? 1 : -1;
        if (pi < 0) return null;
        const pt = picks[pi], en = picks[1 - pi];
        if (doc.points[pt].owner === en) return { error: 'That point already belongs to this curve' };
        return { con: { type: 'pointOn', refs: [pt, en] } };
      }, 'Pick a point, then another point, line or circle', 'Coincident needs at least one point');
    case 'horizontal':
    case 'vertical':
      if (!picks.length) return need('Pick a line, or two points');
      if (k[0] === 'line') {
        if (doc.entities[picks[0]].ref) return err('The axes are already fixed');
        return { con: { type, refs: [picks[0]] } };
      }
      if (k[0] !== 'point') return err('Pick a line, or two points');
      if (picks.length < 2) return need('Pick the second point');
      if (k[1] !== 'point' || picks[0] === picks[1]) return err('Pick a second point');
      return { con: { type, refs: [picks[0], picks[1]] } };
    case 'parallel':
    case 'perpendicular':
      return two(() => (k[0] === 'line' && k[1] === 'line') ? { con: { type, refs: [picks[0], picks[1]] } } : null,
        'Pick two lines', 'Pick two lines');
    case 'tangent':
      return two(() => {
        const nl = k.filter(x => x === 'line').length, nc = k.filter(isCurveKind).length;
        if ((nl === 1 && nc === 1) || nc === 2) return { con: { type, refs: [picks[0], picks[1]] } };
        return null;
      }, 'Pick a line and a circle or arc, or two curves', 'Tangent needs a line and a curve, or two curves');
    case 'equal':
      return two(() => {
        if (k[0] === 'line' && k[1] === 'line') return { con: { type, refs: [picks[0], picks[1]] } };
        if (isCurveKind(k[0]) && isCurveKind(k[1])) return { con: { type, refs: [picks[0], picks[1]] } };
        return null;
      }, 'Pick two lines, or two circles or arcs', 'Equal needs two lines, or two circles or arcs');
    case 'concentric':
      return two(() => {
        if (isCurveKind(k[0]) && isCurveKind(k[1])) return { con: { type, refs: [picks[0], picks[1]] } };
        const pi = k[0] === 'point' ? 0 : k[1] === 'point' ? 1 : -1;
        if (pi >= 0 && isCurveKind(k[1 - pi])) return { con: { type: 'coincident', refs: [picks[pi], doc.entities[picks[1 - pi]].c] } };
        return null;
      }, 'Pick two circles or arcs', 'Concentric needs two circles or arcs');
    case 'midpoint':
      return two(() => {
        const pi = k[0] === 'point' ? 0 : k[1] === 'point' ? 1 : -1;
        if (pi < 0 || k[1 - pi] !== 'line') return null;
        if (doc.points[picks[pi]].owner === picks[1 - pi]) return { error: 'Pick a point that is not an end of that line' };
        return { con: { type, refs: [picks[pi], picks[1 - pi]] } };
      }, 'Pick a point and a line', 'Midpoint needs a point and a line');
    case 'fix':
      if (!picks.length) return need('Pick a point or a curve to lock in place');
      if ((doc.points[picks[0]] || doc.entities[picks[0]]).ref) return err('The origin and axes are already fixed');
      return { con: { type, refs: [picks[0]] } };
  }
  return err('Unknown constraint');
}

// Current measured value of a dimension (mm or radians).
function measureCon(doc, c) {
  const P = id => doc.points[id], E = id => doc.entities[id];
  if (c.type === 'radius') return entRadius(doc, E(c.refs[0]));
  if (c.type === 'diameter') return 2 * entRadius(doc, E(c.refs[0]));
  if (c.type === 'angle') {
    const a = E(c.refs[0]), b = E(c.refs[1]);
    const s1 = c.rev && c.rev[0] ? -1 : 1, s2 = c.rev && c.rev[1] ? -1 : 1;
    const ux = s1 * (P(a.p2).x - P(a.p1).x), uy = s1 * (P(a.p2).y - P(a.p1).y);
    const vx = s2 * (P(b.p2).x - P(b.p1).x), vy = s2 * (P(b.p2).y - P(b.p1).y);
    return normAng(Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy));
  }
  if (c.type === 'distance') {
    const g = distRefs(doc, c);
    if (g.kind === 'pp') {
      const a = P(g.a), b = P(g.b);
      if (c.mode === 'h') return Math.abs(b.x - a.x);
      if (c.mode === 'v') return Math.abs(b.y - a.y);
      return Math.hypot(b.x - a.x, b.y - a.y);
    }
    const q = P(g.p), l = E(g.line), a = P(l.p1), b = P(l.p2);
    const L = Math.hypot(b.x - a.x, b.y - a.y) || 1;
    return Math.abs(((b.x - a.x) * (q.y - a.y) - (b.y - a.y) * (q.x - a.x)) / L);
  }
  return 0;
}
// Resolve what a distance dimension measures.
function distRefs(doc, c) {
  const r = c.refs, k = r.map(id => kindOf(doc, id));
  if (r.length === 1) { const l = doc.entities[r[0]]; return { kind: 'pp', a: l.p1, b: l.p2 }; }
  if (k[0] === 'point' && k[1] === 'point') return { kind: 'pp', a: r[0], b: r[1] };
  if (k[0] === 'point') return { kind: 'pl', p: r[0], line: r[1] };
  if (k[1] === 'point') return { kind: 'pl', p: r[1], line: r[0] };
  return { kind: 'pl', p: doc.entities[r[0]].p1, line: r[1] };
}

// ---------------------------------------------------------------------
// Solver
// ---------------------------------------------------------------------
class UF {
  constructor() { this.p = new Map(); }
  find(a) {
    let r = a, q;
    while ((q = this.p.get(r)) !== undefined && q !== r) r = q;
    let c = a;
    while (c !== r) { const nx = this.p.get(c); this.p.set(c, r); c = nx; }
    return r;
  }
  union(a, b) {
    const ra = this.find(a), rb = this.find(b);
    if (ra !== rb) this.p.set(ra, rb);
  }
}

// Residual terms. Each returns its value and, when G is given, adds its
// gradient into G (indexed by parameter). Points are addressed by the
// index of their x parameter; y is the next index.
function tDist(P, G, a, b, w) {
  const dx = P[b] - P[a], dy = P[b + 1] - P[a + 1];
  const d = Math.sqrt(dx * dx + dy * dy);
  if (G && d > 1e-14) {
    const ux = w * dx / d, uy = w * dy / d;
    G[b] += ux; G[b + 1] += uy; G[a] -= ux; G[a + 1] -= uy;
  }
  return w * d;
}
function tRad(P, G, rs, w) {
  if (rs.ir !== undefined) { if (G) G[rs.ir] += w; return w * P[rs.ir]; }
  return tDist(P, G, rs.c, rs.s, w);
}
function tCross(P, G, a, b, c, d, w) {
  const ux = P[b] - P[a], uy = P[b + 1] - P[a + 1], vx = P[d] - P[c], vy = P[d + 1] - P[c + 1];
  if (G) {
    G[b] += w * vy; G[b + 1] -= w * vx; G[a] -= w * vy; G[a + 1] += w * vx;
    G[d] -= w * uy; G[d + 1] += w * ux; G[c] += w * uy; G[c + 1] -= w * ux;
  }
  return w * (ux * vy - uy * vx);
}
function tDot(P, G, a, b, c, d, w) {
  const ux = P[b] - P[a], uy = P[b + 1] - P[a + 1], vx = P[d] - P[c], vy = P[d + 1] - P[c + 1];
  if (G) {
    G[b] += w * vx; G[b + 1] += w * vy; G[a] -= w * vx; G[a + 1] -= w * vy;
    G[d] += w * ux; G[d + 1] += w * uy; G[c] -= w * ux; G[c + 1] -= w * uy;
  }
  return w * (ux * vx + uy * vy);
}
// Signed distance of q from the line a->b (positive on the left).
function tSDist(P, G, a, b, q, w) {
  const ux = P[b] - P[a], uy = P[b + 1] - P[a + 1], vx = P[q] - P[a], vy = P[q + 1] - P[a + 1];
  const L = Math.sqrt(ux * ux + uy * uy);
  if (L < 1e-14) return 0;
  const cr = ux * vy - uy * vx;
  if (G) {
    const k = w / L, m = w * cr / (L * L * L);
    G[q] += -k * uy; G[q + 1] += k * ux;
    G[b] += k * vy - m * ux; G[b + 1] += -k * vx - m * uy;
    G[a] += k * (uy - vy) + m * ux; G[a + 1] += k * (vx - ux) + m * uy;
  }
  return w * cr / L;
}
// w * wrap(angle from u=s1(b-a) to v=s2(d-c), minus theta)
function tAngle(P, G, a, b, c, d, s1, s2, theta, w) {
  const ux = s1 * (P[b] - P[a]), uy = s1 * (P[b + 1] - P[a + 1]);
  const vx = s2 * (P[d] - P[c]), vy = s2 * (P[d + 1] - P[c + 1]);
  const uu = ux * ux + uy * uy, vv = vx * vx + vy * vy;
  if (uu < 1e-28 || vv < 1e-28) return 0;
  const phi = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy);
  if (G) {
    const gvx = -vy / vv * w * s2, gvy = vx / vv * w * s2;
    const gux = uy / uu * w * s1, guy = -ux / uu * w * s1;
    G[d] += gvx; G[d + 1] += gvy; G[c] -= gvx; G[c + 1] -= gvy;
    G[b] += gux; G[b + 1] += guy; G[a] -= gux; G[a + 1] -= guy;
  }
  return w * wrapPi(phi - theta);
}

function buildSystem(doc) {
  const uf = new UF();
  const cons = [];
  for (const id in doc.constraints) {
    const c = doc.constraints[id];
    if (conValid(doc, c)) cons.push(c);
  }
  for (const c of cons) {
    if (c.type === 'coincident') uf.union(c.refs[0], c.refs[1]);
    else if (c.type === 'concentric') uf.union(doc.entities[c.refs[0]].c, doc.entities[c.refs[1]].c);
  }
  // fixed classes: reference geometry and Fix constraints
  const fixedRoot = new Set(), fixedRad = new Set(), anchor = new Map();
  for (const id in doc.points) {
    if (doc.points[id].ref) { const r = uf.find(id); fixedRoot.add(r); anchor.set(r, id); }
  }
  for (const c of cons) {
    if (c.type !== 'fix') continue;
    const t = c.refs[0];
    const pts = doc.points[t] ? [t] : entPoints(doc.entities[t]);
    for (const p of pts) { const r = uf.find(p); fixedRoot.add(r); if (!anchor.has(r)) anchor.set(r, p); }
    if (!doc.points[t] && doc.entities[t].type === 'circle') fixedRad.add(t);
  }
  // parameter table: one x/y pair per point class, one radius per circle
  const sums = new Map();
  for (const id in doc.points) {
    const r = uf.find(id), p = doc.points[id];
    let s = sums.get(r);
    if (!s) sums.set(r, s = { x: 0, y: 0, n: 0 });
    s.x += p.x; s.y += p.y; s.n++;
  }
  const px = new Map(), vals = [], fixed = [];
  for (const [r, s] of sums) {
    let x = s.x / s.n, y = s.y / s.n;
    if (anchor.has(r)) { const a = doc.points[anchor.get(r)]; x = a.x; y = a.y; }
    px.set(r, vals.length);
    const f = fixedRoot.has(r) ? 1 : 0;
    vals.push(x, y); fixed.push(f, f);
  }
  const pr = new Map();
  for (const id in doc.entities) {
    const e = doc.entities[id];
    if (e.type === 'circle') { pr.set(id, vals.length); vals.push(e.r); fixed.push(fixedRad.has(id) ? 1 : 0); }
  }
  const P = Float64Array.from(vals);
  const nP = P.length;
  const varOf = new Int32Array(nP), paramOfVar = [];
  for (let i = 0; i < nP; i++) {
    if (fixed[i]) varOf[i] = -1;
    else { varOf[i] = paramOfVar.length; paramOfVar.push(i); }
  }
  const X = pid => px.get(uf.find(pid));
  const radSpec = e => e.type === 'circle' ? { ir: pr.get(e.id) } : { c: X(e.c), s: X(e.s) };
  const radParams = rs => rs.ir !== undefined ? [rs.ir] : [rs.c, rs.c + 1, rs.s, rs.s + 1];
  const radNow = rs => rs.ir !== undefined ? P[rs.ir] : Math.hypot(P[rs.s] - P[rs.c], P[rs.s + 1] - P[rs.c + 1]);
  const lenNow = (a, b) => Math.hypot(P[b] - P[a], P[b + 1] - P[a + 1]);
  const pp = (...xs) => { const o = []; for (const x of xs) o.push(x, x + 1); return o; };

  // which curves each point class lies on (from point-on-curve constraints)
  const onMap = new Map();
  for (const c of cons) {
    if (c.type !== 'pointOn') continue;
    const k = X(c.refs[0]);
    let s = onMap.get(k);
    if (!s) onMap.set(k, s = new Set());
    s.add(c.refs[1]);
  }
  const isOn = (ix, entId) => { const s = onMap.get(ix); return !!s && s.has(entId); };

  const eqs = [];
  const add = (cid, plist, ev) => {
    const u = Array.from(new Set(plist));
    eqs.push({ cid, params: Int32Array.from(u), ev });
  };
  const E = doc.entities;

  // each arc keeps its two ends at the same distance from the centre
  for (const id in E) {
    const e = E[id];
    if (e.type !== 'arc') continue;
    const c = X(e.c), s = X(e.s), en = X(e.e);
    add('@' + id, pp(c, s, en), (P, G) => tDist(P, G, c, s, 1) + tDist(P, G, c, en, -1));
  }

  for (const con of cons) {
    const cid = con.id, r = con.refs;
    if (isDim(con) && con.driven) continue;
    switch (con.type) {
      case 'coincident': case 'concentric': case 'fix': break;
      case 'pointOn': {
        const q = X(r[0]), e = E[r[1]];
        if (e.type === 'line') {
          const a = X(e.p1), b = X(e.p2);
          add(cid, pp(a, b, q), (P, G) => tSDist(P, G, a, b, q, 1));
        } else {
          const c = X(e.c), rs = radSpec(e);
          add(cid, pp(c, q).concat(radParams(rs)), (P, G) => tDist(P, G, c, q, 1) + tRad(P, G, rs, -1));
        }
        break;
      }
      case 'horizontal': case 'vertical': {
        let a, b;
        if (r.length === 1) { a = X(E[r[0]].p1); b = X(E[r[0]].p2); } else { a = X(r[0]); b = X(r[1]); }
        const o = con.type === 'horizontal' ? 1 : 0;
        const ia = a + o, ib = b + o;
        add(cid, [ia, ib], (P, G) => { if (G) { G[ib] += 1; G[ia] -= 1; } return P[ib] - P[ia]; });
        break;
      }
      case 'parallel': case 'perpendicular': {
        const l1 = E[r[0]], l2 = E[r[1]];
        const a = X(l1.p1), b = X(l1.p2), c = X(l2.p1), d = X(l2.p2);
        const w = 1 / Math.max(lenNow(a, b), lenNow(c, d), 1e-9);
        if (con.type === 'parallel') add(cid, pp(a, b, c, d), (P, G) => tCross(P, G, a, b, c, d, w));
        else add(cid, pp(a, b, c, d), (P, G) => tDot(P, G, a, b, c, d, w));
        break;
      }
      case 'tangent': {
        let e1 = E[r[0]], e2 = E[r[1]];
        if (e1.type !== 'line' && e2.type === 'line') { const t = e1; e1 = e2; e2 = t; }
        if (e1.type === 'line') {
          const a = X(e1.p1), b = X(e1.p2), c = X(e2.c), rs = radSpec(e2);
          // if the line meets the curve at a shared point, "distance = radius"
          // loses its slope there; use "radius is perpendicular to the line"
          let sh = -1;
          for (const lp of [a, b]) {
            if (e2.type === 'arc' && (lp === X(e2.s) || lp === X(e2.e))) sh = lp;
            else if (isOn(lp, e2.id)) sh = lp;
          }
          if (sh < 0 && e2.type === 'arc') for (const ap of [X(e2.s), X(e2.e)]) if (isOn(ap, e1.id)) sh = ap;
          if (sh >= 0) {
            const S = sh, w = 1 / Math.max(lenNow(a, b), 1e-9);
            add(cid, pp(S, c, a, b), (P, G) => tDot(P, G, S, c, a, b, w));
          } else {
            const s = tSDist(P, null, a, b, c, 1) >= 0 ? 1 : -1;
            add(cid, pp(a, b, c).concat(radParams(rs)), (P, G) => tSDist(P, G, a, b, c, 1) + tRad(P, G, rs, -s));
          }
        } else {
          const c1 = X(e1.c), c2 = X(e2.c), r1 = radSpec(e1), r2 = radSpec(e2);
          let sh = -1;
          const ends = e => e.type === 'arc' ? [X(e.s), X(e.e)] : [];
          for (const p1 of ends(e1)) { if (ends(e2).indexOf(p1) >= 0 || isOn(p1, e2.id)) sh = p1; }
          for (const p2 of ends(e2)) { if (isOn(p2, e1.id)) sh = p2; }
          if (sh >= 0) {
            const S = sh, w = 1 / Math.max(radNow(r1), radNow(r2), 1e-9);
            add(cid, pp(S, c1, c2), (P, G) => tCross(P, G, S, c1, S, c2, w));
          } else {
            const d = lenNow(c1, c2), R1 = radNow(r1), R2 = radNow(r2);
            const ps = pp(c1, c2).concat(radParams(r1), radParams(r2));
            if (Math.abs(d - (R1 + R2)) <= Math.abs(d - Math.abs(R1 - R2))) {
              add(cid, ps, (P, G) => tDist(P, G, c1, c2, 1) + tRad(P, G, r1, -1) + tRad(P, G, r2, -1));
            } else {
              const sg = R1 >= R2 ? 1 : -1;
              add(cid, ps, (P, G) => tDist(P, G, c1, c2, 1) + tRad(P, G, r1, -sg) + tRad(P, G, r2, sg));
            }
          }
        }
        break;
      }
      case 'equal': {
        const e1 = E[r[0]], e2 = E[r[1]];
        if (e1.type === 'line') {
          const a = X(e1.p1), b = X(e1.p2), c = X(e2.p1), d = X(e2.p2);
          add(cid, pp(a, b, c, d), (P, G) => tDist(P, G, a, b, 1) + tDist(P, G, c, d, -1));
        } else {
          const r1 = radSpec(e1), r2 = radSpec(e2);
          add(cid, radParams(r1).concat(radParams(r2)), (P, G) => tRad(P, G, r1, 1) + tRad(P, G, r2, -1));
        }
        break;
      }
      case 'midpoint': {
        const q = X(r[0]), l = E[r[1]], a = X(l.p1), b = X(l.p2);
        for (let o = 0; o < 2; o++) {
          const iq = q + o, ia = a + o, ib = b + o;
          add(cid, [iq, ia, ib], (P, G) => {
            if (G) { G[iq] += 1; G[ia] -= 0.5; G[ib] -= 0.5; }
            return P[iq] - 0.5 * (P[ia] + P[ib]);
          });
        }
        break;
      }
      case 'distance': {
        const g = distRefs(doc, con), D = con.value;
        if (g.kind === 'pp') {
          const a = X(g.a), b = X(g.b);
          if (con.mode === 'h' || con.mode === 'v') {
            const o = con.mode === 'h' ? 0 : 1, ia = a + o, ib = b + o;
            const s = P[ib] - P[ia] >= 0 ? 1 : -1;
            add(cid, [ia, ib], (P, G) => { if (G) { G[ib] += s; G[ia] -= s; } return s * (P[ib] - P[ia]) - D; });
          } else {
            add(cid, pp(a, b), (P, G) => tDist(P, G, a, b, 1) - D);
          }
        } else {
          const q = X(g.p), l = E[g.line], a = X(l.p1), b = X(l.p2);
          const s = tSDist(P, null, a, b, q, 1) >= 0 ? 1 : -1;
          add(cid, pp(a, b, q), (P, G) => tSDist(P, G, a, b, q, s) - D);
        }
        break;
      }
      case 'angle': {
        const l1 = E[r[0]], l2 = E[r[1]];
        const a = X(l1.p1), b = X(l1.p2), c = X(l2.p1), d = X(l2.p2);
        const s1 = con.rev && con.rev[0] ? -1 : 1, s2 = con.rev && con.rev[1] ? -1 : 1;
        const w = Math.max(Math.min(lenNow(a, b), lenNow(c, d)), 1e-9), th = con.value;
        add(cid, pp(a, b, c, d), (P, G) => tAngle(P, G, a, b, c, d, s1, s2, th, w));
        break;
      }
      case 'radius': case 'diameter': {
        const rs = radSpec(E[r[0]]), k = con.type === 'diameter' ? 2 : 1, D = con.value;
        add(cid, radParams(rs), (P, G) => tRad(P, G, rs, k) - D);
        break;
      }
    }
  }

  // connected components over variables
  const nV = paramOfVar.length;
  const par = new Int32Array(nV);
  for (let i = 0; i < nV; i++) par[i] = i;
  const find = v => { while (par[v] !== v) { par[v] = par[par[v]]; v = par[v]; } return v; };
  const constEqs = [];
  for (const e of eqs) {
    let first = -1;
    for (const p of e.params) {
      const v = varOf[p];
      if (v < 0) continue;
      if (first < 0) first = v; else { const a = find(first), b = find(v); if (a !== b) par[a] = b; }
    }
    e.v0 = first;
    if (first < 0) constEqs.push(e);
  }
  const compIdx = new Map(), comps = [], compOfVar = new Int32Array(nV).fill(-1);
  for (const e of eqs) {
    if (e.v0 < 0) continue;
    const root = find(e.v0);
    let ci = compIdx.get(root);
    if (ci === undefined) { ci = comps.length; compIdx.set(root, ci); comps.push({ eqs: [], vars: [] }); }
    comps[ci].eqs.push(e);
  }
  for (let v = 0; v < nV; v++) {
    const ci = compIdx.get(find(v));
    if (ci !== undefined) { compOfVar[v] = ci; comps[ci].vars.push(v); }
  }
  // Radii are damped harder than positions: when there is a choice, the
  // solver moves a circle rather than resizing it.
  const isRad = new Uint8Array(nP), dampW = new Float64Array(nP).fill(1);
  for (const [, ir] of pr) { isRad[ir] = 1; dampW[ir] = RADIUS_STIFFNESS; }
  return {
    doc, uf, P, G: new Float64Array(nP), varOf, paramOfVar, nVars: nV, isRad, dampW,
    X, radParam: id => pr.get(id), eqs, comps, constEqs, compOfVar, cons
  };
}

function writeBack(sys) {
  const doc = sys.doc, P = sys.P;
  for (const id in doc.points) {
    const ix = sys.X(id), p = doc.points[id];
    p.x = P[ix]; p.y = P[ix + 1];
  }
  for (const id in doc.entities) {
    const e = doc.entities[id];
    if (e.type === 'circle') e.r = P[sys.radParam(id)];
  }
}

// --- sparse (envelope) Cholesky --------------------------------------
// Row i of the lower triangle is stored from column fc[i] to i.
function cholEnv(n, fc, rs, L, rankTol, dep) {
  let absTol = 0;
  if (dep) {
    // a column whose size is numerically nothing next to the others
    // (degenerate geometry) counts as dependent too
    for (let i = 0; i < n; i++) { const v = L[rs[i] + i - fc[i]]; if (v > absTol) absTol = v; }
    absTol *= 1e-14;
  }
  for (let i = 0; i < n; i++) {
    const fi = fc[i], ri = rs[i] - fi;
    for (let j = fi; j < i; j++) {
      const fj = fc[j], rj = rs[j] - fj;
      let s = L[ri + j];
      for (let k = fi > fj ? fi : fj; k < j; k++) s -= L[ri + k] * L[rj + k];
      const djj = L[rj + j];
      L[ri + j] = djj > 0 ? s / djj : 0;
    }
    const orig = L[ri + i];
    let d = orig;
    for (let k = fi; k < i; k++) { const t = L[ri + k]; d -= t * t; }
    if (dep) {
      if (!(orig > 1e-300) || d <= rankTol * orig || d <= absTol) { L[ri + i] = 0; dep[i] = 1; }
      else L[ri + i] = Math.sqrt(d);
    } else {
      if (!(d > 0)) return false;
      L[ri + i] = Math.sqrt(d);
    }
  }
  return true;
}
function cholSolve(n, fc, rs, L, b) {
  for (let i = 0; i < n; i++) {
    const fi = fc[i], ri = rs[i] - fi;
    let s = b[i];
    for (let k = fi; k < i; k++) s -= L[ri + k] * b[k];
    b[i] = s / L[ri + i];
  }
  for (let i = n - 1; i >= 0; i--) {
    const fi = fc[i], ri = rs[i] - fi;
    const x = b[i] / L[ri + i];
    b[i] = x;
    for (let k = fi; k < i; k++) b[k] -= L[ri + k] * x;
  }
}

// Reverse Cuthill-McKee ordering to keep the envelope narrow.
function rcmOrder(n, adj) {
  const deg = adj.map(s => s.size);
  const seen = new Uint8Array(n), order = [];
  const starts = Array.from({ length: n }, (_, i) => i).sort((a, b) => deg[a] - deg[b]);
  for (const s of starts) {
    if (seen[s]) continue;
    seen[s] = 1;
    const q = [s];
    for (let h = 0; h < q.length; h++) {
      const v = q[h];
      order.push(v);
      const nb = [];
      for (const u of adj[v]) if (!seen[u]) { seen[u] = 1; nb.push(u); }
      nb.sort((a, b) => deg[a] - deg[b]);
      for (const u of nb) q.push(u);
    }
  }
  return order.reverse();
}

// Local least-squares problem over the variables touched by a set of equations.
function makeLocal(sys, eqList) {
  const varOf = sys.varOf;
  const tmpIdx = new Map(), vars = [];
  for (const e of eqList) {
    for (const p of e.params) {
      const v = varOf[p];
      if (v >= 0 && !tmpIdx.has(v)) { tmpIdx.set(v, vars.length); vars.push(v); }
    }
  }
  const n = vars.length;
  const adj = Array.from({ length: n }, () => new Set());
  for (const e of eqList) {
    const ls = [];
    for (const p of e.params) { const v = varOf[p]; if (v >= 0) ls.push(tmpIdx.get(v)); }
    for (let a = 0; a < ls.length; a++) for (let b = a + 1; b < ls.length; b++) { adj[ls[a]].add(ls[b]); adj[ls[b]].add(ls[a]); }
  }
  const order = rcmOrder(n, adj);
  const newIdx = new Int32Array(n);
  for (let k = 0; k < n; k++) newIdx[order[k]] = k;
  const lpar = new Int32Array(n), dw = new Float64Array(n);
  for (let t = 0; t < n; t++) lpar[newIdx[t]] = sys.paramOfVar[vars[t]];
  for (let i = 0; i < n; i++) dw[i] = sys.dampW[lpar[i]];
  const fc = new Int32Array(n);
  for (let i = 0; i < n; i++) fc[i] = i;
  const lc = [];
  let maxK = 0;
  for (const e of eqList) {
    const c = new Int32Array(e.params.length);
    let mn = n;
    for (let k = 0; k < c.length; k++) {
      const v = varOf[e.params[k]];
      c[k] = v >= 0 ? newIdx[tmpIdx.get(v)] : -1;
      if (c[k] >= 0 && c[k] < mn) mn = c[k];
    }
    for (let k = 0; k < c.length; k++) if (c[k] >= 0 && fc[c[k]] > mn) fc[c[k]] = mn;
    lc.push(c);
    if (c.length > maxK) maxK = c.length;
  }
  const rs = new Int32Array(n + 1);
  for (let i = 0; i < n; i++) rs[i + 1] = rs[i] + (i - fc[i] + 1);
  const nnz = rs[n];
  return {
    n, fc, rs, lc, lpar, dw, eqs: eqList,
    A: new Float64Array(nnz), L: new Float64Array(nnz),
    g: new Float64Array(n), dx: new Float64Array(n), xb: new Float64Array(n),
    vals: new Float64Array(Math.max(maxK, 1))
  };
}
function evalLocal(sys, loc, withJ) {
  const P = sys.P, G = withJ ? sys.G : null, eqs = loc.eqs;
  const { A, g, fc, rs, lc, vals } = loc;
  if (withJ) { A.fill(0); g.fill(0); }
  let cost = 0, maxHard = 0;
  for (let k = 0; k < eqs.length; k++) {
    const e = eqs[k];
    const rv = e.ev(P, G);
    cost += rv * rv;
    if (!e.soft) { const a = Math.abs(rv); if (a > maxHard) maxHard = a; }
    if (!withJ) continue;
    const pl = e.params, c = lc[k], m = pl.length;
    for (let i = 0; i < m; i++) { vals[i] = G[pl[i]]; G[pl[i]] = 0; }
    for (let i = 0; i < m; i++) {
      const ci = c[i];
      if (ci < 0) continue;
      const vi = vals[i];
      if (vi === 0) continue;
      g[ci] += vi * rv;
      const base = rs[ci] - fc[ci];
      for (let j = 0; j < m; j++) {
        const cj = c[j];
        if (cj < 0 || cj > ci) continue;
        A[base + cj] += vi * vals[j];
      }
    }
  }
  if (cost !== cost) cost = Infinity;
  return { cost, maxHard };
}

// Levenberg-Marquardt from the current values. Uniform damping, so each
// step is close to the smallest move that reduces the residuals.
function lmSolve(sys, loc, opts) {
  opts = opts || {};
  const P = sys.P;
  const { n, fc, rs, A, L, g, dx, xb, lpar, dw } = loc;
  let st = evalLocal(sys, loc, true);
  let cost = st.cost, maxHard = st.maxHard, it = 0;
  if (n === 0) return { iters: 0, maxHard };
  const hasSoft = !!opts.soft;
  const maxIter = opts.maxIter || 100;
  const stepTol = opts.stepTol || 1e-13;
  let lam = opts.lam0 || 1e-6;
  while (it < maxIter) {
    if (!hasSoft && maxHard < TOL_GOAL) break;
    let gmax = 0, tr = 0;
    for (let i = 0; i < n; i++) { const a = Math.abs(g[i]); if (a > gmax) gmax = a; tr += A[rs[i] + i - fc[i]]; }
    if (gmax < 1e-15) break;
    const sc = tr / n > 1e-12 ? tr / n : 1;
    let accepted = false, dmax = 0;
    for (let tries = 0; tries < 14; tries++) {
      L.set(A);
      const mu = lam * sc;
      for (let i = 0; i < n; i++) L[rs[i] + i - fc[i]] += mu * dw[i];
      if (!cholEnv(n, fc, rs, L)) { lam *= 10; continue; }
      for (let i = 0; i < n; i++) dx[i] = -g[i];
      cholSolve(n, fc, rs, L, dx);
      dmax = 0;
      for (let i = 0; i < n; i++) {
        const p = lpar[i];
        xb[i] = P[p];
        P[p] += dx[i];
        const a = Math.abs(dx[i]);
        if (a > dmax) dmax = a;
      }
      const s2 = evalLocal(sys, loc, false);
      if (s2.cost < cost) { accepted = true; break; }
      for (let i = 0; i < n; i++) P[lpar[i]] = xb[i];
      lam *= 8;
      if (lam > 1e14) break;
    }
    if (!accepted) break;
    lam = Math.max(lam * 0.2, 1e-12);
    st = evalLocal(sys, loc, true);
    cost = st.cost; maxHard = st.maxHard;
    it++;
    if (dmax < stepTol) break;
  }
  return { iters: it, maxHard };
}

function eqResidual(sys, e) { return Math.abs(e.ev(sys.P, null)); }

// Solve every component that is not already satisfied.
function solveSystem(sys) {
  let maxRes = 0, iters = 0;
  const bad = new Set();
  for (const comp of sys.comps) {
    let m = 0;
    for (const e of comp.eqs) { const a = eqResidual(sys, e); if (a > m) m = a; }
    if (m >= TOL_GOAL) {
      const res = lmSolve(sys, comp.loc || (comp.loc = makeLocal(sys, comp.eqs)), { maxIter: 200 });
      iters += res.iters;
      m = res.maxHard;
    }
    if (!(m <= TOL)) {
      // at a least-squares minimum the constraints that still carry error
      // are the ones that clash
      const thr = Math.max(TOL, m * 1e-3);
      for (const e of comp.eqs) if (!(eqResidual(sys, e) <= thr)) bad.add(e.cid);
      if (!(m === m)) for (const e of comp.eqs) bad.add(e.cid);
    }
    if (!(m <= maxRes)) maxRes = m === m ? m : Infinity;
  }
  for (const e of sys.constEqs) {
    const a = eqResidual(sys, e);
    if (a > TOL) { bad.add(e.cid); if (a > maxRes) maxRes = a; }
  }
  // nothing may collapse: circles and arcs keep a radius, lines a length
  const P = sys.P, collapsed = [];
  for (const id in sys.doc.entities) {
    const e = sys.doc.entities[id];
    if (e.ref) continue;
    let size;
    if (e.type === 'circle') size = P[sys.radParam(id)];
    else {
      const a = sys.X(e.type === 'line' ? e.p1 : e.c), b = sys.X(e.type === 'line' ? e.p2 : e.s);
      size = Math.hypot(P[b] - P[a], P[b + 1] - P[a + 1]);
    }
    if (!(size > 1e-7)) { collapsed.push(id); maxRes = Math.max(maxRes, 1); }
  }
  return { ok: bad.size === 0 && !collapsed.length, maxRes, iters, bad, collapsed };
}

// Build, solve and write the result into the document.
function trySolve(doc) {
  const sys = buildSystem(doc);
  const res = solveSystem(sys);
  writeBack(sys);
  res.sys = sys;
  return res;
}

// Constraints to name when a solve fails: those still carrying error,
// plus Fix / Coincident constraints that pin the points they touch.
function clashList(doc, sys, bad, focusCid, collapsed) {
  const out = new Set();
  for (const cid of bad) if (cid[0] !== '@' && doc.constraints[cid]) out.add(cid);
  if (focusCid && doc.constraints[focusCid]) out.add(focusCid);
  // a curve squeezed to nothing: the constraints on that curve did it
  for (const id of collapsed || []) {
    for (const cid in doc.constraints) {
      const c = doc.constraints[cid];
      if (c.refs.indexOf(id) >= 0 && !(isDim(c) && c.driven)) out.add(cid);
    }
  }
  const classes = new Set();
  for (const cid of out) for (const p of conPoints(doc, doc.constraints[cid])) classes.add(sys.uf.find(p));
  for (const cid in doc.constraints) {
    const c = doc.constraints[cid];
    if (c.type !== 'fix' || !conValid(doc, c)) continue;
    if (conPoints(doc, c).some(p => classes.has(sys.uf.find(p)))) out.add(cid);
  }
  for (const cid of Array.from(out)) {
    const c = doc.constraints[cid];
    const pts = conPoints(doc, c);
    const roots = pts.map(p => sys.uf.find(p));
    if (new Set(roots).size < roots.length && pts.length <= 4) {
      for (const k in doc.constraints) {
        const cc = doc.constraints[k];
        if ((cc.type === 'coincident' || cc.type === 'concentric') && conValid(doc, cc) &&
          conPoints(doc, cc).some(p => pts.indexOf(p) >= 0)) out.add(k);
      }
    }
  }
  return Array.from(out);
}

function restoreInto(doc, snap) {
  const src = typeof snap === 'string' ? JSON.parse(snap) : snap;
  for (const k in doc) delete doc[k];
  Object.assign(doc, src);
  return doc;
}

// Apply a change; keep it only if the sketch still solves.
function applyChange(doc, mutate, focus) {
  const snap = JSON.stringify(doc);
  const focusCid = mutate(doc) || focus;
  const res = trySolve(doc);
  if (res.ok) return { ok: true, sys: res.sys, cid: focusCid };
  const clash = clashList(doc, res.sys, res.bad, focusCid, res.collapsed).map(cid => ({ cid, text: describeCon(doc, doc.constraints[cid]) }));
  const collapsed = res.collapsed.map(id => entityLabel(doc, id));
  restoreInto(doc, snap);
  return { ok: false, clash, collapsed, cid: focusCid };
}

// Change a dimension's value. If the direct solve fails, walk the value
// there in steps before giving up.
function setDimValue(doc, cid, value, expr) {
  const snap = JSON.stringify(doc);
  const old = doc.constraints[cid].value;
  const set = (v) => { const c = doc.constraints[cid]; c.value = v; };
  set(value);
  let res = trySolve(doc);
  if (!res.ok) {
    restoreInto(doc, snap);
    const N = 16;
    for (let i = 1; i <= N; i++) {
      set(old + (value - old) * i / N);
      res = trySolve(doc);
      if (!res.ok) break;
    }
  }
  if (!res.ok) {
    doc.constraints[cid].value = value;
    const clash = clashList(doc, res.sys, res.bad, cid, res.collapsed).map(k => ({ cid: k, text: describeCon(doc, doc.constraints[k]) }));
    const collapsed = res.collapsed.map(id => entityLabel(doc, id));
    restoreInto(doc, snap);
    return { ok: false, clash, collapsed };
  }
  const c = doc.constraints[cid];
  c.value = value;
  if (expr !== undefined) c.expr = expr;
  return { ok: true };
}

// ---------------------------------------------------------------------
// Degrees of freedom
// ---------------------------------------------------------------------
function mulberry(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function analyze(sys) {
  const nP = sys.P.length;
  const freeParam = new Uint8Array(nP);
  const redundant = new Set(), conflict = new Set();
  let dof = 0;
  for (let v = 0; v < sys.nVars; v++) {
    if (sys.compOfVar[v] < 0) { freeParam[sys.paramOfVar[v]] = 1; dof++; }
  }
  const rnd = mulberry(12345);
  for (const comp of sys.comps) {
    const loc = comp.loc || (comp.loc = makeLocal(sys, comp.eqs));
    const { n, fc, rs, A, L, lpar } = loc;
    evalLocal(sys, loc, true);
    L.set(A);
    const dep = new Uint8Array(n);
    cholEnv(n, fc, rs, L, 1e-9, dep);
    let nd = 0;
    for (let i = 0; i < n; i++) nd += dep[i];
    dof += nd;
    if (nd > 0) {
      // project random vectors onto the null space of the Jacobian; a
      // parameter that moves in any of them is still free
      let tr = 0;
      for (let i = 0; i < n; i++) tr += A[rs[i] + i - fc[i]];
      const eps = Math.max(1e-9 * tr / n, 1e-14);
      L.set(A);
      for (let i = 0; i < n; i++) L[rs[i] + i - fc[i]] += eps;
      let any = false;
      if (cholEnv(n, fc, rs, L)) {
        const z = new Float64Array(n);
        for (let k = 0; k < 3; k++) {
          for (let i = 0; i < n; i++) z[i] = rnd() * 2 - 1;
          for (let rep = 0; rep < 3; rep++) { cholSolve(n, fc, rs, L, z); for (let i = 0; i < n; i++) z[i] *= eps; }
          let zm = 0;
          for (let i = 0; i < n; i++) { const a = Math.abs(z[i]); if (a > zm) zm = a; }
          if (zm < 1e-12) continue;
          for (let i = 0; i < n; i++) if (Math.abs(z[i]) > 1e-6 * zm) { freeParam[lpar[i]] = 1; any = true; }
        }
      }
      if (!any) for (let i = 0; i < n; i++) freeParam[lpar[i]] = 1;
    }
    // redundant equations: rows that add nothing to the earlier ones
    const m = comp.eqs.length, rank = n - nd;
    if (m > rank && m * n * Math.max(rank, 1) < 4e8) {
      const Q = [];
      const colOf = new Map();
      for (let i = 0; i < n; i++) colOf.set(lpar[i], i);
      const G = sys.G;
      for (const e of comp.eqs) {
        const w = new Float64Array(n);
        e.ev(sys.P, G);
        for (const p of e.params) { const ci = colOf.get(p); if (ci !== undefined) w[ci] = G[p]; G[p] = 0; }
        let n0 = 0;
        for (let i = 0; i < n; i++) n0 += w[i] * w[i];
        n0 = Math.sqrt(n0);
        let isRed = n0 < 1e-12;
        if (!isRed) {
          for (let pass = 0; pass < 2; pass++) {
            for (const q of Q) {
              let d = 0;
              for (let i = 0; i < n; i++) d += w[i] * q[i];
              if (d !== 0) for (let i = 0; i < n; i++) w[i] -= d * q[i];
            }
          }
          let n1 = 0;
          for (let i = 0; i < n; i++) n1 += w[i] * w[i];
          n1 = Math.sqrt(n1);
          if (n1 < 1e-6 * n0) isRed = true;
          else { for (let i = 0; i < n; i++) w[i] /= n1; Q.push(w); }
        }
        if (isRed && e.cid[0] !== '@') redundant.add(e.cid);
      }
    }
  }
  for (const e of sys.eqs) {
    if (eqResidual(sys, e) > 1e-6) { if (e.cid[0] !== '@') conflict.add(e.cid); }
  }
  for (const e of sys.constEqs) {
    if (e.cid[0] !== '@' && !conflict.has(e.cid)) redundant.add(e.cid);
  }
  const ptFree = pid => { const ix = sys.X(pid); return !!(freeParam[ix] || freeParam[ix + 1]); };
  const entFree = id => {
    const e = sys.doc.entities[id];
    if (!e) return false;
    for (const p of entPoints(e)) if (ptFree(p)) return true;
    return e.type === 'circle' && !!freeParam[sys.radParam(id)];
  };
  return { dof, freeParam, redundant, conflict, ptFree, entFree };
}
function docDof(doc) { return analyze(buildSystem(doc)).dof; }

// Add a constraint only if it removes a degree of freedom (used for
// inferred constraints, so drawing never over-defines the sketch).
function addConIfUseful(doc, con) {
  const before = docDof(doc);
  const snap = JSON.stringify(doc);
  const id = addCon(doc, con);
  const res = trySolve(doc);
  if (!res.ok || analyze(res.sys).dof >= before) { restoreInto(doc, snap); return null; }
  return id;
}

// Add a dimension at its measured value. If the geometry it measures is
// already determined, it becomes a driven (reference) dimension.
function addDimension(doc, con) {
  con.value = measureCon(doc, con);
  const before = docDof(doc);
  const id = addCon(doc, con);
  const after = docDof(doc);
  if (after >= before) doc.constraints[id].driven = true;
  return id;
}

// ---------------------------------------------------------------------
// Dragging: a weak spring pulls the grabbed geometry toward the cursor,
// the constraints are re-solved, then polished to full accuracy.
// ---------------------------------------------------------------------
const SPRING = 0.05;
function beginDrag(sys, grabs) {
  const P = sys.P;
  const soft = [], comps = new Set(), holds = [];
  const touch = p => { const v = sys.varOf[p]; if (v >= 0) { const c = sys.compOfVar[v]; if (c >= 0) comps.add(c); } };
  // spring pulling one point toward a target
  const pull = (ix, t, w) => {
    for (let o = 0; o < 2; o++) {
      const ip = ix + o, key = o ? 'y' : 'x';
      soft.push({ cid: '~', soft: true, params: Int32Array.from([ip]), ev: (P, G) => { if (G) G[ip] += w; return w * (P[ip] - t[key]); } });
      touch(ip);
    }
  };
  // much weaker spring that keeps a point where it was on the last frame
  const hold = ix => { const t = { x: P[ix], y: P[ix + 1] }; holds.push({ ix, t }); pull(ix, t, SPRING * 0.1); };
  for (const g of grabs) {
    if (g.kind === 'point') {
      const ix = sys.X(g.pid);
      g.t = { x: P[ix], y: P[ix + 1] };
      pull(ix, g.t, SPRING);
    } else if (g.kind === 'radius') {
      // pull the curve itself to the cursor; prefer changing the radius
      // over moving the centre (circle) or the end points (arc)
      const e = sys.doc.entities[g.ent];
      const c = sys.X(e.c);
      const rs = e.type === 'circle' ? { ir: sys.radParam(e.id) } : { c, s: sys.X(e.s) };
      const t = g.t = { x: P[c] + 1, y: P[c + 1] };
      const ps = Array.from(new Set([c, c + 1].concat(rs.ir !== undefined ? [rs.ir] : [rs.s, rs.s + 1])));
      soft.push({
        cid: '~', soft: true, params: Int32Array.from(ps), ev: (P, G) => {
          const dx = t.x - P[c], dy = t.y - P[c + 1], d = Math.sqrt(dx * dx + dy * dy);
          if (G && d > 1e-14) { G[c] -= SPRING * dx / d; G[c + 1] -= SPRING * dy / d; }
          return SPRING * d + tRad(P, G, rs, -SPRING);
        }
      });
      for (const p of ps) touch(p);
      if (e.type === 'circle') hold(c); else { hold(sys.X(e.s)); hold(sys.X(e.e)); }
    }
  }
  let hard = [];
  for (const ci of comps) hard = hard.concat(sys.comps[ci].eqs);
  const all = hard.concat(soft);
  const locAll = makeLocal(sys, all);
  const locHard = hard.length ? makeLocal(sys, hard) : null;
  return { sys, grabs, holds, locAll, locHard, backup: new Float64Array(locAll.n) };
}
function dragStep(s) {
  const sys = s.sys, P = sys.P, loc = s.locAll;
  for (let i = 0; i < loc.n; i++) s.backup[i] = P[loc.lpar[i]];
  for (const h of s.holds) { h.t.x = P[h.ix]; h.t.y = P[h.ix + 1]; }
  lmSolve(sys, loc, { soft: true, maxIter: 30, lam0: 1e-7, stepTol: 1e-9 });
  let ok = true;
  if (s.locHard) {
    const res = lmSolve(sys, s.locHard, { maxIter: 40, lam0: 1e-8 });
    ok = res.maxHard <= 1e-6;
  }
  for (let i = 0; i < loc.n && ok; i++) {
    const v = P[loc.lpar[i]];
    if (!(v === v) || (sys.isRad[loc.lpar[i]] && !(v > 1e-6))) ok = false;   // NaN, or a circle turned inside out
  }
  if (!ok) { for (let i = 0; i < loc.n; i++) P[loc.lpar[i]] = s.backup[i]; return false; }
  writeBack(sys);
  return true;
}

// ---------------------------------------------------------------------
// Save / load
// ---------------------------------------------------------------------
function serialize(doc) { return JSON.stringify(doc, null, 1); }
function parseDoc(text) {
  let d;
  try { d = JSON.parse(text); } catch (e) { return { error: 'This file is not valid JSON.' }; }
  if (!d || d.app !== 'PrecisionSketch' || !d.points || !d.entities || !d.constraints) return { error: 'This is not a PrecisionSketch file.' };
  if (d.version > 1) return { error: 'This file was saved by a newer version of PrecisionSketch.' };
  const base = newDoc();
  for (const k in base) if (d[k] === undefined) d[k] = base[k];
  for (const k of ['O', 'OX', 'OY']) d.points[k] = base.points[k];
  for (const k of ['AX', 'AY']) d.entities[k] = base.entities[k];
  if (!UNITS[d.units]) d.units = 'mm';
  for (const id in d.entities) {
    const e = d.entities[id];
    if (!e || !e.type || entPoints(e).some(p => !d.points[p])) return { error: 'The file is damaged: ' + id + ' is missing a point.' };
  }
  for (const id in d.constraints) if (!conValid(d, d.constraints[id])) delete d.constraints[id];
  return { doc: d };
}
