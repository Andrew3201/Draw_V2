// =====================================================================
// PrecisionSketch interface: canvas view, tools, inference, panels,
// export. Geometry and solving live in PS (core).
// =====================================================================
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const cv = $('cv'), ctx = cv.getContext('2d');
  const TAU = Math.PI * 2;
  const circ = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + (2 * r) + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0';

  // icons are path data so the same shapes draw in the toolbar and on the canvas
  const ICON = {
    select: { f: 'M5 2.5l10.5 7.2-4.6.9 2.6 5-2 1-2.6-5-3.9 3z' },
    line: { s: 'M5 15L15 5', f: circ(5, 15, 1.9) + circ(15, 5, 1.9) },
    rect: { s: 'M3.5 5.5h13v9h-13z' },
    circle: { s: circ(10, 10, 6.5), f: circ(10, 10, 1.2) },
    arc: { s: 'M4 15.5A11.5 11.5 0 0 1 15.5 4', f: circ(4, 15.5, 1.8) + circ(15.5, 4, 1.8) },
    construction: { s: 'M3 17l2.6-2.6M7.6 12.4l2.6-2.6M12.2 7.8l2.6-2.6M16.4 3.6L17 3' },
    coincident: { s: circ(10, 10, 5.5), f: circ(10, 10, 2.2) },
    pointOn: { s: circ(10, 10, 5.5), f: circ(10, 10, 2.2) },
    horizontal: { s: 'M3 10h14M3 7v6M17 7v6' },
    vertical: { s: 'M10 3v14M7 3h6M7 17h6' },
    parallel: { s: 'M4.5 16l6-12M9.5 16l6-12' },
    perpendicular: { s: 'M4 15.5h12M10 15.5V4' },
    tangent: { s: circ(9.5, 12, 4.8) + 'M3 7.2h14' },
    equal: { s: 'M5 7.5h10M5 12.5h10' },
    concentric: { s: circ(10, 10, 6.8) + circ(10, 10, 3.2) },
    midpoint: { s: 'M3 14.5L17 5.5', f: circ(10, 10, 2.2) },
    fix: { s: 'M5.5 9.5h9v7h-9zM7.5 9.5V7a2.5 2.5 0 0 1 5 0v2.5' },
    dimension: { s: 'M3.5 4v12M16.5 4v12M4.5 10h11M7 7.5L4.5 10 7 12.5M13 7.5l2.5 2.5-2.5 2.5' },
    undo: { s: 'M7 4.5L3.5 8 7 11.5M3.5 8h8a4.5 4.5 0 0 1 0 9H9' },
    redo: { s: 'M13 4.5L16.5 8 13 11.5M16.5 8h-8a4.5 4.5 0 0 0 0 9H11' },
    fit: { s: 'M3.5 7.5v-4h4M12.5 3.5h4v4M16.5 12.5v4h-4M7.5 16.5h-4v-4' },
    copy: { s: 'M7 7h9.5v9.5H7zM13 7V3.5H3.5V13H7' },
    export: { s: 'M10 12.5V3M6.5 6.5L10 3l3.5 3.5M4 12v4.5h12V12' },
    menu: { s: 'M3.5 6h13M3.5 10h13M3.5 14h13' },
    props: { s: 'M4 5.5h12M4 10h12M4 14.5h12', f: circ(7.5, 5.5, 1.8) + circ(12.5, 10, 1.8) + circ(8.5, 14.5, 1.8) },
    logo: { s: 'M3 16.5h14M3 16.5V3.5M6.5 13l4-7 4 7', f: circ(10.5, 6, 1.4) }
  };
  function iconSvg(name) {
    const i = ICON[name];
    return '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      (i.s ? '<path d="' + i.s + '"/>' : '') + (i.f ? '<path d="' + i.f + '" fill="currentColor" stroke="none"/>' : '') + '</svg>';
  }
  const iconPaths = {};
  function iconPath(name) {
    if (!iconPaths[name]) { const i = ICON[name] || ICON.coincident; iconPaths[name] = { s: i.s ? new Path2D(i.s) : null, f: i.f ? new Path2D(i.f) : null }; }
    return iconPaths[name];
  }

  const TOOLS = [
    { grp: 'Create', items: [['select', 'Select', 'Esc'], ['line', 'Line', 'L'], ['rect', 'Corner rectangle', 'R'], ['circle', 'Center circle', 'C'], ['arc', '3-point arc', 'A'], ['construction', 'Construction on/off', 'Q']] },
    { grp: 'Constrain', items: [['coincident', 'Coincident', 'I'], ['horizontal', 'Horizontal', 'H'], ['vertical', 'Vertical', 'V'], ['parallel', 'Parallel', 'B'], ['perpendicular', 'Perpendicular', 'Shift+L'], ['tangent', 'Tangent', 'T'], ['equal', 'Equal', 'E'], ['concentric', 'Concentric', 'O'], ['midpoint', 'Midpoint', 'M'], ['fix', 'Fix', 'X']] },
    { grp: 'Dimension', items: [['dimension', 'Dimension', 'D']] }
  ];
  const CON_TOOLS = { coincident: 1, horizontal: 1, vertical: 1, parallel: 1, perpendicular: 1, tangent: 1, equal: 1, concentric: 1, midpoint: 1, fix: 1 };
  const KEYMAP = { l: 'line', r: 'rect', c: 'circle', a: 'arc', d: 'dimension', i: 'coincident', h: 'horizontal', v: 'vertical', b: 'parallel', t: 'tangent', e: 'equal', o: 'concentric', m: 'midpoint', x: 'fix' };
  const HINTS = {
    select: 'Click to select, drag blue geometry to move it. Drag on empty space to box-select.',
    line: 'Click to place points. Double-click or Esc ends the chain. Shift turns snapping off.',
    rect: 'Click two opposite corners.',
    circle: 'Click the center, then a point on the circle.',
    arc: 'Click the start, the end, then a point on the arc.',
    dimension: 'Click a line, circle or arc, or two items, then click where the dimension goes.'
  };
  const PALETTE = ['#1f6fd6', '#58a6f0', '#12805c', '#7cc474', '#e0a300', '#d95f0e', '#c9271c', '#8250c4', '#17212b', '#6b7785', '#c5ccd4', '#ffffff'];
  const STORE = 'precisionsketch.autosave.v1';

  const st = {
    doc: null, sys: null, ana: null, topo: null, items: [],
    view: { cx: 0, cy: 0, zoom: 5 }, w: 100, h: 100, dpr: 1,
    mode: 'sketch', tool: 'select', ts: {},
    sel: new Set(), hover: null, flash: null,
    hist: [], hi: -1,
    mouse: { sx: 0, sy: 0, in: false }, keys: { shift: false, space: false },
    press: null, pan: null, box: null, drag: null,
    colors: {}, glyphRects: [], dimRects: [], raf: 0, gridStep: 1,
    infer: null, lastLine: null, recent: [], example: false
  };
  window.__ps = st;   // handy for debugging from the console

  // ------------------------------------------------------------------
  // derived state, history, storage
  // ------------------------------------------------------------------
  function derive() {
    st.sys = PS.buildSystem(st.doc);
    st.ana = PS.analyze(st.sys);
    retopo();
    for (const r of Array.from(st.sel)) if (!refExists(r)) st.sel.delete(r);
    if (st.hover && !refExists(st.hover)) st.hover = null;
  }
  function retopo() {
    st.topo = PS.computeTopology(st.doc, st.sys);
    PS.syncShapes(st.doc, st.topo);
    st.items = PS.drawList(st.topo);
  }
  function refExists(r) {
    const id = r.slice(2);
    if (r[0] === 'p') return !!st.doc.points[id];
    if (r[0] === 'e') return !!st.doc.entities[id];
    if (r[0] === 'c') return !!st.doc.constraints[id];
    return !!shapeByKey(id);
  }
  function shapeByKey(key) {
    for (const f of st.topo.faces) if (f.key === key) return { kind: 'face', face: f, rec: f.rec, key };
    for (const p of st.topo.paths) if (p.key === key) return { kind: 'path', path: p, rec: p.rec, key };
    return null;
  }
  function commit() {
    derive();
    const snap = JSON.stringify(st.doc);
    if (st.hist[st.hi] !== snap) {
      st.hist.length = st.hi + 1;
      st.hist.push(snap);
      if (st.hist.length > 200) st.hist.shift();
      st.hi = st.hist.length - 1;
    }
    if (st.example && st.hi > 0) { st.example = false; $('example').hidden = true; }
    autosave();
    queuePanels();
    requestDraw();
  }
  function travel(dir) {
    const i = st.hi + dir;
    if (i < 0 || i >= st.hist.length) return;
    st.hi = i;
    PS.restoreInto(st.doc, st.hist[i]);
    cancelTool();
    derive(); autosave(); queuePanels(); requestDraw();
  }
  let saveTimer = 0;
  function autosave() {
    clearTimeout(saveTimer);
    if (st.example) return;
    saveTimer = setTimeout(() => { try { localStorage.setItem(STORE, JSON.stringify(st.doc)); } catch (e) { /* storage unavailable */ } }, 400);
  }
  function loadDoc(doc, keepHistory) {
    if (!st.doc) st.doc = doc; else PS.restoreInto(st.doc, JSON.stringify(doc));
    PS.trySolve(st.doc);
    st.sel.clear(); st.hover = null;
    if (!keepHistory) { st.hist = []; st.hi = -1; }
    cancelTool();
    commit();
    fitView();
  }

  // ------------------------------------------------------------------
  // view
  // ------------------------------------------------------------------
  function W2S(x, y) { const v = st.view; return [(x - v.cx) * v.zoom + st.w / 2, st.h / 2 - (y - v.cy) * v.zoom]; }
  function S2W(sx, sy) { const v = st.view; return { x: (sx - st.w / 2) / v.zoom + v.cx, y: (st.h / 2 - sy) / v.zoom + v.cy }; }
  function setWorld(c) { const v = st.view, k = st.dpr; c.setTransform(k * v.zoom, 0, 0, -k * v.zoom, k * (st.w / 2 - v.cx * v.zoom), k * (st.h / 2 + v.cy * v.zoom)); }
  function setScreen(c) { c.setTransform(st.dpr, 0, 0, st.dpr, 0, 0); }
  function readColors() {
    const cs = getComputedStyle(document.documentElement), c = {};
    for (const k of ['bg', 'grid', 'grid-major', 'axis', 'defined', 'under', 'conflict', 'select', 'hover', 'dim', 'driven', 'glyph-bg', 'glyph-line', 'glyph-fg', 'region', 'infer']) {
      c[k] = cs.getPropertyValue('--cv-' + k).trim() || '#888';
    }
    st.colors = c;
    st.font = cs.getPropertyValue('--mono').trim() || 'monospace';
  }
  function resize() {
    const r = $('stage').getBoundingClientRect();
    st.w = Math.max(50, r.width); st.h = Math.max(50, r.height);
    st.dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(st.w * st.dpr); cv.height = Math.round(st.h * st.dpr);
    requestDraw();
  }
  function sketchBounds() {
    const d = st.doc, bb = [Infinity, Infinity, -Infinity, -Infinity];
    const add = (x, y) => { if (x < bb[0]) bb[0] = x; if (y < bb[1]) bb[1] = y; if (x > bb[2]) bb[2] = x; if (y > bb[3]) bb[3] = y; };
    for (const id in d.entities) {
      const e = d.entities[id];
      if (e.ref) continue;
      if (e.type === 'line') { for (const p of [e.p1, e.p2]) add(d.points[p].x, d.points[p].y); }
      else { const c = d.points[e.c], r = PS.entRadius(d, e); add(c.x - r, c.y - r); add(c.x + r, c.y + r); }
    }
    for (const id in d.constraints) {
      const c = d.constraints[id];
      if (!PS.isDim(c) || !c.pos) continue;
      const t = dimTextPoint(c);
      if (t) add(t.x, t.y);
    }
    return bb[0] === Infinity ? null : bb;
  }
  function fitView() {
    const bb = sketchBounds();
    if (!bb) { st.view = { cx: 30, cy: 18, zoom: 6 }; requestDraw(); return; }
    add0(bb);
    const w = Math.max(bb[2] - bb[0], 1e-6), h = Math.max(bb[3] - bb[1], 1e-6);
    const z = Math.min((st.w - 120) / w, (st.h - 110) / h);
    st.view = { cx: (bb[0] + bb[2]) / 2, cy: (bb[1] + bb[3]) / 2, zoom: Math.max(0.02, Math.min(z, 400)) };
    requestDraw();
  }
  function add0(bb) { if (0 < bb[0]) bb[0] = 0; if (0 < bb[1]) bb[1] = 0; if (0 > bb[2]) bb[2] = 0; if (0 > bb[3]) bb[3] = 0; }
  function requestDraw() { if (!st.raf) st.raf = requestAnimationFrame(draw); }

  // ------------------------------------------------------------------
  // drawing
  // ------------------------------------------------------------------
  function draw() {
    st.raf = 0;
    if (!st.doc) return;
    st.glyphRects = []; st.dimRects = [];
    setScreen(ctx);
    ctx.globalAlpha = 1;
    if (st.mode === 'clean') drawClean(); else drawSketch();
    if (st.box) {
      const b = st.box, C = st.colors;
      setScreen(ctx);
      ctx.strokeStyle = C.select; ctx.fillStyle = C.select; ctx.lineWidth = 1;
      ctx.setLineDash(b.x1 < b.x0 ? [5, 4] : []);
      ctx.globalAlpha = 0.08; ctx.fillRect(b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0);
      ctx.globalAlpha = 1; ctx.strokeRect(b.x0 + .5, b.y0 + .5, b.x1 - b.x0, b.y1 - b.y0);
      ctx.setLineDash([]);
    }
    updateStatus();
  }
  function niceStep(raw) {
    const p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
    return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
  }
  function drawGrid() {
    const C = st.colors, u = PS.UNITS[st.doc.units], z = st.view.zoom;
    const step = niceStep(10 / z / u) * u;
    st.gridStep = step;
    if (!st.doc.grid.show) return;
    const a = S2W(0, st.h), b = S2W(st.w, 0);
    ctx.lineWidth = 1;
    for (let pass = 0; pass < 2; pass++) {
      ctx.strokeStyle = pass ? C['grid-major'] : C.grid;
      ctx.beginPath();
      for (let i = Math.ceil(a.x / step); i * step <= b.x; i++) {
        if ((i % 5 === 0) !== !!pass) continue;
        const sx = Math.round(W2S(i * step, 0)[0]) + .5;
        ctx.moveTo(sx, 0); ctx.lineTo(sx, st.h);
      }
      for (let j = Math.ceil(a.y / step); j * step <= b.y; j++) {
        if ((j % 5 === 0) !== !!pass) continue;
        const sy = Math.round(W2S(0, j * step)[1]) + .5;
        ctx.moveTo(0, sy); ctx.lineTo(st.w, sy);
      }
      ctx.stroke();
    }
  }
  function entPath(c, e) {
    const d = st.doc;
    c.beginPath();
    if (e.type === 'line') { const a = d.points[e.p1], b = d.points[e.p2]; c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); }
    else if (e.type === 'circle') { const p = d.points[e.c]; c.arc(p.x, p.y, Math.max(e.r, 0), 0, TAU); }
    else {
      const p = d.points[e.c], s = d.points[e.s], en = d.points[e.e];
      const r = Math.hypot(s.x - p.x, s.y - p.y), a0 = Math.atan2(s.y - p.y, s.x - p.x);
      let a1 = Math.atan2(en.y - p.y, en.x - p.x);
      if (a1 <= a0) a1 += TAU;
      c.arc(p.x, p.y, r, a0, a1, false);
    }
  }
  // hovering a constraint lights up the geometry it refers to
  function hotByConstraint(id) {
    const h = st.hover;
    if (!h || h[0] !== 'c') return false;
    const c = st.doc.constraints[h.slice(2)];
    return !!c && c.refs.indexOf(id) >= 0;
  }
  function drawSketch() {
    const C = st.colors, d = st.doc, z = st.view.zoom;
    ctx.fillStyle = C.bg; ctx.fillRect(0, 0, st.w, st.h);
    drawGrid();
    // axes and origin
    const o = W2S(0, 0);
    ctx.strokeStyle = C.axis; ctx.lineWidth = 1;
    for (const ax of ['AX', 'AY']) {
      const on = st.sel.has('e:' + ax), hot = st.hover === 'e:' + ax || hotByConstraint(ax) || pickHas(ax);
      ctx.strokeStyle = on ? C.select : hot ? C.hover : C.axis; ctx.lineWidth = on || hot ? 2 : 1;
      ctx.beginPath();
      if (ax === 'AX') { ctx.moveTo(0, Math.round(o[1]) + .5); ctx.lineTo(st.w, Math.round(o[1]) + .5); }
      else { ctx.moveTo(Math.round(o[0]) + .5, 0); ctx.lineTo(Math.round(o[0]) + .5, st.h); }
      ctx.stroke();
    }
    // closed regions: actual fill, softened so the geometry stays readable
    setWorld(ctx);
    for (const it of st.items) {
      if (it.kind !== 'face') continue;
      PS.tracePath(ctx, it);
      if (it.rec.fill !== 'none') { ctx.globalAlpha = 0.6 * it.rec.opacity; ctx.fillStyle = it.rec.fill; }
      else { ctx.globalAlpha = 0.07; ctx.fillStyle = C.region; }
      ctx.fill('evenodd');
    }
    ctx.globalAlpha = 1;
    drawShapeSelection();
    // curves
    setWorld(ctx);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (const id in d.entities) {
      const e = d.entities[id];
      if (e.ref) continue;
      const on = st.sel.has('e:' + id), hot = st.hover === 'e:' + id || hotByConstraint(id) || pickHas(id);
      entPath(ctx, e);
      if (hot && !on) { ctx.strokeStyle = C.hover; ctx.globalAlpha = 0.55; ctx.lineWidth = 6 / z; ctx.setLineDash([]); ctx.stroke(); ctx.globalAlpha = 1; }
      ctx.strokeStyle = on ? C.select : st.ana.entFree(id) ? C.under : C.defined;
      ctx.lineWidth = (on ? 2.4 : e.construction ? 1.1 : 1.7) / z;
      ctx.setLineDash(e.construction ? [6 / z, 4 / z] : []);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    // points
    setScreen(ctx);
    for (const id in d.points) {
      const p = d.points[id];
      if (p.hidden) continue;
      const s = W2S(p.x, p.y);
      if (s[0] < -10 || s[1] < -10 || s[0] > st.w + 10 || s[1] > st.h + 10) continue;
      const on = st.sel.has('p:' + id), hot = st.hover === 'p:' + id || hotByConstraint(id) || pickHas(id);
      if (hot && !on) { ctx.fillStyle = C.hover; ctx.globalAlpha = 0.6; ctx.beginPath(); ctx.arc(s[0], s[1], 7, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
      if (id === 'O') {
        ctx.strokeStyle = on ? C.select : C.axis; ctx.fillStyle = C.bg; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(s[0], s[1], 4, 0, TAU); ctx.fill(); ctx.stroke();
        continue;
      }
      ctx.fillStyle = on ? C.select : st.ana.ptFree(id) ? C.under : C.defined;
      ctx.beginPath(); ctx.arc(s[0], s[1], on ? 4.2 : 2.7, 0, TAU); ctx.fill();
    }
    drawGlyphs();
    for (const id in d.constraints) { const c = d.constraints[id]; if (PS.isDim(c) && PS.conValid(d, c)) drawDim(c, false); }
    drawToolPreview();
  }
  function drawShapeSelection() {
    const C = st.colors, z = st.view.zoom;
    const outline = (key, color, wpx) => {
      const sh = shapeByKey(key);
      if (!sh) return;
      let it;
      if (sh.kind === 'path') it = { cycles: [{ segs: sh.path.segs }], closed: sh.path.closed };
      else it = { cycles: sh.face.own ? PS.shapeCycles(st.topo, sh.face) : sh.face.cycles, closed: true };
      setWorld(ctx);
      PS.tracePath(ctx, it);
      if (sh.kind === 'face' && tint) { ctx.globalAlpha = tint; ctx.fillStyle = color; ctx.fill('evenodd'); ctx.globalAlpha = 1; }
      ctx.strokeStyle = color; ctx.lineWidth = wpx / z; ctx.lineJoin = 'round';
      ctx.setLineDash(st.mode === 'clean' ? [6 / z, 4 / z] : []);
      ctx.stroke(); ctx.setLineDash([]);
    };
    let tint = st.mode === 'clean' ? 0 : 0.1;
    if (st.hover && st.hover[0] === 's' && !st.sel.has(st.hover)) outline(st.hover.slice(2), C.hover, 2);
    tint = 0;
    for (const r of st.sel) if (r[0] === 's') outline(r.slice(2), C.select, st.mode === 'clean' ? 1.5 : 2.5);
  }
  function drawClean() {
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, st.w, st.h);
    setWorld(ctx);
    for (const it of st.items) PS.paintItem(ctx, it);
    drawShapeSelection();
    setScreen(ctx);
  }

  // --- constraint glyphs ---
  function entMid(id) {
    const d = st.doc, e = d.entities[id];
    if (!e) { const p = d.points[id]; return [p.x, p.y]; }
    if (e.ref) { const c = S2W(st.w * (id === 'AX' ? 0.78 : 0.5), st.h * (id === 'AX' ? 0.5 : 0.22)); return id === 'AX' ? [c.x, 0] : [0, c.y]; }
    if (e.type === 'line') { const a = d.points[e.p1], b = d.points[e.p2]; return [(a.x + b.x) / 2, (a.y + b.y) / 2]; }
    const c = d.points[e.c], r = PS.entRadius(d, e);
    let ang = Math.PI / 4;
    if (e.type === 'arc') {
      const s = d.points[e.s], en = d.points[e.e], a0 = Math.atan2(s.y - c.y, s.x - c.x);
      ang = a0 + PS.normAng(Math.atan2(en.y - c.y, en.x - c.x) - a0) / 2;
    }
    return [c.x + r * Math.cos(ang), c.y + r * Math.sin(ang)];
  }
  function glyphAnchors(c) {
    const d = st.doc, r = c.refs, E = d.entities, P = d.points;
    switch (c.type) {
      case 'coincident': case 'pointOn': case 'midpoint': return [[P[r[0]].x, P[r[0]].y]];
      case 'concentric': { const p = P[E[r[0]].c]; return [[p.x, p.y]]; }
      case 'horizontal': case 'vertical':
        if (r.length === 1) return [entMid(r[0])];
        return [[(P[r[0]].x + P[r[1]].x) / 2, (P[r[0]].y + P[r[1]].y) / 2]];
      case 'tangent': {
        let a = E[r[0]], b = E[r[1]];
        if (a.type !== 'line' && b.type === 'line') { const t = a; a = b; b = t; }
        if (a.type === 'line') {
          const p = P[a.p1], q = P[a.p2], cc = P[b.c], dx = q.x - p.x, dy = q.y - p.y, L2 = dx * dx + dy * dy || 1;
          const t = ((cc.x - p.x) * dx + (cc.y - p.y) * dy) / L2;
          return [[p.x + t * dx, p.y + t * dy]];
        }
        const c1 = P[a.c], c2 = P[b.c], r1 = PS.entRadius(d, a), dd = Math.hypot(c2.x - c1.x, c2.y - c1.y) || 1;
        const sg = dd < Math.max(r1, PS.entRadius(d, b)) && r1 < PS.entRadius(d, b) ? -1 : 1;
        return [[c1.x + sg * (c2.x - c1.x) / dd * r1, c1.y + sg * (c2.y - c1.y) / dd * r1]];
      }
      case 'fix': return [entMid(r[0])];
      default: return r.map(entMid);
    }
  }
  function drawGlyphs() {
    const C = st.colors, d = st.doc;
    const used = new Map(), z = st.view.zoom;
    const sizePx = id => {
      const e = d.entities[id] || d.entities[(d.points[id] || {}).owner];
      if (!e || e.ref) return 1e9;
      if (e.type === 'line') { const a = d.points[e.p1], b = d.points[e.p2]; return Math.hypot(b.x - a.x, b.y - a.y) * z; }
      return 2 * PS.entRadius(d, e) * z;
    };
    setScreen(ctx);
    for (const id in d.constraints) {
      const c = d.constraints[id];
      if (PS.isDim(c) || !PS.conValid(d, c)) continue;
      const bad = st.ana.conflict.has(id) || st.ana.redundant.has(id) || (st.flash && st.flash.has(id));
      const on = st.sel.has('c:' + id), hot = st.hover === 'c:' + id;
      // zoomed far out, marks on tiny geometry only add clutter
      if (!bad && !on && !hot && Math.max.apply(null, c.refs.map(sizePx)) < 42) continue;
      for (const a of glyphAnchors(c)) {
        const s = W2S(a[0], a[1]);
        if (s[0] < -30 || s[1] < -30 || s[0] > st.w + 30 || s[1] > st.h + 30) continue;
        const key = Math.round(s[0] / 12) + ',' + Math.round(s[1] / 12);
        const k = used.get(key) || 0;
        used.set(key, k + 1);
        const x = Math.round(s[0] + 7 + k * 16), y = Math.round(s[1] - 22);
        ctx.fillStyle = on ? C.select : C['glyph-bg'];
        ctx.strokeStyle = bad ? C.conflict : on ? C.select : hot ? C.hover : C['glyph-line'];
        ctx.lineWidth = bad || hot ? 1.5 : 1;
        ctx.beginPath(); ctx.roundRect(x + .5, y + .5, 14, 14, 3); ctx.fill(); ctx.stroke();
        const ip = iconPath(c.type);
        ctx.save();
        ctx.translate(x + 1.5, y + 1.5); ctx.scale(0.6, 0.6);
        ctx.strokeStyle = ctx.fillStyle = bad ? C.conflict : on ? C['glyph-bg'] : C['glyph-fg'];
        ctx.lineWidth = 1.9; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        if (ip.s) ctx.stroke(ip.s);
        if (ip.f) ctx.fill(ip.f);
        ctx.restore();
        st.glyphRects.push({ cid: id, x: x - 1, y: y - 1, w: 17, h: 17 });
      }
    }
  }

  // --- dimensions ---
  function dimFrame(c) {
    const d = st.doc, P = id => d.points[id];
    if (c.type === 'distance') {
      const g = PS.distRefs(d, c);
      let A, B;
      if (g.kind === 'pp') { A = P(g.a); B = P(g.b); }
      else {
        const q = P(g.p), l = d.entities[g.line], a = P(l.p1), b = P(l.p2);
        const dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1, t = ((q.x - a.x) * dx + (q.y - a.y) * dy) / L2;
        A = { x: a.x + t * dx, y: a.y + t * dy }; B = q;
      }
      let ux, uy;
      if (g.kind === 'pp' && c.mode === 'h') { ux = 1; uy = 0; }
      else if (g.kind === 'pp' && c.mode === 'v') { ux = 0; uy = 1; }
      else { ux = B.x - A.x; uy = B.y - A.y; const L = Math.hypot(ux, uy); if (L < 1e-12) { ux = 1; uy = 0; } else { ux /= L; uy /= L; } }
      return { kind: 'lin', A, B, ux, uy, nx: -uy, ny: ux, M: { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 }, half: Math.abs((B.x - A.x) * ux + (B.y - A.y) * uy) / 2 };
    }
    if (c.type === 'radius' || c.type === 'diameter') {
      const e = d.entities[c.refs[0]];
      return { kind: 'rad', C: P(e.c), r: PS.entRadius(d, e), dia: c.type === 'diameter' };
    }
    const a = d.entities[c.refs[0]], b = d.entities[c.refs[1]];
    const s1 = c.rev && c.rev[0] ? -1 : 1, s2 = c.rev && c.rev[1] ? -1 : 1;
    const a1 = P(a.p1), a2 = P(a.p2), b1 = P(b.p1), b2 = P(b.p2);
    let ux = s1 * (a2.x - a1.x), uy = s1 * (a2.y - a1.y), vx = s2 * (b2.x - b1.x), vy = s2 * (b2.y - b1.y);
    const lu = Math.hypot(ux, uy) || 1, lv = Math.hypot(vx, vy) || 1;
    ux /= lu; uy /= lu; vx /= lv; vy /= lv;
    const den = ux * vy - uy * vx;
    let X;
    if (Math.abs(den) < 1e-9) X = { x: (a1.x + b1.x) / 2, y: (a1.y + b1.y) / 2 };
    else { const t = ((b1.x - a1.x) * vy - (b1.y - a1.y) * vx) / den; X = { x: a1.x + ux * t, y: a1.y + uy * t }; }
    return { kind: 'ang', X, ux, uy, vx, vy };
  }
  function posFromPoint(c, w) {
    const f = dimFrame(c);
    if (f.kind === 'lin') {
      const rx = w.x - f.M.x, ry = w.y - f.M.y, t = rx * f.ux + ry * f.uy, pos = { t, n: rx * f.nx + ry * f.ny };
      // between the arrows: remember the position as a fraction of the span
      if (f.half > 1e-9 && Math.abs(t) <= f.half) pos.k = t / f.half;
      return pos;
    }
    const o = f.kind === 'rad' ? f.C : f.X;
    return { x: w.x - o.x, y: w.y - o.y };
  }
  function dimTextPoint(c, f) {
    f = f || dimFrame(c);
    const p = c.pos || (f.kind === 'lin' ? { t: 0, n: 8 } : { x: 10, y: 10 });
    if (f.kind === 'lin') { const t = p.k !== undefined ? p.k * f.half : p.t; return { x: f.M.x + f.ux * t + f.nx * p.n, y: f.M.y + f.uy * t + f.ny * p.n }; }
    const o = f.kind === 'rad' ? f.C : f.X;
    return { x: o.x + p.x, y: o.y + p.y };
  }
  function dimText(c) {
    const d = st.doc, v = c.driven || c.preview ? PS.measureCon(d, c) : c.value;
    let s;
    if (c.type === 'angle') s = PS.fmtNum(v * 180 / Math.PI, d.precision) + '°';
    else s = (c.type === 'diameter' ? '⌀' : c.type === 'radius' ? 'R' : '') + PS.fmtLen(v, d);
    return c.driven ? '(' + s + ')' : s;
  }
  function arrow(x, y, dx, dy) {
    const L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
    ctx.beginPath(); ctx.moveTo(x, y);
    ctx.lineTo(x - dx * 9 - dy * 3, y - dy * 9 + dx * 3);
    ctx.lineTo(x - dx * 9 + dy * 3, y - dy * 9 - dx * 3);
    ctx.closePath(); ctx.fill();
  }
  function drawDim(c, preview) {
    const C = st.colors, f = dimFrame(c), T = dimTextPoint(c, f);
    const id = c.id, on = id && st.sel.has('c:' + id), hot = id && st.hover === 'c:' + id;
    const bad = id && (st.ana.conflict.has(id) || (st.flash && st.flash.has(id)));
    const col = preview ? C.infer : bad ? C.conflict : on ? C.select : c.driven ? C.driven : C.dim;
    setScreen(ctx);
    ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = hot ? 1.6 : 1; ctx.setLineDash([]);
    const ts = W2S(T.x, T.y);
    if (f.kind === 'lin') {
      const offA = (T.x - f.A.x) * f.nx + (T.y - f.A.y) * f.ny, offB = (T.x - f.B.x) * f.nx + (T.y - f.B.y) * f.ny;
      const A1 = W2S(f.A.x + f.nx * offA, f.A.y + f.ny * offA), B1 = W2S(f.B.x + f.nx * offB, f.B.y + f.ny * offB);
      const As = W2S(f.A.x, f.A.y), Bs = W2S(f.B.x, f.B.y);
      ctx.globalAlpha = 0.7;
      for (const [p, q] of [[As, A1], [Bs, B1]]) {
        const dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy);
        if (L < 1) continue;
        ctx.beginPath(); ctx.moveTo(p[0] + dx / L * 4, p[1] + dy / L * 4); ctx.lineTo(q[0] + dx / L * 5, q[1] + dy / L * 5); ctx.stroke();
      }
      ctx.globalAlpha = 1;
      const dx = B1[0] - A1[0], dy = B1[1] - A1[1], L = Math.hypot(dx, dy);
      ctx.beginPath(); ctx.moveTo(A1[0], A1[1]); ctx.lineTo(B1[0], B1[1]);
      // run the dimension line out to the text when it sits beyond an arrow
      const tt = L > 1e-6 ? ((ts[0] - A1[0]) * dx + (ts[1] - A1[1]) * dy) / (L * L) : 0;
      if (tt < 0) { ctx.moveTo(A1[0], A1[1]); ctx.lineTo(ts[0], ts[1]); }
      if (tt > 1) { ctx.moveTo(B1[0], B1[1]); ctx.lineTo(ts[0], ts[1]); }
      ctx.stroke();
      if (L > 26) { arrow(A1[0], A1[1], -dx, -dy); arrow(B1[0], B1[1], dx, dy); }
      else if (L > 1e-6) { arrow(A1[0], A1[1], dx, dy); arrow(B1[0], B1[1], -dx, -dy); }
    } else if (f.kind === 'rad') {
      let ux = T.x - f.C.x, uy = T.y - f.C.y;
      const L = Math.hypot(ux, uy);
      if (L < 1e-9) { ux = Math.SQRT1_2; uy = Math.SQRT1_2; } else { ux /= L; uy /= L; }
      const R1 = W2S(f.C.x + ux * f.r, f.C.y + uy * f.r), R2 = W2S(f.C.x - ux * f.r, f.C.y - uy * f.r), Cs = W2S(f.C.x, f.C.y);
      const from = f.dia ? R2 : Cs, to = L > f.r ? ts : R1;
      ctx.beginPath(); ctx.moveTo(from[0], from[1]); ctx.lineTo(to[0], to[1]); ctx.stroke();
      arrow(R1[0], R1[1], R1[0] - Cs[0], R1[1] - Cs[1]);
      if (f.dia) arrow(R2[0], R2[1], R2[0] - Cs[0], R2[1] - Cs[1]);
    } else {
      const rho = Math.max(Math.hypot(T.x - f.X.x, T.y - f.X.y), 1e-6), z = st.view.zoom;
      const a0 = Math.atan2(f.uy, f.ux), th = PS.normAng(Math.atan2(f.vy, f.vx) - a0);
      const Xs = W2S(f.X.x, f.X.y), R = rho * z;
      ctx.globalAlpha = 0.5;
      for (const [x, y] of [[f.ux, f.uy], [f.vx, f.vy]]) { ctx.beginPath(); ctx.moveTo(Xs[0], Xs[1]); ctx.lineTo(Xs[0] + x * (R + 6), Xs[1] - y * (R + 6)); ctx.stroke(); }
      ctx.globalAlpha = 1;
      ctx.beginPath(); ctx.arc(Xs[0], Xs[1], R, -a0, -(a0 + th), true); ctx.stroke();
      if (R * th > 26) {
        arrow(Xs[0] + f.ux * R, Xs[1] - f.uy * R, f.uy, f.ux);
        arrow(Xs[0] + f.vx * R, Xs[1] - f.vy * R, -f.vy, -f.vx);
      }
    }
    // text with a knock-out behind it
    const txt = dimText(c);
    ctx.font = '500 12px ' + st.font;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const tw = ctx.measureText(txt).width + 8;
    ctx.fillStyle = C.bg; ctx.globalAlpha = 0.92; ctx.fillRect(ts[0] - tw / 2, ts[1] - 8, tw, 16); ctx.globalAlpha = 1;
    if (hot || on) { ctx.strokeStyle = on ? C.select : C.hover; ctx.lineWidth = 1; ctx.strokeRect(Math.round(ts[0] - tw / 2) + .5, Math.round(ts[1] - 8) + .5, Math.round(tw), 16); }
    ctx.fillStyle = col; ctx.fillText(txt, ts[0], ts[1] + .5);
    if (id) st.dimRects.push({ cid: id, x: ts[0] - tw / 2 - 2, y: ts[1] - 10, w: tw + 4, h: 20 });
  }

  // --- tool previews and inference marks ---
  function pickHas(id) { return !!(st.ts.picks && st.ts.picks.indexOf(id) >= 0); }
  function drawInferMarks(inf, sx, sy) {
    if (!inf) return;
    const C = st.colors, all = (inf.snaps || []).concat(inf.lineSnaps || []);
    setScreen(ctx);
    for (const s of all) {
      // highlight what is being snapped to
      if (s.pid) { const p = st.doc.points[s.pid], q = W2S(p.x, p.y); ctx.strokeStyle = C.infer; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(q[0], q[1], 6.5, 0, TAU); ctx.stroke(); }
      if (s.ent && st.doc.entities[s.ent] && !st.doc.entities[s.ent].ref) {
        setWorld(ctx); entPath(ctx, st.doc.entities[s.ent]);
        ctx.strokeStyle = C.infer; ctx.globalAlpha = 0.5; ctx.lineWidth = 4 / st.view.zoom; ctx.stroke(); ctx.globalAlpha = 1; setScreen(ctx);
      }
    }
    let k = 0;
    for (const s of all) {
      const x = Math.round(sx + 12 + k * 17), y = Math.round(sy + 10);
      ctx.fillStyle = C['glyph-bg']; ctx.strokeStyle = C.infer; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(x + .5, y + .5, 14, 14, 3); ctx.fill(); ctx.stroke();
      const ip = iconPath(s.type);
      ctx.save(); ctx.translate(x + 1.5, y + 1.5); ctx.scale(0.6, 0.6);
      ctx.strokeStyle = ctx.fillStyle = C.infer; ctx.lineWidth = 1.9; ctx.lineCap = 'round';
      if (ip.s) ctx.stroke(ip.s);
      if (ip.f) ctx.fill(ip.f);
      ctx.restore();
      k++;
    }
  }
  function drawToolPreview() {
    const C = st.colors, ts = st.ts, z = st.view.zoom;
    if (!st.mouse.in && !st.drag) return;
    const inf = st.infer;
    const cur = inf || S2W(st.mouse.sx, st.mouse.sy);
    setWorld(ctx);
    ctx.strokeStyle = C.under; ctx.lineWidth = 1.5 / z; ctx.setLineDash([]);
    if (st.tool === 'line' && ts.a) { ctx.beginPath(); ctx.moveTo(ts.a.x, ts.a.y); ctx.lineTo(cur.x, cur.y); ctx.stroke(); }
    else if (st.tool === 'rect' && ts.a) { ctx.strokeRect(ts.a.x, ts.a.y, cur.x - ts.a.x, cur.y - ts.a.y); }
    else if (st.tool === 'circle' && ts.a) { ctx.beginPath(); ctx.arc(ts.a.x, ts.a.y, Math.hypot(cur.x - ts.a.x, cur.y - ts.a.y), 0, TAU); ctx.stroke(); }
    else if (st.tool === 'arc' && ts.a) {
      if (!ts.b) { ctx.setLineDash([4 / z, 4 / z]); ctx.beginPath(); ctx.moveTo(ts.a.x, ts.a.y); ctx.lineTo(cur.x, cur.y); ctx.stroke(); ctx.setLineDash([]); }
      else {
        const g = arcThrough(ts.a, ts.b, cur);
        ctx.beginPath();
        if (g) ctx.arc(g.cx, g.cy, g.r, g.a0, g.a1, false); else { ctx.moveTo(ts.a.x, ts.a.y); ctx.lineTo(ts.b.x, ts.b.y); }
        ctx.stroke();
      }
    }
    setScreen(ctx);
    if (st.tool === 'dimension' && ts.picks && ts.picks.length) {
      const c = dimFromPicks(ts.picks, S2W(st.mouse.sx, st.mouse.sy));
      if (c) { c.preview = true; drawDim(c, true); }
    }
    if (inf && (st.tool !== 'select' || st.drag)) {
      const s = W2S(inf.x, inf.y);
      drawInferMarks(inf, s[0], s[1]);
      if (st.tool !== 'select') { ctx.fillStyle = C.under; ctx.beginPath(); ctx.arc(s[0], s[1], 3, 0, TAU); ctx.fill(); }
    }
  }
  function arcThrough(a, b, m) {
    const ax = a.x, ay = a.y, bx = b.x, by = b.y, mx = m.x, my = m.y;
    const D = 2 * (ax * (by - my) + bx * (my - ay) + mx * (ay - by));
    if (Math.abs(D) < 1e-9) return null;
    const a2 = ax * ax + ay * ay, b2 = bx * bx + by * by, m2 = mx * mx + my * my;
    const cx = (a2 * (by - my) + b2 * (my - ay) + m2 * (ay - by)) / D, cy = (a2 * (mx - bx) + b2 * (ax - mx) + m2 * (bx - ax)) / D;
    const r = Math.hypot(ax - cx, ay - cy);
    if (!(r < 1e7)) return null;
    // counter-clockwise from s to e, passing through m
    const ccw = (mx - ax) * (by - my) - (my - ay) * (bx - mx) > 0;
    const s = ccw ? a : b, e = ccw ? b : a;
    const a0 = Math.atan2(s.y - cy, s.x - cx);
    let a1 = Math.atan2(e.y - cy, e.x - cx);
    if (a1 <= a0) a1 += TAU;
    return { cx, cy, r, a0, a1, s, e, swapped: !ccw };
  }

  // ------------------------------------------------------------------
  // hit testing
  // ------------------------------------------------------------------
  function entDist(e, w) {
    const d = st.doc;
    if (e.type === 'line') {
      const a = d.points[e.p1], b = d.points[e.p2], dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1;
      let t = ((w.x - a.x) * dx + (w.y - a.y) * dy) / L2;
      if (!e.ref) t = Math.max(0, Math.min(1, t));
      return Math.hypot(w.x - a.x - t * dx, w.y - a.y - t * dy);
    }
    const c = d.points[e.c], r = PS.entRadius(d, e), dr = Math.abs(Math.hypot(w.x - c.x, w.y - c.y) - r);
    if (e.type === 'circle') return dr;
    const s = d.points[e.s], en = d.points[e.e], a0 = Math.atan2(s.y - c.y, s.x - c.x);
    const sw = PS.normAng(Math.atan2(en.y - c.y, en.x - c.x) - a0);
    if (PS.normAng(Math.atan2(w.y - c.y, w.x - c.x) - a0) <= sw) return dr;
    return Math.min(Math.hypot(w.x - s.x, w.y - s.y), Math.hypot(w.x - en.x, w.y - en.y));
  }
  function hitTest(sx, sy, o) {
    o = o || {};
    const w = S2W(sx, sy), z = st.view.zoom, d = st.doc;
    if (st.mode === 'clean') return hitShape(w);
    let best = null, bd = 8 / z;
    for (const id in d.points) {
      const p = d.points[id];
      if (p.hidden) continue;
      const dist = Math.hypot(p.x - w.x, p.y - w.y);
      if (dist < bd) { bd = dist; best = id; }
    }
    if (best) return { ref: 'p:' + best, kind: 'point', id: best };
    if (!o.geomOnly) {
      for (const r of st.dimRects) if (sx >= r.x && sx <= r.x + r.w && sy >= r.y && sy <= r.y + r.h) return { ref: 'c:' + r.cid, kind: 'con', id: r.cid };
      for (const r of st.glyphRects) if (sx >= r.x && sx <= r.x + r.w && sy >= r.y && sy <= r.y + r.h) return { ref: 'c:' + r.cid, kind: 'con', id: r.cid };
    }
    best = null; bd = 6 / z;
    for (const id in d.entities) {
      const e = d.entities[id];
      const dist = entDist(e, w) + (e.ref ? 1.5 / z : 0);
      if (dist < bd) { bd = dist; best = id; }
    }
    if (best) return { ref: 'e:' + best, kind: 'ent', id: best };
    if (o.geomOnly) return null;
    return hitShape(w);
  }
  function hitShape(w) {
    const tol = 5 / st.view.zoom;
    let best = null;
    for (const p of st.topo.paths) {
      if (PS.cyclesDist([{ segs: p.segs }], w.x, w.y) < Math.max(tol, p.rec.sw / 2)) best = p;
    }
    if (best && st.mode === 'clean') return { ref: 's:' + best.key, kind: 'shape', id: best.key };
    const f = PS.hitFace(st.topo, w.x, w.y);
    if (f) return { ref: 's:' + f.key, kind: 'shape', id: f.key };
    if (best) return { ref: 's:' + best.key, kind: 'shape', id: best.key };
    return null;
  }

  // ------------------------------------------------------------------
  // inference while drawing
  // ------------------------------------------------------------------
  // Returns the snapped position and the constraints that go with it.
  function inferPoint(w, o) {
    o = o || {};
    const d = st.doc, res = { x: w.x, y: w.y, snaps: [] };
    if (st.keys.shift) return res;
    const tol = 9 / st.view.zoom;
    const skipP = o.skipPoints || null, skipE = o.skipEnts || null;
    let best = null, bd = tol;
    for (const id in d.points) {
      const p = d.points[id];
      if (p.hidden || (skipP && skipP.has(id))) continue;
      const dist = Math.hypot(p.x - w.x, p.y - w.y);
      if (dist < bd) { bd = dist; best = id; }
    }
    if (best) {
      res.x = d.points[best].x; res.y = d.points[best].y;
      res.snaps.push({ type: 'coincident', pid: best });
      return res;
    }
    bd = tol;
    for (const id in d.entities) {
      const e = d.entities[id];
      if (e.type !== 'line' || e.ref || (skipE && skipE.has(id))) continue;
      const a = d.points[e.p1], b = d.points[e.p2], mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      const dist = Math.hypot(mx - w.x, my - w.y);
      if (dist < bd) { bd = dist; best = { id, x: mx, y: my }; }
    }
    if (best) { res.x = best.x; res.y = best.y; res.snaps.push({ type: 'midpoint', ent: best.id }); return res; }
    bd = tol * 0.8;
    for (const id in d.entities) {
      const e = d.entities[id];
      if (skipE && skipE.has(id)) continue;
      const dist = entDist(e, w) + (e.ref ? tol * 0.15 : 0);
      if (dist < bd) { bd = dist; best = id; }
    }
    if (best) {
      const e = d.entities[best], q = projectOn(e, w);
      res.x = q.x; res.y = q.y; res.snaps.push({ type: 'pointOn', ent: best });
    }
    // horizontal / vertical from the previous point
    if (o.from) {
      const f = o.from, hv = Math.abs(res.y - f.y) < tol ? 'horizontal' : Math.abs(res.x - f.x) < tol ? 'vertical' : null;
      if (hv && Math.hypot(res.x - f.x, res.y - f.y) > tol * 1.5) {
        if (!best) { if (hv === 'horizontal') res.y = f.y; else res.x = f.x; res.snaps.push({ type: hv, line: true }); }
        else {
          // stay on the curve and line up with the previous point if both are possible
          const q = alignOnCurve(d.entities[best], f, hv, res);
          if (q) { res.x = q.x; res.y = q.y; res.snaps.push({ type: hv, line: true }); }
        }
      }
    }
    if (!res.snaps.length && d.grid.snap) {
      const g = st.gridStep;
      res.x = Math.round(res.x / g) * g; res.y = Math.round(res.y / g) * g;
    }
    return res;
  }
  function projectOn(e, w) {
    const d = st.doc;
    if (e.type === 'line') {
      const a = d.points[e.p1], b = d.points[e.p2], dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1;
      const t = ((w.x - a.x) * dx + (w.y - a.y) * dy) / L2;
      return { x: a.x + t * dx, y: a.y + t * dy };
    }
    const c = d.points[e.c], r = PS.entRadius(d, e), L = Math.hypot(w.x - c.x, w.y - c.y) || 1;
    return { x: c.x + (w.x - c.x) / L * r, y: c.y + (w.y - c.y) / L * r };
  }
  function alignOnCurve(e, f, hv, near) {
    const d = st.doc;
    if (e.type === 'line') {
      const a = d.points[e.p1], b = d.points[e.p2], dx = b.x - a.x, dy = b.y - a.y;
      if (hv === 'horizontal') { if (Math.abs(dy) < 1e-9) return null; const t = (f.y - a.y) / dy; return { x: a.x + t * dx, y: f.y }; }
      if (Math.abs(dx) < 1e-9) return null;
      const t = (f.x - a.x) / dx; return { x: f.x, y: a.y + t * dy };
    }
    const c = d.points[e.c], r = PS.entRadius(d, e);
    if (hv === 'horizontal') { const k = r * r - (f.y - c.y) * (f.y - c.y); if (k < 0) return null; const h = Math.sqrt(k); return { x: Math.abs(c.x + h - near.x) < Math.abs(c.x - h - near.x) ? c.x + h : c.x - h, y: f.y }; }
    const k = r * r - (f.x - c.x) * (f.x - c.x); if (k < 0) return null; const h = Math.sqrt(k);
    return { x: f.x, y: Math.abs(c.y + h - near.y) < Math.abs(c.y - h - near.y) ? c.y + h : c.y - h };
  }
  // Second point of a line: adds parallel / perpendicular / tangent.
  function inferLineEnd(a, w) {
    const d = st.doc, r = inferPoint(w, { from: a });
    r.lineSnaps = [];
    for (let i = r.snaps.length - 1; i >= 0; i--) if (r.snaps[i].line) r.lineSnaps.push(r.snaps.splice(i, 1)[0]);
    if (st.keys.shift) return r;
    const dx = r.x - a.x, dy = r.y - a.y, L = Math.hypot(dx, dy);
    if (L < 12 / st.view.zoom) return r;
    const free = !r.snaps.length;
    const ang = Math.atan2(dy, dx);
    const near = (target, tol) => { let k = PS.wrapPi(ang - target); if (k > Math.PI / 2) k -= Math.PI; if (k < -Math.PI / 2) k += Math.PI; return Math.abs(k) < tol ? k : null; };
    const snapDir = t => { const ux = Math.cos(t), uy = Math.sin(t), m = dx * ux + dy * uy; r.x = a.x + ux * m; r.y = a.y + uy * m; };
    // tangent to an arc or circle the line starts on
    for (const s of a.snaps || []) {
      let e = null;
      if (s.type === 'coincident') { const o = d.entities[d.points[s.pid].owner]; if (o && o.type === 'arc' && o.c !== s.pid) e = o; }
      else if (s.type === 'pointOn' && d.entities[s.ent].type !== 'line') e = d.entities[s.ent];
      if (!e) continue;
      const c = d.points[e.c], t = Math.atan2(a.y - c.y, a.x - c.x) + Math.PI / 2;
      const k = near(t, free ? 0.07 : 0.01);
      if (k !== null && !r.lineSnaps.length) { if (free) snapDir(t); r.lineSnaps.push({ type: 'tangent', ent: e.id }); return r; }
    }
    // tangent where the line lands on a circle or arc
    const on = r.snaps.find(s => s.type === 'pointOn' && d.entities[s.ent].type !== 'line');
    if (on && !r.lineSnaps.length) {
      const e = d.entities[on.ent], c = d.points[e.c], R = PS.entRadius(d, e), dc = Math.hypot(a.x - c.x, a.y - c.y);
      if (dc > R * 1.0001) {
        const base = Math.atan2(a.y - c.y, a.x - c.x), al = Math.acos(R / dc);
        let bestT = null, bdist = 10 / st.view.zoom;
        for (const sg of [1, -1]) {
          const tx = c.x + R * Math.cos(base + sg * al), ty = c.y + R * Math.sin(base + sg * al);
          const dist = Math.hypot(tx - r.x, ty - r.y);
          if (dist < bdist) { bdist = dist; bestT = { x: tx, y: ty }; }
        }
        if (bestT) { r.x = bestT.x; r.y = bestT.y; r.lineSnaps.push({ type: 'tangent', ent: e.id }); return r; }
      }
    }
    if (r.lineSnaps.length) return r;
    // parallel / perpendicular to lines this one touches, or the last line hovered
    const cands = new Set();
    for (const s of a.snaps || []) {
      if (s.type === 'coincident') { const o = d.entities[d.points[s.pid].owner]; if (o && o.type === 'line') cands.add(o.id); }
      if ((s.type === 'pointOn' || s.type === 'midpoint') && d.entities[s.ent].type === 'line') cands.add(s.ent);
    }
    if (st.lastLine && d.entities[st.lastLine]) cands.add(st.lastLine);
    for (const id of cands) {
      const e = d.entities[id], p = d.points[e.p1], q = d.points[e.p2], t = Math.atan2(q.y - p.y, q.x - p.x);
      for (const [type, tt] of [['perpendicular', t + Math.PI / 2], ['parallel', t]]) {
        const k = near(tt, free ? 0.05 : 0.004);
        if (k === null) continue;
        if (type === 'parallel' && (a.snaps || []).some(s => (s.type === 'coincident' && d.points[s.pid].owner === id) || s.ent === id)) continue;
        if (free) snapDir(tt);
        r.lineSnaps.push({ type, ent: id });
        return r;
      }
    }
    return r;
  }
  // Rim of a circle being drawn: land on a point, or touch a line.
  function inferRim(a, w) {
    const d = st.doc, res = { x: w.x, y: w.y, snaps: [], lineSnaps: [] };
    if (st.keys.shift) return res;
    const tol = 9 / st.view.zoom;
    let best = null, bd = tol;
    for (const id in d.points) {
      const p = d.points[id];
      if (p.hidden) continue;
      const dist = Math.hypot(p.x - w.x, p.y - w.y);
      if (dist < bd) { bd = dist; best = id; }
    }
    if (best) { res.x = d.points[best].x; res.y = d.points[best].y; res.lineSnaps.push({ type: 'pointOn', pid: best, rim: true }); return res; }
    const r = Math.hypot(w.x - a.x, w.y - a.y);
    bd = tol;
    for (const id in d.entities) {
      const e = d.entities[id];
      if (e.type !== 'line') continue;
      const p = d.points[e.p1], q = d.points[e.p2], dx = q.x - p.x, dy = q.y - p.y, L = Math.hypot(dx, dy) || 1;
      const dist = Math.abs((dx * (a.y - p.y) - dy * (a.x - p.x)) / L);
      if (Math.abs(dist - r) < bd && dist > tol) { bd = Math.abs(dist - r); best = { id, dist }; }
    }
    if (best) {
      const k = best.dist / (r || 1);
      res.x = a.x + (w.x - a.x) * k; res.y = a.y + (w.y - a.y) * k;
      res.lineSnaps.push({ type: 'tangent', ent: best.id });
    } else if (d.grid.snap) {
      const g = st.gridStep, rr = Math.max(g, Math.round(r / g) * g), k = rr / (r || 1);
      res.x = a.x + (w.x - a.x) * k; res.y = a.y + (w.y - a.y) * k;
    }
    return res;
  }
  function applyPointSnaps(pid, snaps) {
    for (const s of snaps || []) {
      if (s.type === 'coincident') PS.addConIfUseful(st.doc, { type: 'coincident', refs: [pid, s.pid] });
      else if (s.type === 'midpoint') PS.addConIfUseful(st.doc, { type: 'midpoint', refs: [pid, s.ent] });
      else if (s.type === 'pointOn') PS.addConIfUseful(st.doc, { type: 'pointOn', refs: [pid, s.ent] });
    }
  }
  function applyLineSnaps(id, snaps) {
    for (const s of snaps || []) {
      if (s.type === 'horizontal' || s.type === 'vertical') PS.addConIfUseful(st.doc, { type: s.type, refs: [id] });
      else if (s.rim) PS.addConIfUseful(st.doc, { type: 'pointOn', refs: [s.pid, id] });
      else PS.addConIfUseful(st.doc, { type: s.type, refs: [id, s.ent] });
    }
  }

  // ------------------------------------------------------------------
  // tools
  // ------------------------------------------------------------------
  function cancelTool() { st.ts = {}; st.infer = null; st.drag = null; st.press = null; st.box = null; closeDimEdit(); }
  function setTool(name) {
    if (name === 'construction') { toggleConstruction(); return; }
    if (st.mode === 'clean' && name !== 'select') setMode('sketch');
    if (CON_TOOLS[name]) {
      // apply straight away when the current selection already fits
      const picks = Array.from(st.sel).filter(r => r[0] === 'p' || r[0] === 'e').map(r => r.slice(2));
      if (picks.length) {
        if ((name === 'horizontal' || name === 'vertical' || name === 'fix') && picks.every(p => PS.kindOf(st.doc, p) === 'line' || name === 'fix')) {
          let n = 0;
          for (const p of picks) { const r = PS.makeConstraint(st.doc, name, [p]); if (r.con && applyCon(r.con, true)) n++; }
          if (n) { st.sel.clear(); commit(); return; }
        } else {
          const r = PS.makeConstraint(st.doc, name, picks.slice(0, 2));
          if (r.con && picks.length <= 2) { if (applyCon(r.con)) st.sel.clear(); queuePanels(); requestDraw(); return; }
        }
      }
    }
    cancelTool();
    st.tool = name;
    if (name !== 'select') st.sel.clear();
    if (name === 'dimension') st.ts.picks = [];
    if (CON_TOOLS[name]) st.ts.picks = [];
    syncToolbar(); queuePanels(); requestDraw();
    cv.style.cursor = name === 'select' ? 'default' : 'crosshair';
  }
  function toggleConstruction() {
    const ids = Array.from(st.sel).filter(r => r[0] === 'e').map(r => r.slice(2)).filter(id => !st.doc.entities[id].ref);
    if (!ids.length) { toast('Select lines, circles or arcs first, then press Q to make them construction geometry.'); return; }
    const to = !ids.every(id => st.doc.entities[id].construction);
    for (const id of ids) st.doc.entities[id].construction = to;
    commit();
  }
  function reportClash(r) {
    let msg = '<b>Not applied.</b> ';
    const list = () => '<ul>' + r.clash.map(k => '<li>' + esc(k.text) + '</li>').join('') + '</ul>';
    if (r.collapsed && r.collapsed.length) msg += 'It would shrink ' + esc(r.collapsed.join(', ')) + ' to nothing.' + (r.clash && r.clash.length > 1 ? ' These cannot all hold together:' + list() : '');
    else if (r.clash && r.clash.length > 1) msg += 'These constraints cannot all hold together:' + list();
    else msg += 'The rest of the sketch does not allow it' + (r.clash && r.clash.length ? ' (' + esc(r.clash[0].text) + ').' : '.');
    toast(msg, true, 7000);
    st.flash = new Set((r.clash || []).map(k => k.cid));
    clearTimeout(reportClash.t);
    reportClash.t = setTimeout(() => { st.flash = null; requestDraw(); }, 7000);
  }
  function applyCon(con, quiet) {
    const r = PS.applyChange(st.doc, d => PS.addCon(d, con));
    if (!r.ok) { derive(); reportClash(r); requestDraw(); return false; }
    if (!quiet) commit();
    return true;
  }
  function deleteSelection() {
    const ids = Array.from(st.sel).filter(r => r[0] === 'e' || r[0] === 'c').map(r => r.slice(2));
    if (!ids.length) {
      if (Array.from(st.sel).some(r => r[0] === 's')) toast('Shapes come from the sketch. Switch to Sketch view and delete the lines that form it.');
      return;
    }
    if (PS.deleteItems(st.doc, ids)) { st.sel.clear(); PS.trySolve(st.doc); commit(); }
  }

  // --- dimension tool ---
  function modeFor(A, B, w) {
    const x0 = Math.min(A.x, B.x), x1 = Math.max(A.x, B.x), y0 = Math.min(A.y, B.y), y1 = Math.max(A.y, B.y);
    const tol = 2 / st.view.zoom;
    if (x1 - x0 < tol || y1 - y0 < tol) return 'aligned';
    if (w.x > x0 && w.x < x1 && (w.y < y0 || w.y > y1)) return 'h';
    if (w.y > y0 && w.y < y1 && (w.x < x0 || w.x > x1)) return 'v';
    return 'aligned';
  }
  function dimFromPicks(picks, w) {
    const d = st.doc, k = picks.map(id => PS.kindOf(d, id));
    let c = null;
    if (picks.length === 1) {
      if (k[0] === 'line') { const e = d.entities[picks[0]]; if (e.ref) return null; c = { type: 'distance', refs: [picks[0]], mode: modeFor(d.points[e.p1], d.points[e.p2], w) }; }
      else if (k[0] === 'circle') c = { type: 'diameter', refs: [picks[0]] };
      else if (k[0] === 'arc') c = { type: 'radius', refs: [picks[0]] };
      else return null;
    } else if (k[0] === 'point' && k[1] === 'point') {
      c = { type: 'distance', refs: picks.slice(), mode: modeFor(d.points[picks[0]], d.points[picks[1]], w) };
    } else if ((k[0] === 'point' && k[1] === 'line') || (k[0] === 'line' && k[1] === 'point')) {
      c = { type: 'distance', refs: k[0] === 'point' ? picks.slice() : [picks[1], picks[0]] };
    } else if (k[0] === 'line' && k[1] === 'line') {
      const a = d.entities[picks[0]], b = d.entities[picks[1]];
      const a1 = d.points[a.p1], a2 = d.points[a.p2], b1 = d.points[b.p1], b2 = d.points[b.p2];
      const ux = a2.x - a1.x, uy = a2.y - a1.y, vx = b2.x - b1.x, vy = b2.y - b1.y;
      const den = ux * vy - uy * vx;
      if (Math.abs(den) < 1e-4 * Math.hypot(ux, uy) * Math.hypot(vx, vy)) {
        c = { type: 'distance', refs: a.ref ? [picks[1], picks[0]] : picks.slice() };
      } else {
        // pick the sector the cursor is in
        const t = ((b1.x - a1.x) * vy - (b1.y - a1.y) * vx) / den;
        const X = { x: a1.x + ux * t, y: a1.y + uy * t };
        const rx = w.x - X.x, ry = w.y - X.y;
        const al = (rx * vy - ry * vx) / den, be = (ux * ry - uy * rx) / den;
        let refs = picks.slice(), rev = [al < 0, be < 0];
        const s1 = rev[0] ? -1 : 1, s2 = rev[1] ? -1 : 1;
        if (s1 * s2 * den < 0) { refs = [picks[1], picks[0]]; rev = [rev[1], rev[0]]; }
        c = { type: 'angle', refs, rev };
      }
    } else return null;
    c.pos = posFromPoint(c, w);
    return c;
  }
  function dimClick(sx, sy) {
    const ts = st.ts, d = st.doc, w = S2W(sx, sy);
    const hit = hitTest(sx, sy, { geomOnly: true });
    const k0 = ts.picks.length ? PS.kindOf(d, ts.picks[0]) : null;
    if (!ts.picks.length) {
      if (!hit) { toast('Click a line, circle, arc or point to dimension.'); return; }
      ts.picks = [hit.id];
      setHint(hit.kind === 'point' ? 'Click a second point or a line.' : 'Click where the dimension goes, or click a second item.');
      return;
    }
    if (ts.picks.length === 1 && hit && hit.id !== ts.picks[0]) {
      const k1 = PS.kindOf(d, hit.id);
      const ownEnd = k1 === 'point' && d.points[hit.id].owner === ts.picks[0];
      if ((k0 === 'point' || k0 === 'line') && (k1 === 'point' || k1 === 'line') && !ownEnd) {
        ts.picks.push(hit.id); setHint('Click where the dimension goes.'); return;
      }
    }
    if (ts.picks.length === 1 && k0 === 'point') return;
    const c = dimFromPicks(ts.picks, w);
    ts.picks = [];
    if (!c) return;
    const id = PS.addDimension(d, c);
    commit();
    setHint(HINTS.dimension);
    if (d.constraints[id].driven) toast('That size is already set by other constraints, so this is a reference dimension (shown in brackets).');
    else openDimEdit(id);
  }
  let editing = null;
  function openDimEdit(cid) {
    const c = st.doc.constraints[cid];
    if (!c || c.driven) return;
    editing = cid;
    const T = dimTextPoint(c), s = W2S(T.x, T.y), box = $('dimedit');
    box.hidden = false;
    box.style.left = Math.max(52, Math.min(st.w - 52, s[0])) + 'px';
    box.style.top = Math.max(16, Math.min(st.h - 16, s[1])) + 'px';
    box.value = c.type === 'angle' ? PS.fmtNum(c.value * 180 / Math.PI, Math.max(st.doc.precision, 3)) : PS.fmtNum(c.value / PS.UNITS[st.doc.units], Math.max(st.doc.precision, 4));
    box.focus(); box.select();
  }
  function closeDimEdit() { if (editing) { editing = null; $('dimedit').hidden = true; } }
  function setDim(cid, text) {
    const c = st.doc.constraints[cid];
    if (!c) return true;
    const r = PS.evalExpr(text, { units: st.doc.units, kind: c.type === 'angle' ? 'angle' : 'length' });
    if (!r.ok) { toast(esc(r.error) + '.', true); return false; }
    if (c.type === 'angle' ? !(r.value > 1e-6 && r.value < TAU - 1e-6) : !(r.value > 1e-9)) {
      toast(c.type === 'angle' ? 'Enter an angle between 0 and 360 degrees.' : 'Enter a size greater than zero.', true);
      return false;
    }
    if (Math.abs(r.value - c.value) < 1e-12) return true;
    const res = PS.setDimValue(st.doc, cid, r.value);
    if (!res.ok) { derive(); reportClash(res); requestDraw(); return true; }
    commit();
    return true;
  }

  // --- pointer handling ---
  function local(e) { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function onDown(e) {
    const [sx, sy] = local(e);
    st.mouse = { sx, sy, in: true };
    cv.focus({ preventScroll: true });
    if (editing) { const ok = setDim(editing, $('dimedit').value); if (ok) closeDimEdit(); return; }
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
    if (e.button === 1 || e.button === 2 || st.keys.space) { st.pan = { sx, sy, cx: st.view.cx, cy: st.view.cy }; cv.style.cursor = 'grabbing'; e.preventDefault(); return; }
    if (e.button !== 0) return;
    st.keys.shift = e.shiftKey;
    st.downAt = { sx, sy };
    if (st.tool === 'select') {
      st.press = { sx, sy, hit: hitTest(sx, sy), shift: e.shiftKey, moved: false, mode: null };
    } else toolClick(sx, sy);
    requestDraw();
  }
  function onMove(e) {
    const [sx, sy] = local(e);
    st.mouse = { sx, sy, in: true };
    st.keys.shift = e.shiftKey;
    if (st.pan) {
      st.view.cx = st.pan.cx - (sx - st.pan.sx) / st.view.zoom;
      st.view.cy = st.pan.cy + (sy - st.pan.sy) / st.view.zoom;
      requestDraw(); return;
    }
    const w = S2W(sx, sy);
    if (st.tool === 'select') {
      const pr = st.press;
      if (pr) {
        if (!pr.moved && Math.hypot(sx - pr.sx, sy - pr.sy) > 4) {
          pr.moved = true;
          const h = pr.hit;
          if (h && st.mode === 'sketch' && (h.kind === 'point' || h.kind === 'ent')) { pr.mode = startDrag(h, S2W(pr.sx, pr.sy)) ? 'drag' : 'none'; }
          else if (h && h.kind === 'con' && PS.isDim(st.doc.constraints[h.id])) { pr.mode = 'dim'; st.sel.clear(); st.sel.add(h.ref); }
          else pr.mode = 'box';
        }
        if (pr.mode === 'drag') dragMove(w);
        else if (pr.mode === 'dim') { const c = st.doc.constraints[pr.hit.id]; c.pos = posFromPoint(c, w); }
        else if (pr.mode === 'box') st.box = { x0: pr.sx, y0: pr.sy, x1: sx, y1: sy };
      } else {
        const h = hitTest(sx, sy);
        st.hover = h ? h.ref : null;
        cv.style.cursor = st.keys.space ? 'grab' : h && (h.kind === 'point' || h.kind === 'ent') && st.mode === 'sketch' ? 'move' : h ? 'pointer' : 'default';
      }
    } else {
      toolMove(sx, sy);
      // press-drag-release also places the second point
    }
    requestDraw();
  }
  function onUp(e) {
    const [sx, sy] = local(e);
    try { cv.releasePointerCapture(e.pointerId); } catch (err) { /* fine */ }
    if (st.pan) { st.pan = null; cv.style.cursor = st.tool === 'select' ? 'default' : 'crosshair'; return; }
    if (e.button !== 0) return;
    if (st.tool === 'select') {
      const pr = st.press;
      st.press = null;
      if (!pr) return;
      if (!pr.moved) {
        const h = pr.hit;
        if (!h) { if (!pr.shift) st.sel.clear(); }
        else if (pr.shift) { if (st.sel.has(h.ref)) st.sel.delete(h.ref); else st.sel.add(h.ref); }
        else { st.sel.clear(); st.sel.add(h.ref); }
        if (h && h.kind === 'ent' && st.doc.entities[h.id].type === 'line') st.lastLine = h.id;
        queuePanels();
      } else if (pr.mode === 'drag') dragEnd();
      else if (pr.mode === 'dim') commit();
      else if (pr.mode === 'box') { boxSelect(st.box, pr.shift); st.box = null; queuePanels(); }
    } else if (st.downAt && Math.hypot(sx - st.downAt.sx, sy - st.downAt.sy) > 8 && st.ts.a && (st.tool === 'line' || st.tool === 'rect' || st.tool === 'circle')) {
      toolClick(sx, sy);   // press, drag, release
      if (st.tool === 'line') { st.ts = {}; st.infer = null; }
    }
    st.downAt = null;
    requestDraw();
  }
  function startDrag(hit, w) {
    const d = st.doc;
    let grabs;
    if (hit.kind === 'point') { if (d.points[hit.id].ref) return false; grabs = [{ kind: 'point', pid: hit.id }]; }
    else {
      const e = d.entities[hit.id];
      if (e.ref) return false;
      if (e.type === 'line') grabs = [e.p1, e.p2].map(pid => ({ kind: 'point', pid, off: { x: d.points[pid].x - w.x, y: d.points[pid].y - w.y } }));
      else grabs = [{ kind: 'radius', ent: e.id }];
    }
    st.drag = { s: PS.beginDrag(st.sys, grabs), hit };
    st.sel.clear(); st.sel.add(hit.ref);
    if (hit.kind === 'point') {
      // points and curves the dragged point must not snap to
      const root = st.sys.uf.find(hit.id), skipP = new Set(), skipE = new Set();
      for (const id in d.points) if (st.sys.uf.find(id) === root) { skipP.add(id); const o = d.entities[d.points[id].owner]; if (o) { skipE.add(o.id); for (const q of PS.entPoints(o)) skipP.add(q); } }
      for (const id in d.constraints) { const c = d.constraints[id]; if (c.type === 'pointOn' && skipP.has(c.refs[0])) skipE.add(c.refs[1]); }
      st.drag.skipP = skipP; st.drag.skipE = skipE;
    }
    return true;
  }
  function dragMove(w) {
    const dg = st.drag;
    if (!dg) return;
    let target = w;
    st.infer = null;
    if (dg.skipP) {
      const inf = inferPoint(w, { skipPoints: dg.skipP, skipEnts: dg.skipE });
      if (inf.snaps.length) { st.infer = inf; target = inf; }
      else if (st.doc.grid.snap) target = inf;
    }
    for (const g of dg.s.grabs) { g.t.x = target.x + (g.off ? g.off.x : 0); g.t.y = target.y + (g.off ? g.off.y : 0); }
    PS.dragStep(dg.s);
    retopo();
  }
  function dragEnd() {
    const dg = st.drag, inf = st.infer;
    st.drag = null; st.infer = null;
    if (dg && inf && inf.snaps.length && dg.hit.kind === 'point') {
      const p = st.doc.points[dg.hit.id];
      // only join when the point actually got there
      if (Math.hypot(p.x - inf.x, p.y - inf.y) < 12 / st.view.zoom) {
        const s = inf.snaps[0];
        const con = s.type === 'coincident' ? { type: 'coincident', refs: [dg.hit.id, s.pid] } : s.type === 'midpoint' ? { type: 'midpoint', refs: [dg.hit.id, s.ent] } : { type: 'pointOn', refs: [dg.hit.id, s.ent] };
        PS.applyChange(st.doc, d => PS.addCon(d, con));
      }
    }
    commit();
  }
  function boxSelect(b, add) {
    if (!b) return;
    const x0 = Math.min(b.x0, b.x1), x1 = Math.max(b.x0, b.x1), y0 = Math.min(b.y0, b.y1), y1 = Math.max(b.y0, b.y1);
    const crossing = b.x1 < b.x0;
    const a = S2W(x0, y1), c = S2W(x1, y0), d = st.doc;
    const inside = (x, y) => x >= a.x && x <= c.x && y >= a.y && y <= c.y;
    if (!add) st.sel.clear();
    if (st.mode === 'clean') {
      for (const it of st.items) {
        const bb = it.kind === 'face' ? it.face.bbox : it.path.bbox;
        const enclosed = bb[0] >= a.x && bb[2] <= c.x && bb[1] >= a.y && bb[3] <= c.y;
        const overlap = bb[0] <= c.x && bb[2] >= a.x && bb[1] <= c.y && bb[3] >= a.y;
        if (crossing ? overlap : enclosed) st.sel.add('s:' + it.key);
      }
      return;
    }
    for (const id in d.entities) {
      const e = d.entities[id];
      if (e.ref) continue;
      const pts = [];
      if (e.type === 'line') { const p = d.points[e.p1], q = d.points[e.p2]; for (let i = 0; i <= 12; i++) pts.push([p.x + (q.x - p.x) * i / 12, p.y + (q.y - p.y) * i / 12]); }
      else {
        const p = d.points[e.c], r = PS.entRadius(d, e);
        let a0 = 0, sw = TAU;
        if (e.type === 'arc') { const s = d.points[e.s], en = d.points[e.e]; a0 = Math.atan2(s.y - p.y, s.x - p.x); sw = PS.normAng(Math.atan2(en.y - p.y, en.x - p.x) - a0); }
        for (let i = 0; i <= 32; i++) pts.push([p.x + r * Math.cos(a0 + sw * i / 32), p.y + r * Math.sin(a0 + sw * i / 32)]);
      }
      const n = pts.filter(p => inside(p[0], p[1])).length;
      if (crossing ? n > 0 : n === pts.length) st.sel.add('e:' + id);
    }
    for (const r of st.dimRects) {
      const mx = r.x + r.w / 2, my = r.y + r.h / 2;
      if (mx >= x0 && mx <= x1 && my >= y0 && my <= y1) st.sel.add('c:' + r.cid);
    }
  }
  function toolMove(sx, sy) {
    const w = S2W(sx, sy), ts = st.ts;
    st.infer = null;
    if (st.tool === 'line') st.infer = ts.a ? inferLineEnd(ts.a, w) : inferPoint(w);
    else if (st.tool === 'rect') st.infer = inferPoint(w);
    else if (st.tool === 'circle') st.infer = ts.a ? inferRim(ts.a, w) : inferPoint(w);
    else if (st.tool === 'arc') st.infer = ts.b ? null : inferPoint(w);
    else {
      const h = hitTest(sx, sy, { geomOnly: true });
      st.hover = h ? h.ref : null;
    }
    const h2 = hitTest(sx, sy, { geomOnly: true });
    if (h2 && h2.kind === 'ent' && st.doc.entities[h2.id].type === 'line' && !st.doc.entities[h2.id].ref) st.lastLine = h2.id;
  }
  function toolClick(sx, sy) {
    const d = st.doc, ts = st.ts, w = S2W(sx, sy);
    toolMove(sx, sy);
    const inf = st.infer || { x: w.x, y: w.y, snaps: [] };
    const far = (p, q) => Math.hypot(p.x - q.x, p.y - q.y) > 1e-6;
    if (st.tool === 'line') {
      if (!ts.a) { ts.a = inf; return; }
      if (!far(ts.a, inf)) return;
      const id = PS.addLine(d, ts.a.x, ts.a.y, inf.x, inf.y), e = d.entities[id];
      applyPointSnaps(e.p1, ts.a.snaps);
      applyPointSnaps(e.p2, inf.snaps);
      applyLineSnaps(id, inf.lineSnaps);
      PS.trySolve(d);
      const ended = inf.snaps.some(s => s.type === 'coincident');
      commit();
      const p2 = d.points[e.p2];
      st.ts = ended ? {} : { a: { x: p2.x, y: p2.y, snaps: [{ type: 'coincident', pid: e.p2 }] } };
      st.infer = null;
    } else if (st.tool === 'rect') {
      if (!ts.a) { ts.a = inf; return; }
      if (Math.abs(inf.x - ts.a.x) < 1e-6 || Math.abs(inf.y - ts.a.y) < 1e-6) return;
      const R = PS.addRect(d, ts.a.x, ts.a.y, inf.x, inf.y);
      applyPointSnaps(R.p1, ts.a.snaps);
      applyPointSnaps(R.p2, inf.snaps);
      PS.trySolve(d);
      st.ts = {}; st.infer = null;
      commit();
    } else if (st.tool === 'circle') {
      if (!ts.a) { ts.a = inf; return; }
      const r = Math.hypot(inf.x - ts.a.x, inf.y - ts.a.y);
      if (r < 1e-6) return;
      const id = PS.addCircle(d, ts.a.x, ts.a.y, r);
      applyPointSnaps(d.entities[id].c, ts.a.snaps);
      applyLineSnaps(id, inf.lineSnaps);
      PS.trySolve(d);
      st.ts = {}; st.infer = null;
      commit();
    } else if (st.tool === 'arc') {
      if (!ts.a) { ts.a = inf; return; }
      if (!ts.b) { if (far(ts.a, inf)) ts.b = inf; return; }
      const g = arcThrough(ts.a, ts.b, w);
      if (!g) { toast('Those three points are in a straight line. Click a point off the line.'); return; }
      const id = PS.addArc(d, g.cx, g.cy, g.s.x, g.s.y, g.e.x, g.e.y), e = d.entities[id];
      applyPointSnaps(e.s, g.s.snaps);
      applyPointSnaps(e.e, g.e.snaps);
      // tangent to a line the arc starts or ends on
      for (const [pid, snaps] of [[e.s, g.s.snaps], [e.e, g.e.snaps]]) {
        for (const s of snaps || []) {
          if (s.type !== 'coincident') continue;
          const o = d.entities[d.points[s.pid].owner];
          if (!o || o.type !== 'line' || st.keys.shift) continue;
          const p = d.points[pid], a = d.points[o.p1], b = d.points[o.p2];
          const ux = b.x - a.x, uy = b.y - a.y, rx = p.x - g.cx, ry = p.y - g.cy;
          if (Math.abs(ux * rx + uy * ry) / ((Math.hypot(ux, uy) || 1) * g.r) < 0.12) PS.addConIfUseful(d, { type: 'tangent', refs: [o.id, id] });
        }
      }
      PS.trySolve(d);
      st.ts = {}; st.infer = null;
      commit();
    } else if (st.tool === 'dimension') dimClick(sx, sy);
    else if (CON_TOOLS[st.tool]) {
      const h = hitTest(sx, sy, { geomOnly: true });
      if (!h) return;
      ts.picks.push(h.id);
      const r = PS.makeConstraint(d, st.tool, ts.picks);
      if (r.con) { ts.picks = []; applyCon(r.con); setHint(toolHint()); }
      else if (r.error) { ts.picks = []; toast(esc(r.error) + '.', true); setHint(toolHint()); }
      else setHint(r.need + '.');
    }
  }
  function toolHint() {
    if (HINTS[st.tool]) return HINTS[st.tool];
    const r = PS.makeConstraint(st.doc, st.tool, []);
    return r.need ? r.need + '. Esc returns to Select.' : '';
  }
  function onWheel(e) {
    e.preventDefault();
    const [sx, sy] = local(e);
    const before = S2W(sx, sy);
    const dy = e.deltaMode === 1 ? e.deltaY * 30 : e.deltaY;
    st.view.zoom = Math.max(0.02, Math.min(4000, st.view.zoom * Math.exp(-dy * (e.ctrlKey ? 0.01 : 0.0015))));
    const after = S2W(sx, sy);
    st.view.cx += before.x - after.x; st.view.cy += before.y - after.y;
    closeDimEdit();
    requestDraw();
  }
  function onDbl(e) {
    const [sx, sy] = local(e);
    if (st.tool === 'line') { st.ts = {}; st.infer = null; requestDraw(); return; }
    if (st.tool !== 'select' || st.mode !== 'sketch') return;
    for (const r of st.dimRects) {
      if (sx >= r.x && sx <= r.x + r.w && sy >= r.y && sy <= r.y + r.h) {
        const c = st.doc.constraints[r.cid];
        if (c.driven) toast('This is a reference dimension. Its value follows the geometry.');
        else openDimEdit(r.cid);
        return;
      }
    }
  }
  function setMode(m) {
    if (st.mode === m) return;
    st.mode = m;
    cancelTool();
    if (m === 'clean') { st.tool = 'select'; for (const r of Array.from(st.sel)) if (r[0] !== 's') st.sel.delete(r); }
    st.hover = null;
    $('btnSketch').setAttribute('aria-pressed', m === 'sketch');
    $('btnClean').setAttribute('aria-pressed', m === 'clean');
    $('viewtag').textContent = m === 'clean' ? 'Clean view · this is what exports' : '';
    cv.style.cursor = 'default';
    syncToolbar(); queuePanels(); requestDraw();
  }

  // ------------------------------------------------------------------
  // status, toast, toolbar
  // ------------------------------------------------------------------
  let hintOverride = null;
  function setHint(t) { hintOverride = t; }
  function dofPill() {
    const a = st.ana;
    const nEnt = Object.keys(st.doc.entities).length - 2;
    if (a.conflict.size) return '<span class="pill bad">Conflicting constraints</span>';
    if (a.redundant.size) return '<span class="pill bad">Over-defined: ' + a.redundant.size + ' redundant constraint' + (a.redundant.size > 1 ? 's' : '') + '</span>';
    if (!nEnt) return '<span class="pill ok">Empty sketch</span>';
    if (a.dof === 0) return '<span class="pill ok">Fully defined</span>';
    return '<span class="pill under">' + a.dof + ' degree' + (a.dof > 1 ? 's' : '') + ' of freedom</span>';
  }
  function updateStatus() {
    const d = st.doc, w = st.infer && st.tool !== 'select' ? st.infer : S2W(st.mouse.sx, st.mouse.sy);
    $('coords').textContent = st.mouse.in ? 'X ' + PS.fmtLen(w.x, d) + '   Y ' + PS.fmtLen(w.y, d) + ' ' + d.units : d.units;
    const pill = dofPill();
    if ($('dof').dataset.v !== pill) { $('dof').innerHTML = pill; $('dof').dataset.v = pill; }
    const hint = st.mode === 'clean' ? 'Click a shape to style it. Tab returns to the sketch.' : (st.tool === 'select' ? HINTS.select : (hintOverride || toolHint()));
    if ($('hint').textContent !== hint) $('hint').textContent = hint;
    $('zoom').textContent = Math.round(st.view.zoom / (96 / 25.4) * 100) + '%';
  }
  let toastTimer = 0;
  function toast(html, bad, ms) {
    const t = $('toast');
    t.innerHTML = html; t.className = bad ? 'bad' : ''; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, ms || 4200);
  }
  function buildToolbar() {
    let h = '';
    for (const g of TOOLS) {
      h += '<div class="grp"><div class="grp-label">' + g.grp + '</div><div class="grp-row">';
      for (const [id, name, key] of g.items) h += '<button class="tb" type="button" data-tool="' + id + '" title="' + name + ' (' + key + ')" aria-label="' + name + '" aria-pressed="false">' + iconSvg(id) + '</button>';
      h += '</div></div>';
    }
    $('toolbar').innerHTML = h;
    $('toolbar').addEventListener('click', e => { const b = e.target.closest('[data-tool]'); if (b) { hintOverride = null; setTool(b.dataset.tool); cv.focus({ preventScroll: true }); } });
    $('brand').innerHTML = iconSvg('logo').replace('<svg ', '<svg width="18" height="18" ') + '<span>PrecisionSketch</span>';
    $('btnUndo').innerHTML = iconSvg('undo'); $('btnRedo').innerHTML = iconSvg('redo'); $('btnFit').innerHTML = iconSvg('fit');
    $('btnLeft').innerHTML = iconSvg('menu'); $('btnRight').innerHTML = iconSvg('props');
    $('btnCopy').insertAdjacentHTML('afterbegin', iconSvg('copy')); $('btnExport').insertAdjacentHTML('afterbegin', iconSvg('export'));
  }
  function syncToolbar() {
    for (const b of $('toolbar').querySelectorAll('[data-tool]')) b.setAttribute('aria-pressed', b.dataset.tool === st.tool && st.mode === 'sketch');
    $('btnUndo').disabled = st.hi <= 0; $('btnRedo').disabled = st.hi >= st.hist.length - 1;
  }

  // ------------------------------------------------------------------
  // panels
  // ------------------------------------------------------------------
  let panelTimer = 0;
  function queuePanels() { if (!panelTimer) panelTimer = setTimeout(() => { panelTimer = 0; buildPanels(); }, 0); }
  function buildPanels() {
    const act = document.activeElement, aid = act && act.id && (act.closest('#left') || act.closest('#right')) ? act.id : null;
    $('left').innerHTML = leftHtml();
    $('right').innerHTML = rightHtml();
    if (aid && $(aid)) { $(aid).focus(); if ($(aid).select && $(aid).type === 'text') $(aid).select(); }
    syncToolbar();
  }
  const opt = (v, label, cur) => '<option value="' + v + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + label + '</option>';
  function shapeName(it, i) {
    const n = it.rec.ents.length;
    return (it.kind === 'face' ? 'Region' : 'Open path') + ' · ' + n + (n === 1 ? ' curve' : ' curves');
  }
  function leftHtml() {
    const d = st.doc;
    let h = '<div class="sec"><h2>Document</h2>' +
      '<div class="row"><label for="f-units">Units</label><select class="field" id="f-units" data-doc="units">' + ['mm', 'cm', 'in', 'pt', 'px'].map(u => opt(u, u, d.units)).join('') + '</select></div>' +
      '<div class="row"><label for="f-prec">Decimals</label><select class="field" id="f-prec" data-doc="precision">' + [0, 1, 2, 3, 4].map(u => opt(u, u, d.precision)).join('') + '</select></div>' +
      '<label class="check"><input type="checkbox" id="f-grid" data-doc="grid"' + (d.grid.show ? ' checked' : '') + '> Show grid</label>' +
      '<label class="check"><input type="checkbox" id="f-snap" data-doc="snap"' + (d.grid.snap ? ' checked' : '') + '> Snap to grid</label></div>';
    h += '<div class="sec"><h2>Shapes</h2>';
    const items = st.items.slice().reverse();
    if (!items.length) h += '<p class="hint">Closed loops become shapes you can fill. Open chains become outline-only paths.</p>';
    else {
      h += '<ul class="list">';
      items.forEach((it, i) => {
        const fill = it.kind === 'face' ? it.rec.fill : 'none';
        h += '<li class="click' + (st.sel.has('s:' + it.key) ? ' on' : '') + '" data-shape="' + esc(it.key) + '"><span class="sw' + (fill === 'none' ? ' none' : '') + '"' + (fill !== 'none' ? ' style="background:' + esc(fill) + '"' : '') + '></span><span class="grow">' + shapeName(it, i) + '</span></li>';
      });
      h += '</ul><p class="hint" style="margin-top:8px">Front of the drawing is at the top.</p>';
    }
    return h + '</div>';
  }
  function conLabel(c) {
    const d = st.doc;
    let s = PS.CON_LABEL[c.type];
    if (PS.isDim(c)) s += ' ' + dimText(c);
    return s;
  }
  function conListHtml(ids, title) {
    if (!ids.length) return '';
    let h = '<div class="sec"><h2>' + title + '</h2><ul class="list">';
    for (const id of ids) {
      const c = st.doc.constraints[id];
      const bad = st.ana.conflict.has(id) || st.ana.redundant.has(id);
      const others = c.refs.map(r => PS.entityLabel(st.doc, r)).join(', ');
      h += '<li class="click' + (bad ? ' bad' : '') + '" data-con="' + id + '" title="' + esc(others) + '"><span class="grow">' + esc(conLabel(c)) + (st.ana.redundant.has(id) ? ' (redundant)' : '') + '</span><button class="x" type="button" data-delcon="' + id + '" aria-label="Delete constraint">&times;</button></li>';
    }
    return h + '</ul></div>';
  }
  function consOf(id) {
    const d = st.doc, e = d.entities[id], ids = new Set([id]);
    if (e) for (const p of PS.entPoints(e)) ids.add(p);
    const out = [];
    for (const cid in d.constraints) if (d.constraints[cid].refs.some(r => ids.has(r))) out.push(cid);
    return out;
  }
  function ptRow(label, pid, key) {
    const p = st.doc.points[pid], ro = p.ref ? ' disabled' : '';
    return '<div class="row"><span class="lab">' + label + '</span><div class="pair">' +
      '<input class="field" id="f-' + key + 'x" data-pt="' + pid + '" data-ax="x" value="' + PS.fmtLen(p.x, st.doc) + '" aria-label="' + label + ' X"' + ro + '>' +
      '<input class="field" id="f-' + key + 'y" data-pt="' + pid + '" data-ax="y" value="' + PS.fmtLen(p.y, st.doc) + '" aria-label="' + label + ' Y"' + ro + '></div></div>';
  }
  function rightHtml() {
    const d = st.doc, sel = Array.from(st.sel);
    if (!sel.length) return noSelHtml();
    const shapes = sel.filter(r => r[0] === 's');
    if (shapes.length === sel.length) return shapeHtml(shapes.map(r => shapeByKey(r.slice(2))).filter(Boolean));
    if (sel.length > 1) {
      const n = { e: 0, p: 0, c: 0, s: 0 };
      for (const r of sel) n[r[0]]++;
      const parts = [];
      if (n.e) parts.push(n.e + ' curve' + (n.e > 1 ? 's' : ''));
      if (n.p) parts.push(n.p + ' point' + (n.p > 1 ? 's' : ''));
      if (n.c) parts.push(n.c + ' constraint' + (n.c > 1 ? 's' : ''));
      if (n.s) parts.push(n.s + ' shape' + (n.s > 1 ? 's' : ''));
      return '<div class="sec"><h2>Selection</h2><p class="kv">' + parts.join(', ') + '</p>' +
        '<p class="hint" style="margin-top:8px">Pick a constraint in the toolbar to apply it to the selection. <kbd>Delete</kbd> removes curves and constraints.</p>' +
        (n.e || n.c ? '<div class="btnrow"><button class="btn small" type="button" data-act="delete">Delete</button></div>' : '') + '</div>';
    }
    const r = sel[0], id = r.slice(2);
    if (r[0] === 'c') {
      const c = d.constraints[id];
      const bad = st.ana.conflict.has(id) ? 'Conflicts with other constraints' : st.ana.redundant.has(id) ? 'Redundant: the sketch already implies it' : '';
      let h = '<div class="sec"><h2>' + (PS.isDim(c) ? 'Dimension' : 'Constraint') + '</h2><p class="kv">' + esc(PS.CON_LABEL[c.type]) + '</p><p class="hint">' + esc(c.refs.map(x => PS.entityLabel(d, x)).join(', ')) + '</p>';
      if (bad) h += '<p style="margin:8px 0 0"><span class="pill bad">' + bad + '</span></p>';
      if (PS.isDim(c)) {
        const v = c.type === 'angle' ? PS.fmtNum((c.driven ? PS.measureCon(d, c) : c.value) * 180 / Math.PI, d.precision) : PS.fmtLen(c.driven ? PS.measureCon(d, c) : c.value, d);
        h += '<div class="row" style="margin-top:10px"><label for="f-dimv">Value</label><input class="field" id="f-dimv" data-dim="' + id + '" value="' + v + '"' + (c.driven ? ' disabled' : '') + '></div>' +
          '<label class="check" style="margin-top:6px"><input type="checkbox" id="f-driven" data-driven="' + id + '"' + (c.driven ? ' checked' : '') + '> Reference only (driven)</label>' +
          '<p class="hint">Accepts units and arithmetic, such as <kbd>1.5 in</kbd> or <kbd>40/2 + 3</kbd>.</p>';
      }
      return h + '<div class="btnrow"><button class="btn small" type="button" data-act="delete">Delete</button></div></div>';
    }
    if (r[0] === 'p') {
      const p = d.points[id];
      return '<div class="sec"><h2>Point</h2><p class="kv">' + esc(PS.entityLabel(d, id)) + '</p><div style="margin-top:8px">' + ptRow('X, Y', id, 'p') + '</div>' +
        '<p style="margin:10px 0 0">' + (p.ref ? '<span class="pill ok">Reference</span>' : st.ana.ptFree(id) ? '<span class="pill under">Under-defined</span>' : '<span class="pill ok">Fully defined</span>') + '</p></div>' +
        conListHtml(consOf(id), 'Constraints');
    }
    const e = d.entities[id];
    let h = '<div class="sec"><h2>' + esc(PS.entityLabel(d, id)) + '</h2>';
    if (e.ref) return h + '<p class="hint">Reference geometry. Constrain or dimension to it; it never moves and is not exported.</p></div>' + conListHtml(consOf(id), 'Constraints');
    if (e.type === 'line') {
      const a = d.points[e.p1], b = d.points[e.p2];
      h += '<div class="row"><span class="lab">Length</span><span class="kv">' + PS.fmtLen(Math.hypot(b.x - a.x, b.y - a.y), d) + ' ' + d.units + '</span></div>' +
        '<div class="row"><span class="lab">Angle</span><span class="kv">' + PS.fmtNum(Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI, 2) + '°</span></div>' + ptRow('Start', e.p1, 'a') + ptRow('End', e.p2, 'b');
    } else {
      const rr = PS.entRadius(d, e);
      h += '<div class="row"><span class="lab">' + (e.type === 'circle' ? 'Diameter' : 'Radius') + '</span><span class="kv">' + PS.fmtLen(e.type === 'circle' ? rr * 2 : rr, d) + ' ' + d.units + '</span></div>' + ptRow('Center', e.c, 'c');
      if (e.type === 'arc') h += ptRow('Start', e.s, 'a') + ptRow('End', e.e, 'b');
    }
    h += '<label class="check" style="margin-top:8px"><input type="checkbox" id="f-constr" data-act="construction"' + (e.construction ? ' checked' : '') + '> Construction geometry</label>' +
      '<p style="margin:8px 0 0">' + (st.ana.entFree(id) ? '<span class="pill under">Under-defined</span>' : '<span class="pill ok">Fully defined</span>') + '</p>' +
      '<div class="btnrow"><button class="btn small" type="button" data-act="delete">Delete</button></div></div>';
    return h + conListHtml(consOf(id), 'Constraints');
  }
  function noSelHtml() {
    const d = st.doc;
    let nE = 0, nC = 0, nD = 0;
    for (const id in d.entities) if (!d.entities[id].ref) nE++;
    for (const id in d.constraints) { if (PS.isDim(d.constraints[id])) nD++; else nC++; }
    const bad = Array.from(st.ana.conflict).concat(Array.from(st.ana.redundant));
    return '<div class="sec"><h2>Sketch</h2><p style="margin:0 0 8px">' + dofPill() + '</p>' +
      '<div class="row"><span class="lab">Curves</span><span class="kv">' + nE + '</span></div>' +
      '<div class="row"><span class="lab">Constraints</span><span class="kv">' + nC + '</span></div>' +
      '<div class="row"><span class="lab">Dimensions</span><span class="kv">' + nD + '</span></div></div>' +
      conListHtml(bad, 'Needs attention') +
      '<div class="sec"><h2>Reading the sketch</h2>' +
      '<p class="hint"><b style="color:var(--under)">Blue</b> geometry can still move. Drag it, or add constraints and dimensions until no blue is left.</p>' +
      '<p class="hint">Select items, then pick a constraint. Press <kbd>D</kbd> and click a line or circle to dimension it; double-click a dimension to change it.</p>' +
      '<p class="hint">Click inside a closed loop to select the shape and give it a fill. <kbd>Tab</kbd> switches to Clean view.</p></div>';
  }
  function colorRow(key, label, val, idp) {
    const none = val === 'none', hex = none ? '#ffffff' : val;
    return '<div class="row tight"><label for="f-' + idp + 'mode">' + label + '</label><div class="pair">' +
      '<select class="field" id="f-' + idp + 'mode" data-style="' + key + '" data-kind="mode" style="flex:0 0 66px">' + opt('none', 'None', none ? 'none' : 'solid') + opt('solid', 'Solid', none ? 'none' : 'solid') + '</select>' +
      '<input type="color" id="f-' + idp + 'col" data-style="' + key + '" data-kind="color" value="' + esc(hex) + '" aria-label="' + label + ' color"' + (none ? ' disabled' : '') + '>' +
      '<input class="field" id="f-' + idp + 'hex" data-style="' + key + '" data-kind="hex" value="' + (none ? '' : esc(val)) + '" placeholder="#rrggbb" aria-label="' + label + ' hex"' + (none ? ' disabled' : '') + '></div></div>';
  }
  function swatchHtml(key) {
    const cols = st.recent.concat(PALETTE.filter(c => st.recent.indexOf(c) < 0)).slice(0, 16);
    return '<div class="swatches">' + cols.map(c => '<button type="button" data-swatch="' + c + '" data-style="' + key + '" style="background:' + c + '" title="' + c + '" aria-label="' + c + '"></button>').join('') +
      (window.EyeDropper ? '<button type="button" class="btn small" data-eyedrop="' + key + '" style="width:auto;height:18px;padding:0 6px">Pick</button>' : '') + '</div>';
  }
  function shapeHtml(shapes) {
    const d = st.doc, s0 = shapes[0], rec = s0.rec, many = shapes.length > 1;
    const faces = shapes.filter(s => s.kind === 'face');
    const nested = faces.filter(s => s.face.parent >= 0);
    let h = '<div class="sec"><h2>' + (many ? shapes.length + ' shapes' : s0.kind === 'face' ? (s0.face.own ? 'Shape' : 'Hole') : 'Open path') + '</h2>';
    if (!many && s0.kind === 'face') h += '<p class="hint">Closed region bounded by ' + rec.ents.length + (rec.ents.length === 1 ? ' curve' : ' curves') + '. Its styling stays with it when dimensions change.</p>';
    if (!many && s0.kind === 'path') h += '<p class="hint">Open chain: outline only. Close the loop to make it fillable.</p>';
    if (nested.length) {
      const own = nested.every(s => s.face.own);
      h += '<div class="row" style="margin-top:8px"><label for="f-role">Inside loop</label><select class="field" id="f-role" data-act="role">' + opt('hole', 'Hole in the outer shape', own ? 'own' : 'hole') + opt('own', 'Separate shape', own ? 'own' : 'hole') + '</select></div>';
    }
    h += '</div>';
    if (faces.length) h += '<div class="sec"><h2>Fill</h2>' + colorRow('fill', 'Fill', faces[0].rec.fill, 'fl') + swatchHtml('fill') + '</div>';
    h += '<div class="sec"><h2>Outline</h2>' + colorRow('stroke', 'Color', rec.stroke, 'st') +
      '<div class="row"><label for="f-sw">Width</label><div class="pair"><input class="field" id="f-sw" data-style="sw" value="' + PS.fmtNum(rec.sw / PS.UNITS[d.units], Math.max(d.precision, 3)) + '"><span class="lab">' + d.units + '</span></div></div>' +
      '<div class="row"><label for="f-dash">Style</label><select class="field" id="f-dash" data-style="dash">' + opt('solid', 'Solid', rec.dash) + opt('dash', 'Dashed', rec.dash) + opt('dot', 'Dotted', rec.dash) + opt('dashdot', 'Dash-dot', rec.dash) + '</select></div>' +
      '<div class="row"><label for="f-join">Corners</label><select class="field" id="f-join" data-style="join">' + opt('miter', 'Sharp', rec.join) + opt('round', 'Round', rec.join) + opt('bevel', 'Bevel', rec.join) + '</select></div>' +
      '<div class="row"><label for="f-cap">Ends</label><select class="field" id="f-cap" data-style="cap">' + opt('butt', 'Flat', rec.cap) + opt('round', 'Round', rec.cap) + opt('square', 'Square', rec.cap) + '</select></div></div>';
    h += '<div class="sec"><h2>Opacity</h2><div class="pair"><input type="range" id="f-op" min="0" max="100" step="1" value="' + Math.round(rec.opacity * 100) + '" data-style="opacity" aria-label="Opacity"><span class="kv" id="f-opv" style="flex:0 0 38px;text-align:right">' + Math.round(rec.opacity * 100) + '%</span></div></div>';
    h += '<div class="sec"><h2>Order</h2><div class="btnrow" style="margin-top:0"><button class="btn small" type="button" data-act="front">Bring to front</button><button class="btn small" type="button" data-act="back">Send to back</button></div></div>';
    return h;
  }
  function selectedShapes() { return Array.from(st.sel).filter(r => r[0] === 's').map(r => shapeByKey(r.slice(2))).filter(Boolean); }
  function setStyle(key, val, live) {
    for (const s of selectedShapes()) {
      if (key === 'fill' && s.kind !== 'face') continue;
      s.rec[key] = val; s.rec.user = true;
      // filling an inner loop makes it a shape of its own, in front of the shape around it
      if (key === 'fill' && val !== 'none' && s.face.parent >= 0 && s.rec.own !== true) { s.rec.own = true; s.rec.z = ++st.doc.zTop; }
    }
    if (live) { PS.syncShapes(st.doc, st.topo); st.items = PS.drawList(st.topo); requestDraw(); } else commit();
  }
  function rememberColor(c) {
    if (!/^#[0-9a-f]{6}$/i.test(c)) return;
    st.recent = [c.toLowerCase()].concat(st.recent.filter(x => x !== c.toLowerCase())).slice(0, 8);
    try { localStorage.setItem(STORE + '.colors', JSON.stringify(st.recent)); } catch (e) { /* fine */ }
  }
  function normHex(v) {
    v = v.trim();
    if (/^[0-9a-f]{3}$/i.test(v) || /^[0-9a-f]{6}$/i.test(v)) v = '#' + v;
    if (/^#[0-9a-f]{3}$/i.test(v)) v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
    return /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : null;
  }
  function onPanelInput(e) {
    const t = e.target, key = t.dataset.style;
    if (!key) return;
    if (t.dataset.kind === 'color') { setStyle(key, t.value, true); const hx = t.parentNode.querySelector('[data-kind="hex"]'); if (hx) hx.value = t.value; }
    else if (key === 'opacity') { setStyle(key, t.value / 100, true); $('f-opv').textContent = t.value + '%'; }
  }
  function onPanelChange(e) {
    const t = e.target, d = st.doc;
    if (t.dataset.doc) {
      const k = t.dataset.doc;
      if (k === 'units') d.units = t.value;
      else if (k === 'precision') d.precision = +t.value;
      else if (k === 'grid') d.grid.show = t.checked;
      else if (k === 'snap') d.grid.snap = t.checked;
      commit(); return;
    }
    if (t.dataset.style) {
      const key = t.dataset.style, kind = t.dataset.kind;
      if (kind === 'mode') {
        const cur = selectedShapes()[0];
        setStyle(key, t.value === 'none' ? 'none' : key === 'fill' ? (st.recent[0] || PALETTE[1]) : PS.DEFAULT_STYLE.stroke);
        if (cur && t.value !== 'none') rememberColor(cur.rec[key]);
      } else if (kind === 'color') { rememberColor(t.value); setStyle(key, t.value); }
      else if (kind === 'hex') { const v = normHex(t.value); if (!v) { toast('Enter a color as #rrggbb.', true); queuePanels(); return; } rememberColor(v); setStyle(key, v); }
      else if (key === 'sw') {
        const r = PS.evalExpr(t.value, { units: d.units, kind: 'length' });
        if (!r.ok || !(r.value >= 0) || r.value > 1000) { toast('Enter an outline width, such as 0.5 or 1 pt.', true); queuePanels(); return; }
        setStyle(key, r.value);
      } else if (key === 'opacity') setStyle(key, t.value / 100);
      else setStyle(key, t.value);
      return;
    }
    if (t.dataset.act === 'role') {
      for (const s of selectedShapes()) if (s.kind === 'face' && s.face.parent >= 0) {
        if (t.value === 'own' && s.rec.own !== true) s.rec.z = ++d.zTop;   // the outer shape is solid underneath, so sit in front of it
        s.rec.own = t.value === 'own'; s.rec.user = true;
      }
      commit(); return;
    }
    if (t.dataset.act === 'construction') { const id = Array.from(st.sel)[0].slice(2); d.entities[id].construction = t.checked; commit(); return; }
    if (t.dataset.dim) { setDim(t.dataset.dim, t.value); queuePanels(); return; }
    if (t.dataset.driven) {
      const c = d.constraints[t.dataset.driven];
      if (t.checked) { c.driven = true; commit(); return; }
      const before = PS.docDof(d);
      const r = PS.applyChange(d, doc => { const k = doc.constraints[c.id]; k.driven = false; k.value = PS.measureCon(doc, k); return c.id; });
      if (!r.ok || PS.docDof(d) >= before) {
        d.constraints[c.id].driven = true;
        derive();
        toast('That size is already fixed by other constraints, so this dimension stays a reference.');
      }
      commit(); return;
    }
    if (t.dataset.pt) {
      const r = PS.evalExpr(t.value, { units: d.units, kind: 'length' });
      if (!r.ok) { toast(esc(r.error) + '.', true); queuePanels(); return; }
      const p = d.points[t.dataset.pt];
      const s = PS.beginDrag(st.sys, [{ kind: 'point', pid: p.id }]);
      s.grabs[0].t[t.dataset.ax] = r.value;
      for (let i = 0; i < 12; i++) PS.dragStep(s);
      if (Math.abs(d.points[p.id][t.dataset.ax] - r.value) > 1e-6) toast('The constraints on this point do not let it go all the way there.');
      commit(); return;
    }
  }
  function onPanelClick(e) {
    const t = e.target, d = st.doc;
    const del = t.closest('[data-delcon]');
    if (del) { PS.deleteItems(d, [del.dataset.delcon]); PS.trySolve(d); st.hover = null; commit(); return; }
    const sw = t.closest('[data-swatch]');
    if (sw) { rememberColor(sw.dataset.swatch); setStyle(sw.dataset.style, sw.dataset.swatch); return; }
    const eye = t.closest('[data-eyedrop]');
    if (eye) { try { new window.EyeDropper().open().then(r => { const v = normHex(r.sRGBHex); if (v) { rememberColor(v); setStyle(eye.dataset.eyedrop, v); } }).catch(() => { }); } catch (err) { toast('The color picker is not available here.'); } return; }
    const sh = t.closest('[data-shape]');
    if (sh) { if (!e.shiftKey) st.sel.clear(); st.sel.add('s:' + sh.dataset.shape); queuePanels(); requestDraw(); return; }
    const con = t.closest('[data-con]');
    if (con) { st.sel.clear(); st.sel.add('c:' + con.dataset.con); if (st.mode === 'clean') setMode('sketch'); queuePanels(); requestDraw(); return; }
    const act = t.closest('button[data-act]');
    if (!act) return;
    if (act.dataset.act === 'delete') deleteSelection();
    else if (act.dataset.act === 'front' || act.dataset.act === 'back') {
      const front = act.dataset.act === 'front';
      let lo = Infinity;
      for (const k in d.shapes) lo = Math.min(lo, d.shapes[k].z);
      for (const s of selectedShapes()) { s.rec.z = front ? ++d.zTop : (lo -= 1); s.rec.user = true; }
      commit();
    }
  }
  function onPanelHover(e) {
    const con = e.target.closest && e.target.closest('[data-con]');
    const sh = e.target.closest && e.target.closest('[data-shape]');
    const h = con ? 'c:' + con.dataset.con : sh ? 's:' + sh.dataset.shape : null;
    if (h !== st.hover) { st.hover = h; requestDraw(); }
  }

  // ------------------------------------------------------------------
  // export, clipboard, files
  // ------------------------------------------------------------------
  function exportItems(scope) {
    if (scope !== 'selection') return st.items;
    const keys = new Set(), ents = new Set();
    for (const r of st.sel) {
      if (r[0] === 's') { const s = shapeByKey(r.slice(2)); if (s) keys.add(s.kind === 'face' ? PS.ownerFace(st.topo, s.face).key : s.key); }
      else if (r[0] === 'e') ents.add(r.slice(2));
    }
    return st.items.filter(it => keys.has(it.key) || it.rec.ents.some(e => ents.has(e)));
  }
  function renderPNG(items, o) {
    const b = PS.itemsBounds(items).stroke, k = o.dpi / 25.4;
    let W = Math.max(1, Math.ceil((b[2] - b[0]) * k)), H = Math.max(1, Math.ceil((b[3] - b[1]) * k));
    let scale = k, note = '';
    const MAXPX = 8192;
    if (W > MAXPX || H > MAXPX) { const f = MAXPX / Math.max(W, H); scale = k * f; W = Math.max(1, Math.round(W * f)); H = Math.max(1, Math.round(H * f)); note = 'The image was limited to ' + MAXPX + ' px on its long side.'; }
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const g = c.getContext('2d');
    if (o.background) { g.fillStyle = o.background; g.fillRect(0, 0, W, H); }
    g.setTransform(scale, 0, 0, -scale, -b[0] * scale, b[3] * scale);
    for (const it of items) PS.paintItem(g, it);
    const dpi = scale * 25.4;
    const blob = new Promise((res, rej) => c.toBlob(bl => {
      if (!bl) { rej(new Error('PNG encoding failed')); return; }
      bl.arrayBuffer().then(buf => res(new Blob([PS.pngSetDpi(new Uint8Array(buf), dpi)], { type: 'image/png' })), rej);
    }, 'image/png'));
    return { blob, W, H, dpi, note, mmW: b[2] - b[0], mmH: b[3] - b[1] };
  }
  let usePromise = null;
  function downloadsCap() {
    if (!usePromise) usePromise = (window.claude && window.claude.use) ? window.claude.use('downloads').catch(() => null) : Promise.resolve(undefined);
    return usePromise;
  }
  // Returns 'saved', 'declined' or 'unavailable'.
  async function saveFile(filename, data, mime) {
    const cap = await downloadsCap();
    if (cap) {
      try { await cap.save({ filename, data }); return 'saved'; }
      catch (err) { return err && err.code === 'declined' ? 'declined' : 'unavailable'; }
    }
    if (cap === null) return 'unavailable';
    // opened as a plain file, outside a viewer: an ordinary download works
    try {
      const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 10000);
      return 'saved';
    } catch (err) { return 'unavailable'; }
  }
  function closeDialog() { const s = $('scrim'); if (s) s.remove(); cv.focus({ preventScroll: true }); }
  function dialog(html) {
    closeDialog();
    const s = document.createElement('div');
    s.id = 'scrim';
    s.innerHTML = '<div class="dialog" role="dialog" aria-modal="true">' + html + '</div>';
    s.addEventListener('mousedown', e => { if (e.target === s) closeDialog(); });
    document.body.appendChild(s);
    const f = s.querySelector('[autofocus], button, input, select');
    if (f) f.focus();
    return s;
  }
  async function copyText(text, okMsg) {
    try { await navigator.clipboard.writeText(text); toast(okMsg); return true; }
    catch (err) { return false; }
  }
  // Shown when a file cannot be saved or an image cannot be copied directly.
  function fallbackDialog(o) {
    let h = '<h1>' + o.title + '</h1><p class="hint">' + o.why + '</p>';
    if (o.imgUrl) h += '<div class="preview"><img alt="Drawing" src="' + o.imgUrl + '"></div><p class="note">Right-click the image and choose <b>Copy image</b>, then paste it into PowerPoint or Visio. ' + (o.size || '') + '</p>';
    if (o.text) h += '<textarea class="code" id="f-code" readonly aria-label="File contents">' + esc(o.text) + '</textarea>';
    h += '<div class="foot">' + (o.text ? '<button class="btn" type="button" id="dlgCopyText">' + (o.textLabel || 'Copy text') + '</button>' : '') +
      (o.save ? '<button class="btn" type="button" id="dlgSave">' + o.saveLabel + '</button>' : '') + '<button class="btn primary" type="button" id="dlgClose">Done</button></div>';
    const s = dialog(h);
    s.querySelector('#dlgClose').onclick = closeDialog;
    if (o.text) s.querySelector('#dlgCopyText').onclick = async () => {
      if (!(await copyText(o.text, 'Copied.'))) { const ta = s.querySelector('#f-code'); ta.focus(); ta.select(); toast('Press Ctrl+C to copy the selected text.'); }
    };
    if (o.save) s.querySelector('#dlgSave').onclick = o.save;
  }
  async function copyImage() {
    const sel = exportItems('selection'), items = sel.length ? sel : st.items;
    if (!items.length) { toast('Nothing to copy yet. Draw a closed shape or a line first.'); return; }
    const out = renderPNG(items, { dpi: 300 });
    const svg = PS.buildSVG(items, {});
    const what = sel.length ? 'Selection' : 'Drawing';
    const sizeTxt = PS.fmtNum(out.mmW, 2) + ' × ' + PS.fmtNum(out.mmH, 2) + ' mm at ' + Math.round(out.dpi) + ' dpi.';
    let failed = null;
    try {
      if (!navigator.clipboard || !window.ClipboardItem) throw new Error('This browser has no image clipboard.');
      const parts = { 'image/png': out.blob };
      let withSvg = false;
      try { withSvg = !!(ClipboardItem.supports && ClipboardItem.supports('image/svg+xml')); } catch (e) { withSvg = false; }
      if (withSvg) {
        try { await navigator.clipboard.write([new ClipboardItem(Object.assign({ 'image/svg+xml': new Blob([svg.svg], { type: 'image/svg+xml' }) }, parts))]); }
        catch (e) { await navigator.clipboard.write([new ClipboardItem({ 'image/png': out.blob })]); withSvg = false; }
      } else await navigator.clipboard.write([new ClipboardItem(parts)]);
      toast(what + ' copied as an image' + (withSvg ? ' (PNG and SVG)' : '') + ', ' + sizeTxt + ' Paste it into PowerPoint or Visio.');
      return;
    } catch (err) { failed = err; }
    let blob;
    try { blob = await out.blob; } catch (err) { toast('The image could not be created.', true); return; }
    const url = URL.createObjectURL(blob);
    fallbackDialog({
      title: 'Copy as image',
      why: 'This page is not allowed to write images to the clipboard here, so copy it by hand or save the file.',
      imgUrl: url, size: sizeTxt,
      save: async () => { const r = await saveFile('drawing.png', blob, 'image/png'); if (r === 'saved') toast('Saved drawing.png.'); else if (r === 'unavailable') toast('Saving is not available in this view. Use right-click, Copy image.', true); },
      saveLabel: 'Save PNG', text: svg.svg, textLabel: 'Copy SVG code'
    });
  }
  function exportDialog() {
    const hasSel = exportItems('selection').length > 0;
    const h = '<h1>Export</h1>' +
      '<div class="row"><label for="x-fmt">Format</label><select class="field" id="x-fmt">' + opt('svg', 'SVG (editable vectors)', 'svg') + opt('png', 'PNG (image)', 'svg') + '</select></div>' +
      '<div class="row"><label for="x-scope">Include</label><select class="field" id="x-scope">' + opt('all', 'Whole drawing', hasSel ? 'selection' : 'all') + (hasSel ? opt('selection', 'Selection only', 'selection') : '') + '</select></div>' +
      '<div id="x-svg"><div class="row"><label for="x-frame">Picture frame</label><select class="field" id="x-frame">' + opt('stroke', 'Geometry plus outline width', 'stroke') + opt('geometry', 'Geometry only (exact size)', 'stroke') + '</select></div>' +
      '<div class="row"><label for="x-arcs">Arcs</label><select class="field" id="x-arcs">' + opt('arc', 'True arcs', 'arc') + opt('bezier', 'Bézier curves', 'arc') + '</select></div></div>' +
      '<div id="x-png" hidden><div class="row"><label for="x-dpi">Resolution</label><div class="pair"><input class="field" id="x-dpi" value="300" inputmode="numeric"><span class="lab">dpi</span></div></div>' +
      '<div class="row"><label for="x-bg">Background</label><select class="field" id="x-bg">' + opt('', 'Transparent', '') + opt('#ffffff', 'White', '') + '</select></div></div>' +
      '<p class="note" id="x-info"></p>' +
      '<div class="foot"><button class="btn" type="button" id="x-cancel">Cancel</button><button class="btn" type="button" id="x-copy">Copy SVG code</button><button class="btn primary" type="button" id="x-go" autofocus>Save file</button></div>';
    const s = dialog(h);
    const q = id => s.querySelector('#' + id);
    const read = () => ({ fmt: q('x-fmt').value, scope: q('x-scope').value, frame: q('x-frame').value, bezier: q('x-arcs').value === 'bezier', dpi: Math.max(10, Math.min(2400, parseFloat(q('x-dpi').value) || 300)), bg: q('x-bg').value });
    const info = () => {
      const o = read(), items = exportItems(o.scope);
      q('x-svg').hidden = o.fmt !== 'svg'; q('x-png').hidden = o.fmt !== 'png'; q('x-copy').hidden = o.fmt !== 'svg';
      if (!items.length) { q('x-info').textContent = 'Nothing to export yet. Shapes appear once the sketch has a closed loop or a line.'; q('x-go').disabled = true; return; }
      q('x-go').disabled = false;
      const b = PS.itemsBounds(items), u = PS.UNITS[st.doc.units], f = v => PS.fmtNum(v / u, Math.max(st.doc.precision, 2));
      const gw = b.geom[2] - b.geom[0], gh = b.geom[3] - b.geom[1], sw = b.stroke[2] - b.stroke[0], sh = b.stroke[3] - b.stroke[1];
      const n = items.length + (items.length === 1 ? ' shape' : ' shapes');
      if (o.fmt === 'svg') {
        q('x-info').innerHTML = o.frame === 'geometry'
          ? n + '. Picture size <b>' + f(gw) + ' × ' + f(gh) + ' ' + st.doc.units + '</b>, exactly the geometry. Outlines sit half outside the frame; some programs crop that half until you convert the picture to shapes.'
          : n + '. Picture size <b>' + f(sw) + ' × ' + f(sh) + ' ' + st.doc.units + '</b>: the ' + f(gw) + ' × ' + f(gh) + ' geometry plus the outline width. After Convert to Shape in PowerPoint the shapes measure ' + f(gw) + ' × ' + f(gh) + '.';
      } else {
        const k = o.dpi / 25.4;
        q('x-info').innerHTML = n + '. <b>' + Math.ceil(sw * k) + ' × ' + Math.ceil(sh * k) + ' px</b>, which is ' + f(sw) + ' × ' + f(sh) + ' ' + st.doc.units + ' at ' + o.dpi + ' dpi. The file records its physical size.';
      }
    };
    for (const id of ['x-fmt', 'x-scope', 'x-frame', 'x-arcs', 'x-dpi', 'x-bg']) q(id).addEventListener('input', info);
    info();
    q('x-cancel').onclick = closeDialog;
    q('x-copy').onclick = async () => {
      const o = read(), out = PS.buildSVG(exportItems(o.scope), o);
      if (out && await copyText(out.svg, 'SVG code copied.')) closeDialog();
      else if (out) fallbackDialog({ title: 'SVG code', why: 'Copying was blocked here. Select the text below and copy it.', text: out.svg, textLabel: 'Copy SVG code' });
    };
    q('x-go').onclick = async () => {
      const o = read(), items = exportItems(o.scope);
      if (!items.length) return;
      if (o.fmt === 'svg') {
        const out = PS.buildSVG(items, o);
        const r = await saveFile('drawing.svg', out.svg, 'image/svg+xml');
        if (r === 'saved') { closeDialog(); toast('Saved drawing.svg. In PowerPoint use Insert, Pictures, then Convert to Shape to edit it.', false, 6500); }
        else if (r === 'unavailable') fallbackDialog({ title: 'Export SVG', why: 'Saving files is not available in this view. Copy the SVG code and save it as a .svg file, or open this page in a browser tab to download.', text: out.svg, textLabel: 'Copy SVG code' });
      } else {
        const out = renderPNG(items, { dpi: o.dpi, background: o.bg || null });
        let blob;
        try { blob = await out.blob; } catch (err) { toast('The image could not be created.', true); return; }
        const r = await saveFile('drawing.png', blob, 'image/png');
        if (r === 'saved') { closeDialog(); toast('Saved drawing.png. ' + out.note); }
        else if (r === 'unavailable') fallbackDialog({ title: 'Export PNG', why: 'Saving files is not available in this view.', imgUrl: URL.createObjectURL(blob), size: out.W + ' × ' + out.H + ' px.' });
      }
    };
  }
  async function saveProject() {
    const text = PS.serialize(st.doc);
    const r = await saveFile('drawing.precisionsketch.json', text, 'application/json');
    if (r === 'saved') toast('Saved drawing.precisionsketch.json.');
    else if (r === 'unavailable') fallbackDialog({ title: 'Save drawing', why: 'Saving files is not available in this view. Copy the text below into a file ending in .json to keep the drawing; File, Open reads it back.', text, textLabel: 'Copy drawing file' });
  }
  function openProject(file) {
    const fr = new FileReader();
    fr.onload = () => {
      const r = PS.parseDoc(String(fr.result));
      if (r.error) { toast(esc(r.error), true, 6000); return; }
      st.example = false; $('example').hidden = true;
      loadDoc(r.doc, true);
      toast('Opened ' + esc(file.name) + '. Undo returns to the previous drawing.');
    };
    fr.onerror = () => toast('That file could not be read.', true);
    fr.readAsText(file);
  }
  function fileMenu() {
    const old = document.querySelector('.menu');
    if (old) { old.remove(); return; }
    const m = document.createElement('div');
    m.className = 'menu';
    m.innerHTML = '<button type="button" data-m="new"><span>New drawing</span></button><button type="button" data-m="open"><span>Open…</span></button><button type="button" data-m="save"><span>Save drawing…</span></button><hr>' +
      '<button type="button" data-m="export"><span>Export SVG or PNG…</span></button><button type="button" data-m="copy"><span>Copy as image</span></button><hr>' +
      '<button type="button" data-m="example"><span>Load the example</span></button><button type="button" data-m="keys"><span>Keyboard shortcuts</span></button>';
    const r = $('btnFile').getBoundingClientRect();
    m.style.left = r.left + 'px'; m.style.top = (r.bottom + 4) + 'px';
    document.body.appendChild(m);
    const close = ev => { if (!ev || !m.contains(ev.target)) { m.remove(); document.removeEventListener('mousedown', close, true); } };
    setTimeout(() => document.addEventListener('mousedown', close, true), 0);
    m.addEventListener('click', e => {
      const b = e.target.closest('[data-m]');
      if (!b) return;
      m.remove(); document.removeEventListener('mousedown', close, true);
      const k = b.dataset.m;
      if (k === 'new') { st.example = false; $('example').hidden = true; loadDoc(PS.newDoc(), true); toast('New drawing. Undo brings the previous one back.'); }
      else if (k === 'open') $('fileIn').click();
      else if (k === 'save') saveProject();
      else if (k === 'export') exportDialog();
      else if (k === 'copy') copyImage();
      else if (k === 'example') { loadDoc(exampleDoc(), true); st.example = true; $('example').hidden = false; }
      else if (k === 'keys') keysDialog();
    });
  }
  function keysDialog() {
    const rows = [['Select', 'Esc'], ['Line', 'L'], ['Rectangle', 'R'], ['Circle', 'C'], ['Arc', 'A'], ['Dimension', 'D'], ['Construction on/off', 'Q'], ['Coincident', 'I'], ['Horizontal', 'H'], ['Vertical', 'V'], ['Parallel', 'B'], ['Perpendicular', 'Shift+L'], ['Tangent', 'T'], ['Equal', 'E'], ['Concentric', 'O'], ['Midpoint', 'M'], ['Fix', 'X'], ['Delete selection', 'Delete'], ['Undo / Redo', 'Ctrl+Z / Ctrl+Y'], ['Sketch / Clean view', 'Tab'], ['Zoom to fit', 'F'], ['Pan', 'Right or middle drag, Space+drag'], ['Zoom', 'Scroll'], ['Snapping off', 'Hold Shift']];
    const s = dialog('<h1>Keyboard shortcuts</h1><div class="keys">' + rows.map(r => '<div><span>' + r[0] + '</span><kbd>' + r[1] + '</kbd></div>').join('') + '</div><div class="foot"><button class="btn primary" type="button" id="dlgClose">Done</button></div>');
    s.querySelector('#dlgClose').onclick = closeDialog;
  }

  // ------------------------------------------------------------------
  // example drawing shown on first open
  // ------------------------------------------------------------------
  function exampleDoc() {
    const d = PS.newDoc(), E = d.entities;
    const keep = st.doc; st.doc = d;     // dimension placement helpers read st.doc
    const R = PS.addRect(d, 0, 0, 70, 40), [b, r, t, l] = R.lines;
    PS.addCon(d, { type: 'coincident', refs: [R.p1, 'O'] });
    const dim = (c, x, y) => { c.pos = posFromPoint(c, { x, y }); return PS.addCon(d, c); };
    dim({ type: 'distance', refs: [b], mode: 'aligned', value: 70 }, 35, -9);
    dim({ type: 'distance', refs: [r], mode: 'aligned', value: 40 }, 79, 20);
    const c1 = PS.addCircle(d, 15, 20, 6), c2 = PS.addCircle(d, 49, 20, 6);
    dim({ type: 'distance', refs: [E[c1].c, l], value: 15 }, 7.5, 47);
    dim({ type: 'distance', refs: [E[c1].c, b], value: 20 }, -9, 10);
    dim({ type: 'diameter', refs: [c1], value: 12 }, 15 + 9, 20 + 11);
    PS.addCon(d, { type: 'equal', refs: [c1, c2] });
    PS.addCon(d, { type: 'horizontal', refs: [E[c1].c, E[c2].c] });
    PS.trySolve(d);
    const sys = PS.buildSystem(d), topo = PS.computeTopology(d, sys);
    PS.syncShapes(d, topo);
    const plate = topo.faces.find(f => f.parent < 0);
    if (plate) { plate.rec.fill = '#58a6f0'; plate.rec.stroke = '#17212b'; plate.rec.sw = 0.5; plate.rec.user = true; }
    st.doc = keep;
    return d;
  }

  // ------------------------------------------------------------------
  // keyboard and start-up
  // ------------------------------------------------------------------
  function onKey(e) {
    st.keys.shift = e.shiftKey;
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = tag === 'input' || tag === 'select' || tag === 'textarea';
    if ($('scrim')) { if (e.key === 'Escape') closeDialog(); return; }
    if (e.target === $('dimedit')) {
      if (e.key === 'Enter') { if (setDim(editing, e.target.value)) { closeDimEdit(); cv.focus({ preventScroll: true }); } else e.target.select(); e.preventDefault(); }
      else if (e.key === 'Escape') { closeDimEdit(); cv.focus({ preventScroll: true }); e.preventDefault(); }
      e.stopPropagation(); return;
    }
    if (typing) { if (e.key === 'Enter' && tag === 'input') e.target.blur(); if (e.key === 'Escape') { e.target.blur(); cv.focus({ preventScroll: true }); } return; }
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const onControl = tag === 'button' || tag === 'a';
    if (onControl && (k === ' ' || k === 'Enter' || k === 'Tab')) return;   // leave keyboard navigation alone
    if (k === 'Escape' && document.querySelector('.menu')) { document.querySelector('.menu').remove(); return; }
    if (e.ctrlKey || e.metaKey) {
      if (k === 'z' && !e.shiftKey) { travel(-1); e.preventDefault(); }
      else if (k === 'y' || (k === 'z' && e.shiftKey)) { travel(1); e.preventDefault(); }
      else if (k === 's') { saveProject(); e.preventDefault(); }
      return;
    }
    if (e.altKey) return;
    if (k === ' ') { st.keys.space = true; if (!st.pan) cv.style.cursor = 'grab'; e.preventDefault(); return; }
    if (k === 'Tab') { setMode(st.mode === 'sketch' ? 'clean' : 'sketch'); e.preventDefault(); return; }
    if (k === 'Escape') {
      hintOverride = null;
      if (st.tool !== 'select' && (st.ts.a || (st.ts.picks && st.ts.picks.length))) { st.ts = st.ts.picks ? { picks: [] } : {}; st.infer = null; }
      else if (st.tool !== 'select') setTool('select');
      else { st.sel.clear(); queuePanels(); }
      requestDraw(); return;
    }
    if (k === 'Delete' || k === 'Backspace') { deleteSelection(); e.preventDefault(); return; }
    if (k === 'f') { fitView(); return; }
    if (k === 'q') { toggleConstruction(); return; }
    if (k === 'l' && e.shiftKey) { hintOverride = null; setTool('perpendicular'); return; }
    if (KEYMAP[k]) { hintOverride = null; setTool(KEYMAP[k]); }
  }
  function start() {
    readColors();
    buildToolbar();
    try { const c = JSON.parse(localStorage.getItem(STORE + '.colors') || '[]'); if (Array.isArray(c)) st.recent = c.filter(x => /^#[0-9a-f]{6}$/.test(x)).slice(0, 8); } catch (e) { /* fine */ }
    resize();
    let doc = null;
    try { const saved = localStorage.getItem(STORE); if (saved) { const r = PS.parseDoc(saved); if (r.doc && Object.keys(r.doc.entities).length > 2) doc = r.doc; } } catch (e) { /* no storage */ }
    if (!doc) { doc = exampleDoc(); st.example = true; $('example').hidden = false; }
    loadDoc(doc);
    buildPanels();

    cv.addEventListener('pointerdown', onDown);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerup', onUp);
    cv.addEventListener('pointercancel', () => { st.pan = null; st.press = null; st.box = null; if (st.drag) dragEnd(); });
    cv.addEventListener('pointerleave', () => { st.mouse.in = false; if (!st.press) { st.hover = null; st.infer = null; } requestDraw(); });
    cv.addEventListener('wheel', onWheel, { passive: false });
    cv.addEventListener('dblclick', onDbl);
    cv.addEventListener('contextmenu', e => e.preventDefault());
    // focus is managed in onDown; the default would steal it back from the dimension box
    cv.addEventListener('mousedown', e => e.preventDefault());
    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup', e => { st.keys.shift = e.shiftKey; if (e.key === ' ') { st.keys.space = false; if (!st.pan) cv.style.cursor = st.tool === 'select' ? 'default' : 'crosshair'; } });
    $('dimedit').addEventListener('blur', () => { setTimeout(() => { if (editing) { setDim(editing, $('dimedit').value); closeDimEdit(); } }, 0); });
    for (const id of ['left', 'right']) {
      $(id).addEventListener('input', onPanelInput);
      $(id).addEventListener('change', onPanelChange);
      $(id).addEventListener('click', onPanelClick);
      $(id).addEventListener('mouseover', onPanelHover);
      $(id).addEventListener('mouseleave', () => { if (st.hover) { st.hover = null; requestDraw(); } });
    }
    $('btnUndo').onclick = () => travel(-1);
    $('btnRedo').onclick = () => travel(1);
    $('btnFit').onclick = fitView;
    $('btnSketch').onclick = () => setMode('sketch');
    $('btnClean').onclick = () => setMode('clean');
    $('btnCopy').onclick = copyImage;
    $('btnExport').onclick = exportDialog;
    $('btnFile').onclick = fileMenu;
    $('btnLeft').onclick = () => { $('left').classList.toggle('open'); $('right').classList.remove('open'); };
    $('btnRight').onclick = () => { $('right').classList.toggle('open'); $('left').classList.remove('open'); };
    $('stage').addEventListener('pointerdown', () => { $('left').classList.remove('open'); $('right').classList.remove('open'); });
    $('btnBlank').onclick = () => { st.example = false; $('example').hidden = true; loadDoc(PS.newDoc(), true); setTool('line'); };
    $('btnExampleClose').onclick = () => { $('example').hidden = true; };
    $('fileIn').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f) openProject(f); e.target.value = ''; });
    new ResizeObserver(resize).observe($('stage'));
    const themeChange = () => { readColors(); requestDraw(); };
    try { window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChange); } catch (e) { /* older browsers */ }
    new MutationObserver(themeChange).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'class', 'style'] });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { readColors(); requestDraw(); });
    downloadsCap();
    setHint(null);
  }
  // keep the drawing across a republish of this page
  const hot = window.claude && window.claude.hot;
  try { if (hot && hot.snapshot) hot.snapshot(() => { try { localStorage.setItem(STORE, JSON.stringify(st.doc)); } catch (e) { /* fine */ } return {}; }); } catch (e) { /* optional */ }
  if (hot && hot.ready) hot.ready(start); else start();
})();
